
#include <cstddef>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <conio.h>
#include <windows.h>
#include <winhttp.h>
#else
// Fallback para sistemas no Windows
#include <stdio.h>
#include <termios.h>
#include <unistd.h>

inline void gotoxy(int x, int y) { printf("\033[%d;%dH", y, x); }

inline int _getch() {
  struct termios oldt, newt;
  int ch;

  tcgetattr(STDIN_FILENO, &oldt);

  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);

  tcsetattr(STDIN_FILENO, TCSANOW, &newt);

  ch = getchar();

  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);

  return ch;
}

inline void Sleep(int ms) { usleep(ms * 1000); }

#endif

using namespace std;

// =========================================================================
// GOToxy NATIVO PARA WINDOWS
// =========================================================================

#ifdef _WIN32

void gotoxy(int x, int y) {

  COORD coord;

  coord.X = x;
  coord.Y = y;

  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

#endif

// =========================================================================
// PERSISTENCIA EN TXT PLANO
// =========================================================================

// =========================================================================
// PRODUCTO DE INVESTIGACION
// =========================================================================

struct ProductoInvestigacion {

  string idProducto;
  string titulo;
  string categoria;
  bool validado;
  int anio;

  // Datos que pueden aparecer en GrupLAC/CvLAC.
  string tipoProducto;
  string subtipo;
  string doi;
  string isbn;
  string revista;
  string editorial;
  string disponibilidad;
  string institucion;
  string ciudad;
  string pais;
  string numeroContrato;
  string descripcion;
  string palabrasClave;
  string areas;

  vector<string> autores;

  ProductoInvestigacion(string id = "", string t = "", string c = "",
                        bool v = false, int a = 0, string tipo = "",
                        string sub = "", string d = "", string i = "",
                        string r = "", string e = "", string disp = "",
                        string inst = "", string ciu = "", string p = "",
                        string contrato = "", string desc = "",
                        string palabras = "", string ars = "")
      : idProducto(id), titulo(t), categoria(c), validado(v), anio(a),
        tipoProducto(tipo), subtipo(sub), doi(d), isbn(i), revista(r),
        editorial(e), disponibilidad(disp), institucion(inst), ciudad(ciu),
        pais(p), numeroContrato(contrato), descripcion(desc),
        palabrasClave(palabras), areas(ars) {}
};

// =========================================================================
// NODO PRODUCTO//
// =========================================================================
// NODO PRODUCTO
// =========================================================================

struct NodoProducto {

  ProductoInvestigacion *producto;
  NodoProducto *sig;

  NodoProducto(ProductoInvestigacion *p) : producto(p), sig(NULL) {}

  ~NodoProducto() { delete producto; }
};

// =========================================================================
// INVESTIGADOR
// =========================================================================

struct Investigador {

  string codigoRh;
  string nombre;
  string correo;

  // Datos complementarios que pueden aparecer en CvLAC.
  string orcid;
  string institucion;
  string departamento;
  string ciudad;
  string categoriaInvestigador;
  string perfil;
  string nombreCitaciones;
  string nacionalidad;
  string sexo;
  string estadoParEvaluador;

  string researcherId;
  string autorIdScopus;
  string googleScholar;
  string researchGate;
  string academiaEdu;
  string mendeley;
  string linkedin;
  string repositorioInstitucional;

  vector<string> idiomas;

  // Secciones de la hoja de vida.
  vector<string> areasConocimiento;
  vector<string> lineasInvestigacion;
  vector<string> formacionAcademica;
  vector<string> experienciaProfesional;
  vector<string> gruposInvestigacion;
  vector<string> semilleros;
  vector<string> proyectos;
  vector<string> reconocimientos;

  NodoProducto *productos;

  bool activo;

  Investigador(string id = "", string nom = "", string corr = "", string o = "",
               string inst = "", string dep = "", string ciu = "",
               string categoria = "", string per = "")
      : codigoRh(id), nombre(nom), correo(corr), orcid(o), institucion(inst),
        departamento(dep), ciudad(ciu), categoriaInvestigador(categoria),
        perfil(per), productos(NULL), activo(true) {}

  ~Investigador() {

    NodoProducto *actual = productos;

    while (actual) {

      NodoProducto *siguiente = actual->sig;

      delete actual;

      actual = siguiente;
    }

    productos = NULL;
  }

  int contarProductos() const {
    int total = 0;
    NodoProducto *actual = productos;
    while (actual) {
      total++;
      actual = actual->sig;
    }
    return total;
  }

  void agregarProducto(ProductoInvestigacion *producto) {

    if (producto) {

      NodoProducto *nuevo = new NodoProducto(producto);

      if (!productos) {

        productos = nuevo;

      } else {

        NodoProducto *actual = productos;

        while (actual->sig) {

          actual = actual->sig;
        }

        actual->sig = nuevo;
      }
    }
  }
};

// =========================================================================
// NODO INVESTIGADOR//
// =========================================================================
// NODO INVESTIGADOR
// =========================================================================

struct NodoInvestigador {

  Investigador *investigador;

  NodoInvestigador *ant;
  NodoInvestigador *sig;

  NodoInvestigador(Investigador *inv)
      : investigador(inv), ant(NULL), sig(NULL) {}

  ~NodoInvestigador() {

    delete investigador;

    investigador = NULL;
  }
};

// =========================================================================
// GRUPO DE INVESTIGACION
// =========================================================================

struct GrupoInvestigacion {

  string nroGrupo;
  string nombreGrupo;

  // Datos basicos observables en GrupLAC.
  string anioFormacion;
  string departamento;
  string ciudad;
  string lider;
  string informacionCertificada;
  string paginaWeb;
  string email;
  string clasificacion;
  string areaConocimiento;
  string programaNacionalCti;
  string programaNacionalCtiSecundario;

  // Informacion descriptiva.
  string planEstrategico;
  string estadoArte;
  string objetivos;
  string retos;
  string vision;

  vector<string> instituciones;
  vector<string> lineasInvestigacion;

  GrupoInvestigacion(string num = "", string nom = "", string anio = "",
                     string dep = "", string ciu = "", string lid = "",
                     string certificado = "", string web = "", string mail = "",
                     string clasif = "", string area = "", string programa = "",
                     string programaSec = "", string plan = "",
                     string estado = "", string obj = "", string ret = "",
                     string vis = "")
      : nroGrupo(num), nombreGrupo(nom), anioFormacion(anio), departamento(dep),
        ciudad(ciu), lider(lid), informacionCertificada(certificado),
        paginaWeb(web), email(mail), clasificacion(clasif),
        areaConocimiento(area), programaNacionalCti(programa),
        programaNacionalCtiSecundario(programaSec), planEstrategico(plan),
        estadoArte(estado), objetivos(obj), retos(ret), vision(vis) {}
};

// =========================================================================
// NODO GRUPO//
// =========================================================================
// NODO GRUPO
// =========================================================================

struct NodoGrupo {

  GrupoInvestigacion *grupo;

  // Los investigadores almacenados dentro del grupo
  // son copias independientes.
  NodoInvestigador *hijoIntegrantes;

  // Los productos pertenecen al grupo.
  NodoProducto *hijoProductos;

  NodoGrupo *sig;

  NodoGrupo(GrupoInvestigacion *g)
      : grupo(g), hijoIntegrantes(NULL), hijoProductos(NULL), sig(NULL) {}

  ~NodoGrupo() {

    // Liberar grupo
    delete grupo;

    // Liberar integrantes
    NodoInvestigador *inv = hijoIntegrantes;

    while (inv) {

      NodoInvestigador *siguiente = inv->sig;

      delete inv;

      inv = siguiente;
    }

    // Liberar productos
    NodoProducto *prod = hijoProductos;

    while (prod) {

      NodoProducto *siguiente = prod->sig;

      delete prod;

      prod = siguiente;
    }

    grupo = NULL;
    hijoIntegrantes = NULL;
    hijoProductos = NULL;
  }
};

// =========================================================================
static string canonicalKey(const string &texto) {
  string resultado = "";
  bool espacioPrevio = false;
  size_t i = 0;

  while (i < texto.size()) {
    unsigned char c = static_cast<unsigned char>(texto[i]);
    char conv = ' ';
    bool multiocteto = false;

    // Reconocimiento de caracteres UTF-8 comunes en espanol (prefijo 0xC3)
    if (c == 0xC3 && i + 1 < texto.size()) {
      unsigned char c2 = static_cast<unsigned char>(texto[i + 1]);
      if (c2 == 0xA1 || c2 == 0x81) {
        conv = 'a';
        multiocteto = true;
      } else if (c2 == 0xA9 || c2 == 0x89) {
        conv = 'e';
        multiocteto = true;
      } else if (c2 == 0xAD || c2 == 0x8D) {
        conv = 'i';
        multiocteto = true;
      } else if (c2 == 0xB3 || c2 == 0x93) {
        conv = 'o';
        multiocteto = true;
      } else if (c2 == 0xBA || c2 == 0x9A || c2 == 0xBC || c2 == 0x9C) {
        conv = 'u';
        multiocteto = true;
      } else if (c2 == 0xB1 || c2 == 0x91) {
        conv = 'n';
        multiocteto = true;
      }
      if (multiocteto) {
        i++;
      }
    }

    if (!multiocteto) {
      if (c >= 'A' && c <= 'Z') {
        conv = static_cast<char>(c + ('a' - 'A'));
      } else if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
        conv = static_cast<char>(c);
      } else {
        conv = ' ';
      }
    }

    if (conv != ' ') {
      resultado += conv;
      espacioPrevio = false;
    } else {
      if (!espacioPrevio && !resultado.empty()) {
        resultado += ' ';
        espacioPrevio = true;
      }
    }

    i++;
  }

  if (!resultado.empty() && resultado[resultado.size() - 1] == ' ') {
    resultado = resultado.substr(0, resultado.size() - 1);
  }

  return resultado;
}

// LISTA DE INVESTIGADORES
// =========================================================================

class ListaInvestigadores {

private:
  NodoInvestigador *cabeza;
  NodoInvestigador *cola;

public:
  ListaInvestigadores() : cabeza(NULL), cola(NULL) {}

  ~ListaInvestigadores() { limpiar(); }

  // ---------------------------------------------------------
  // AGREGAR
  // ---------------------------------------------------------

  void agregar(Investigador *inv) {

    if (inv) {

      NodoInvestigador *nuevo = new NodoInvestigador(inv);

      if (!cabeza) {

        cabeza = nuevo;
        cola = nuevo;
      } else {

        cola->sig = nuevo;

        nuevo->ant = cola;

        cola = nuevo;
      }
    }
  }

  // ---------------------------------------------------------
  // BUSCAR
  // ---------------------------------------------------------

    Investigador *buscarCoincidencia(const Investigador *otro) {
    if (!otro) {
      return NULL;
    }
    string codOtro = otro->codigoRh;
    string nomOtro = canonicalKey(otro->nombre);
    string orcidOtro = canonicalKey(otro->orcid);
    string correoOtro = canonicalKey(otro->correo);

    NodoInvestigador *actual = cabeza;
    Investigador *encontrado = NULL;

    while (actual && !encontrado) {
      Investigador *cur = actual->investigador;
      if (cur) {
        bool coincide = false;
        if (!codOtro.empty() && !cur->codigoRh.empty() && codOtro == cur->codigoRh) {
          coincide = true;
        }
        if (!coincide && !nomOtro.empty() && nomOtro.size() >= 4) {
          string nomCur = canonicalKey(cur->nombre);
          if (nomOtro == nomCur) {
            coincide = true;
          }
        }
        if (!coincide && !orcidOtro.empty() && orcidOtro.size() >= 8) {
          string orcidCur = canonicalKey(cur->orcid);
          if (orcidOtro == orcidCur) {
            coincide = true;
          }
        }
        if (!coincide && !correoOtro.empty() && correoOtro.size() >= 5) {
          string correoCur = canonicalKey(cur->correo);
          if (correoOtro == correoCur) {
            coincide = true;
          }
        }

        if (coincide) {
          encontrado = cur;
        }
      }
      actual = actual->sig;
    }

    return encontrado;
  }

Investigador *buscar(string codigo) {

    NodoInvestigador *actual = cabeza;

    while (actual) {

      if (actual->investigador->codigoRh == codigo) {

        return actual->investigador;
      }

      actual = actual->sig;
    }

    return NULL;
  }

  // ---------------------------------------------------------
  // DESACTIVAR
  // ---------------------------------------------------------

  void desactivar(string codigo) {

    Investigador *inv = buscar(codigo);

    if (inv) {

      inv->activo = false;
    }
  }

  // ---------------------------------------------------------
  // OBTENER CABEZA
  // ---------------------------------------------------------

  NodoInvestigador *getCabeza() { return cabeza; }

  // ---------------------------------------------------------
  // LIMPIAR
  // ---------------------------------------------------------

  void limpiar() {

    NodoInvestigador *actual = cabeza;

    while (actual) {

      NodoInvestigador *siguiente = actual->sig;

      delete actual;

      actual = siguiente;
    }

    cabeza = NULL;
    cola = NULL;
  }
};

// =========================================================================
// MULTILISTA DE GRUPOS
// =========================================================================

class MultilistaGrupos {

private:
  NodoGrupo *cabeza;

public:
  MultilistaGrupos() : cabeza(NULL) {}

  ~MultilistaGrupos() { limpiar(); }

  // ---------------------------------------------------------
  // AGREGAR GRUPO
  // ---------------------------------------------------------

  void agregarGrupo(GrupoInvestigacion *g) {

    if (g) {

      NodoGrupo *nuevo = new NodoGrupo(g);

      if (!cabeza) {

        cabeza = nuevo;

      } else {

        NodoGrupo *actual = cabeza;

        while (actual->sig) {

          actual = actual->sig;
        }

        actual->sig = nuevo;
      }
    }
  }

  // ---------------------------------------------------------
  // BUSCAR GRUPO
  // ---------------------------------------------------------

    NodoGrupo *buscarGrupoCoincidencia(const GrupoInvestigacion *otro) {
    if (!otro) {
      return NULL;
    }
    string numOtro = otro->nroGrupo;
    string nomOtro = canonicalKey(otro->nombreGrupo);

    NodoGrupo *actual = cabeza;
    NodoGrupo *encontrado = NULL;

    while (actual && !encontrado) {
      GrupoInvestigacion *cur = actual->grupo;
      if (cur) {
        bool coincide = false;
        if (!numOtro.empty() && !cur->nroGrupo.empty() && numOtro == cur->nroGrupo) {
          coincide = true;
        }
        if (!coincide && !nomOtro.empty() && nomOtro.size() >= 4) {
          string nomCur = canonicalKey(cur->nombreGrupo);
          if (nomOtro == nomCur) {
            coincide = true;
          }
        }

        if (coincide) {
          encontrado = actual;
        }
      }
      actual = actual->sig;
    }

    return encontrado;
  }

NodoGrupo *buscarGrupo(string idGrupo) {

    NodoGrupo *actual = cabeza;

    while (actual) {

      if (actual->grupo->nroGrupo == idGrupo) {

        return actual;
      }

      actual = actual->sig;
    }

    return NULL;
  }

  // ---------------------------------------------------------
  // AGREGAR INTEGRANTE
  // ---------------------------------------------------------

  void agregarIntegrante(string idGrupo, Investigador *inv) {

    if (inv) {

      NodoGrupo *grupo = buscarGrupo(idGrupo);

      if (grupo) {

        NodoInvestigador *nuevo = new NodoInvestigador(inv);

        nuevo->sig = grupo->hijoIntegrantes;

        if (grupo->hijoIntegrantes) {

          grupo->hijoIntegrantes->ant = nuevo;
        }

        grupo->hijoIntegrantes = nuevo;
      }
    }
  }

  // ---------------------------------------------------------
  // AGREGAR PRODUCTO
  // ---------------------------------------------------------

  void agregarProducto(string idGrupo, ProductoInvestigacion *producto) {

    if (producto) {

      NodoGrupo *grupo = buscarGrupo(idGrupo);

      if (grupo) {

        NodoProducto *nuevo = new NodoProducto(producto);

        if (!grupo->hijoProductos) {

          grupo->hijoProductos = nuevo;

        } else {

          NodoProducto *actual = grupo->hijoProductos;

          while (actual->sig) {

            actual = actual->sig;
          }

          actual->sig = nuevo;
        }
      }
    }
  }

  // ---------------------------------------------------------
  // OBTENER CABEZA
  // ---------------------------------------------------------

  NodoGrupo *getCabeza() { return cabeza; }

  // ---------------------------------------------------------
  // LIMPIAR
  // ---------------------------------------------------------

  void limpiar() {

    NodoGrupo *actual = cabeza;

    while (actual) {

      NodoGrupo *siguiente = actual->sig;

      delete actual;

      actual = siguiente;
    }

    cabeza = NULL;
  }
};

// =========================================================================
// PILA DE OPERACIONES
// =========================================================================

class PilaOperaciones {

private:
  vector<string> operaciones;

public:
  void push(string op) { operaciones.push_back(op); }

  string pop() {

    if (operaciones.empty())
      return "";

    string op = operaciones.back();

    operaciones.pop_back();

    return op;
  }

  bool empty() { return operaciones.empty(); }
};

// =========================================================================
// COLA DE PROCESAMIENTO
// =========================================================================

class ColaProcesamiento {

private:
  vector<ProductoInvestigacion *> cola;

public:
  void enqueue(ProductoInvestigacion *p) {

    if (p)
      cola.push_back(p);
  }

  ProductoInvestigacion *dequeue() {

    if (cola.empty())
      return NULL;

    ProductoInvestigacion *p = cola.front();

    cola.erase(cola.begin());

    return p;
  }

  bool empty() { return cola.empty(); }
};

// =========================================================================
// HIPERCUBO
// =========================================================================

class HipercuboInformacion {

private:
  double ***matriz;

  int N;
  int M;
  int K;

public:
  HipercuboInformacion(int grupos, int categorias, int anios)
      : matriz(NULL), N(grupos), M(categorias), K(anios) {

    matriz = new double **[N];

    for (int i = 0; i < N; ++i) {

      matriz[i] = new double *[M];

      for (int j = 0; j < M; ++j) {

        matriz[i][j] = new double[K];

        for (int k = 0; k < K; ++k) {

          matriz[i][j][k] = 0.0;
        }
      }
    }
  }

  ~HipercuboInformacion() {

    if (matriz) {

      for (int i = 0; i < N; ++i) {

        for (int j = 0; j < M; ++j) {

          delete[] matriz[i][j];
        }

        delete[] matriz[i];
      }

      delete[] matriz;

      matriz = NULL;
    }
  }

  void registrarDato(int g, int c, int a, double valor) {

    if (g >= 0 && g < N && c >= 0 && c < M && a >= 0 && a < K) {

      matriz[g][c][a] += valor;
    }
  }

  void generarResumenEstadistico() {

    cout << "Resumen Estadistico Generado..." << endl;
  }
};

// =========================================================================
// NORMALIZACION CANONICA DE CADENAS (EQUIVALENTE A PYTHON canonical_key)
// =========================================================================


// =========================================================================
// GENERACION DE FIRMA UNICA DE PRODUCTO (TITULO CANONICO + ANIO)
// =========================================================================

static string generarFirmaProducto(const string &titulo, int anio) {
  ostringstream flujo;
  flujo << canonicalKey(titulo) << "#" << anio;
  return flujo.str();
}

// =========================================================================
// REGISTRO Y GESTOR DE PRODUCTOS UNICOS (CONTROL DE DUPLICADOS)
// =========================================================================

struct RegistroProductoUnico {
  ProductoInvestigacion *producto;
  string firma;
  vector<string> gruposVinculados;
  vector<string> investigadoresVinculados;
  int aparicionesTotales;

  RegistroProductoUnico(ProductoInvestigacion *p = NULL, string f = "")
      : producto(p), firma(f), aparicionesTotales(1) {}
};

class GestorProductosUnicos {
private:
  vector<RegistroProductoUnico> catalogo;
  int totalBruto;

  void registrarEnCatalogo(ProductoInvestigacion *prod,
                           const string &nombreGrupo,
                           const string &nombreInv) {
    if (prod != NULL) {
      totalBruto++;
      string firma = generarFirmaProducto(prod->titulo, prod->anio);

      bool encontrado = false;
      size_t indiceEncontrado = 0;
      size_t i = 0;

      while (i < catalogo.size() && !encontrado) {
        if (catalogo[i].firma == firma) {
          encontrado = true;
          indiceEncontrado = i;
        }
        i++;
      }

      if (encontrado) {
        catalogo[indiceEncontrado].aparicionesTotales++;

        if (!nombreGrupo.empty()) {
          bool grupoYaRegistrado = false;
          size_t g = 0;
          while (g < catalogo[indiceEncontrado].gruposVinculados.size() &&
                 !grupoYaRegistrado) {
            if (catalogo[indiceEncontrado].gruposVinculados[g] == nombreGrupo) {
              grupoYaRegistrado = true;
            }
            g++;
          }
          if (!grupoYaRegistrado) {
            catalogo[indiceEncontrado].gruposVinculados.push_back(nombreGrupo);
          }
        }

        if (!nombreInv.empty()) {
          bool invYaRegistrado = false;
          size_t invIdx = 0;
          while (invIdx <
                     catalogo[indiceEncontrado].investigadoresVinculados.size() &&
                 !invYaRegistrado) {
            if (catalogo[indiceEncontrado].investigadoresVinculados[invIdx] ==
                nombreInv) {
              invYaRegistrado = true;
            }
            invIdx++;
          }
          if (!invYaRegistrado) {
            catalogo[indiceEncontrado].investigadoresVinculados.push_back(
                nombreInv);
          }
        }

        if (catalogo[indiceEncontrado].producto->doi.empty() &&
            !prod->doi.empty()) {
          catalogo[indiceEncontrado].producto->doi = prod->doi;
        }
        if (!catalogo[indiceEncontrado].producto->validado && prod->validado) {
          catalogo[indiceEncontrado].producto->validado = true;
        }
        if (catalogo[indiceEncontrado].producto->revista.empty() &&
            !prod->revista.empty()) {
          catalogo[indiceEncontrado].producto->revista = prod->revista;
        }
        if (catalogo[indiceEncontrado].producto->isbn.empty() &&
            !prod->isbn.empty()) {
          catalogo[indiceEncontrado].producto->isbn = prod->isbn;
        }
      } else {
        RegistroProductoUnico nuevoReg(prod, firma);
        if (!nombreGrupo.empty()) {
          nuevoReg.gruposVinculados.push_back(nombreGrupo);
        }
        if (!nombreInv.empty()) {
          nuevoReg.investigadoresVinculados.push_back(nombreInv);
        }
        catalogo.push_back(nuevoReg);
      }
    }
  }

public:
  GestorProductosUnicos() : totalBruto(0) {}

  void limpiar() {
    catalogo.clear();
    totalBruto = 0;
  }

  void consolidar(ListaInvestigadores &listasInv, MultilistaGrupos &multilistas) {
    limpiar();

    NodoInvestigador *actInv = listasInv.getCabeza();
    while (actInv != NULL) {
      if (actInv->investigador != NULL) {
        string nomInv = actInv->investigador->nombre;
        NodoProducto *actProd = actInv->investigador->productos;
        while (actProd != NULL) {
          registrarEnCatalogo(actProd->producto, "", nomInv);
          actProd = actProd->sig;
        }
      }
      actInv = actInv->sig;
    }

    NodoGrupo *actGrupo = multilistas.getCabeza();
    while (actGrupo != NULL) {
      if (actGrupo->grupo != NULL) {
        string nomGrupo = actGrupo->grupo->nombreGrupo;

        NodoProducto *actProdG = actGrupo->hijoProductos;
        while (actProdG != NULL) {
          registrarEnCatalogo(actProdG->producto, nomGrupo, "");
          actProdG = actProdG->sig;
        }

        NodoInvestigador *actInt = actGrupo->hijoIntegrantes;
        while (actInt != NULL) {
          if (actInt->investigador != NULL) {
            string nomInt = actInt->investigador->nombre;
            NodoProducto *actProdInt = actInt->investigador->productos;
            while (actProdInt != NULL) {
              registrarEnCatalogo(actProdInt->producto, nomGrupo, nomInt);
              actProdInt = actProdInt->sig;
            }
          }
          actInt = actInt->sig;
        }
      }
      actGrupo = actGrupo->sig;
    }
  }

  int obtenerTotalBruto() const { return totalBruto; }

  int obtenerTotalUnicos() const {
    return static_cast<int>(catalogo.size());
  }

  int obtenerTotalDuplicados() const {
    int unicos = static_cast<int>(catalogo.size());
    if (totalBruto > unicos) {
      return totalBruto - unicos;
    }
    return 0;
  }

  const vector<RegistroProductoUnico> &getCatalogo() const {
    return catalogo;
  }

  vector<string> obtenerCategoriasDisponibles() const {
    vector<string> categorias;
    size_t i = 0;
    while (i < catalogo.size()) {
      if (catalogo[i].producto != NULL) {
        string cat = catalogo[i].producto->categoria;
        if (cat.empty()) {
          cat = catalogo[i].producto->tipoProducto;
        }
        if (cat.empty()) {
          cat = "Sin Categoria";
        }

        bool existeCat = false;
        size_t cIdx = 0;
        while (cIdx < categorias.size() && !existeCat) {
          if (categorias[cIdx] == cat) {
            existeCat = true;
          }
          cIdx++;
        }
        if (!existeCat) {
          categorias.push_back(cat);
        }
      }
      i++;
    }
    return categorias;
  }

  int contarPorCategoria(const string &catBuscada) const {
    int contador = 0;
    size_t i = 0;
    while (i < catalogo.size()) {
      if (catalogo[i].producto != NULL) {
        string cat = catalogo[i].producto->categoria;
        if (cat.empty()) {
          cat = catalogo[i].producto->tipoProducto;
        }
        if (cat.empty()) {
          cat = "Sin Categoria";
        }
        if (cat == catBuscada) {
          contador++;
        }
      }
      i++;
    }
    return contador;
  }

  vector<int> obtenerAniosDisponibles() const {
    vector<int> anios;
    size_t i = 0;
    while (i < catalogo.size()) {
      if (catalogo[i].producto != NULL) {
        int anio = catalogo[i].producto->anio;
        if (anio > 1000) {
          bool existeAnio = false;
          size_t aIdx = 0;
          while (aIdx < anios.size() && !existeAnio) {
            if (anios[aIdx] == anio) {
              existeAnio = true;
            }
            aIdx++;
          }
          if (!existeAnio) {
            anios.push_back(anio);
          }
        }
      }
      i++;
    }
    return anios;
  }

  int contarPorAnio(int anioBuscado) const {
    int contador = 0;
    size_t i = 0;
    while (i < catalogo.size()) {
      if (catalogo[i].producto != NULL) {
        if (catalogo[i].producto->anio == anioBuscado) {
          contador++;
        }
      }
      i++;
    }
    return contador;
  }
};

// =========================================================================
// LECTOR DE ARCHIVOS Y WEB
// =========================================================================

class LectorArchivosYWeb {

private:
  string ultimoError;

#ifdef _WIN32
  HANDLE procesoScraper;

  static HANDLE s_procesoScraper;
  static DWORD s_pidScraper;
  static HANDLE s_jobScraper;
  static bool s_manejadorRegistrado;
  static string s_ultimoTipoCierre;

  static void inicializarJobScraper() {
    if (s_jobScraper == NULL) {
      s_jobScraper = CreateJobObjectA(NULL, NULL);
      if (s_jobScraper != NULL) {
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION jeli;
        ZeroMemory(&jeli, sizeof(jeli));
        jeli.BasicLimitInformation.LimitFlags =
            JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        SetInformationJobObject(s_jobScraper, JobObjectExtendedLimitInformation,
                                &jeli, sizeof(jeli));
      }
    }
  }

  static void registrarEventoCierre(const string &tipo,
                                    const string &descripcion) {
    ofstream bitacora("scraper_cierre.log", ios::out | ios::app);
    if (bitacora.is_open()) {
      SYSTEMTIME st;
      GetLocalTime(&st);
      char fechaHora[64];
      wsprintfA(fechaHora, "%04d-%02d-%02d %02d:%02d:%02d", st.wYear, st.wMonth,
                st.wDay, st.wHour, st.wMinute, st.wSecond);
      bitacora << "[" << fechaHora << "] [" << tipo << "] " << descripcion;
      if (s_pidScraper != 0) {
        bitacora << " (PID: " << s_pidScraper << ")";
      }
      bitacora << endl;
      bitacora.close();
    }
  }

  static void matarProcesoScraper() {
    if (s_pidScraper != 0) {
      char comando[128];
      wsprintfA(comando, "taskkill /F /T /PID %lu >nul 2>&1", s_pidScraper);
      system(comando);
    }

    if (s_jobScraper != NULL) {
      TerminateJobObject(s_jobScraper, 0);
      CloseHandle(s_jobScraper);
      s_jobScraper = NULL;
    }

    if (s_procesoScraper != NULL) {
      TerminateProcess(s_procesoScraper, 0);
      WaitForSingleObject(s_procesoScraper, 1000);
      CloseHandle(s_procesoScraper);
      s_procesoScraper = NULL;
    }

    s_pidScraper = 0;
  }

  static BOOL WINAPI ManejadorConsola(DWORD tipoControl) {
    if (tipoControl == CTRL_C_EVENT || tipoControl == CTRL_BREAK_EVENT ||
        tipoControl == CTRL_CLOSE_EVENT || tipoControl == CTRL_LOGOFF_EVENT ||
        tipoControl == CTRL_SHUTDOWN_EVENT) {
      cerrarScraperForzado(tipoControl);
      return TRUE;
    } else {
      return FALSE;
    }
  }
#endif

  // =========================================================
  // SEPARAR CAMPOS
  // =========================================================

  vector<string> separarCampos(const string &linea) {

    vector<string> campos;
    string campo;

    for (size_t i = 0; i < linea.size(); ++i) {

      if (linea[i] == '\t') {

        campos.push_back(campo);

        campo = "";
      } else {

        campo += linea[i];
      }
    }

    campos.push_back(campo);

    return campos;
  }

  // =========================================================
  // CONVERTIR TEXTO A BOOLEANO
  // =========================================================

  bool convertirBooleano(const string &valor) {

    return valor == "1" || valor == "true" || valor == "TRUE" ||
           valor == "si" || valor == "SI";
  }

  // =========================================================
  // CONVERTIR TEXTO A ENTERO
  // =========================================================

  int convertirEntero(const string &valor) {

    if (valor.empty())
      return 0;

    return atoi(valor.c_str());
  }

  // =========================================================
  // OBTENER CAMPO OPCIONAL
  // =========================================================

  string campoOpcional(const vector<string> &campos, size_t indice) {

    if (indice < campos.size())
      return campos[indice];

    return "";
  }

  // =========================================================
  // CREAR PRODUCTO DESDE CAMPOS
  // =========================================================

  ProductoInvestigacion *productoDesdeCampos(const vector<string> &campos) {

    if (campos.size() < 6)
      return NULL;

    return new ProductoInvestigacion(
        campos[1], campos[2], campos[3], convertirBooleano(campos[4]),
        convertirEntero(campos[5]), campoOpcional(campos, 6),
        campoOpcional(campos, 7), campoOpcional(campos, 8),
        campoOpcional(campos, 9), campoOpcional(campos, 10),
        campoOpcional(campos, 11), campoOpcional(campos, 12),
        campoOpcional(campos, 13), campoOpcional(campos, 14),
        campoOpcional(campos, 15), campoOpcional(campos, 16),
        campoOpcional(campos, 17), campoOpcional(campos, 18),
        campoOpcional(campos, 19));
  }

#ifdef _WIN32

  // =========================================================
  // CONVERTIR NUMERO A TEXTO
  // =========================================================

  string numeroATexto(unsigned long numero) {

    ostringstream flujo;

    flujo << numero;

    return flujo.str();
  }

  // =========================================================
  // ESCAPAR TEXTO PARA JSON
  // =========================================================

  string escaparJson(const string &valor) {

    string salida;

    for (size_t i = 0; i < valor.size(); ++i) {

      unsigned char c = static_cast<unsigned char>(valor[i]);

      if (c == '"') {

        salida += "\\\"";
      } else if (c == '\\') {

        salida += "\\\\";
      } else if (c == '\n') {

        salida += "\\n";
      } else if (c == '\r') {

        salida += "\\r";
      } else if (c == '\t') {

        salida += "\\t";
      } else if (c < 32) {

        salida += ' ';
      } else {

        salida += static_cast<char>(c);
      }
    }

    return salida;
  }

  // =========================================================
  // CONVERTIR STRING A WSTRING
  // =========================================================

  wstring stringToWide(const string &texto) {

    int tamano = MultiByteToWideChar(CP_UTF8, 0, texto.c_str(), -1, NULL, 0);

    if (tamano == 0)
      return L"";

    vector<wchar_t> buffer(tamano);

    MultiByteToWideChar(CP_UTF8, 0, texto.c_str(), -1, &buffer[0], tamano);

    return wstring(&buffer[0]);
  }

  // =========================================================
  // OBTENER DIRECTORIO DEL EJECUTABLE
  // =========================================================

  string obtenerDirectorioEjecutable() {

    char ruta[MAX_PATH];

    DWORD longitud = GetModuleFileNameA(NULL, ruta, MAX_PATH);

    if (longitud == 0)
      return "";

    string completa(ruta, longitud);

    size_t posicion = completa.find_last_of("\\/");

    if (posicion == string::npos)
      return "";

    return completa.substr(0, posicion);
  }

  // =========================================================
  // COMPROBAR ARCHIVO
  // =========================================================

  bool archivoExiste(const string &ruta) {

    ifstream archivo(ruta.c_str());

    bool existe = archivo.is_open();

    archivo.close();

    return existe;
  }

  // =========================================================
  // OBTENER RUTA DEL SCRAPER
  // =========================================================

  string obtenerRutaScraper() {

    string directorio = obtenerDirectorioEjecutable();

    if (!directorio.empty()) {
      string c1 = directorio + "\\PEA-i-Scraper.exe";
      if (archivoExiste(c1))
        return c1;

      string c2 = directorio + "\\PEA-i.exe";
      if (archivoExiste(c2))
        return c2;

      string c3 = directorio + "\\scraper\\PEA-i-Scraper.exe";
      if (archivoExiste(c3))
        return c3;

      string c4 = directorio + "\\scraper\\PEA-i.exe";
      if (archivoExiste(c4))
        return c4;

      string c5 = directorio + "\\PEA-Scraper\\dist\\PEA-i.exe";
      if (archivoExiste(c5))
        return c5;

      string c6 = directorio + "\\PEA-Scraper\\PEA-i-Scraper.exe";
      if (archivoExiste(c6))
        return c6;

      string c7 = directorio + "\\PEA-Scraper\\PEA-i.exe";
      if (archivoExiste(c7))
        return c7;

      string c8 = directorio + "\\Python\\PEA-i-Scraper.exe";
      if (archivoExiste(c8))
        return c8;

      string c9 = directorio + "\\Python\\PEA-i.exe";
      if (archivoExiste(c9))
        return c9;
    }

    if (archivoExiste("PEA-i-Scraper.exe"))
      return "PEA-i-Scraper.exe";
    if (archivoExiste("PEA-i.exe"))
      return "PEA-i.exe";
    if (archivoExiste("scraper\\PEA-i-Scraper.exe"))
      return "scraper\\PEA-i-Scraper.exe";
    if (archivoExiste("scraper\\PEA-i.exe"))
      return "scraper\\PEA-i.exe";
    if (archivoExiste("PEA-Scraper\\dist\\PEA-i.exe"))
      return "PEA-Scraper\\dist\\PEA-i.exe";
    if (archivoExiste("PEA-Scraper\\PEA-i-Scraper.exe"))
      return "PEA-Scraper\\PEA-i-Scraper.exe";
    if (archivoExiste("PEA-Scraper\\PEA-i.exe"))
      return "PEA-Scraper\\PEA-i.exe";

    return "";
  }

  // =========================================================
  // INICIAR SCRAPER PYTHON
  // =========================================================

  bool iniciarScraperPython() {

#ifdef _WIN32
    registrarManejadorConsola();

    if (s_procesoScraper != NULL) {
      DWORD estado = WaitForSingleObject(s_procesoScraper, 0);

      if (estado == WAIT_TIMEOUT) {
        if (consultarHealth()) {
          return true;
        }
      }

      matarProcesoScraper();
    }

    STARTUPINFOA inicio;
    PROCESS_INFORMATION proceso;

    ZeroMemory(&inicio, sizeof(inicio));
    ZeroMemory(&proceso, sizeof(proceso));
    inicio.cb = sizeof(inicio);

    BOOL creado = FALSE;
    string ruta = "";

    if (archivoExiste("PEA-Scraper\\DLDD-MAFF-JDLA.py")) {
      string comandoPy = "python \"PEA-Scraper\\DLDD-MAFF-JDLA.py\" --api";
      vector<char> bufferPy(comandoPy.begin(), comandoPy.end());
      bufferPy.push_back('\0');
      creado = CreateProcessA(NULL, &bufferPy[0], NULL, NULL,
                              FALSE, CREATE_NO_WINDOW, NULL,
                              NULL, &inicio, &proceso);
    }

    if (!creado) {
      ruta = obtenerRutaScraper();

      if (ruta.empty()) {
        ultimoError =
            "No se encontro el ejecutable del scraper (PEA-i-Scraper.exe ni "
            "PEA-i.exe) ni el script PEA-Scraper\\DLDD-MAFF-JDLA.py.";
        return false;
      }

      string comando = "\"" + ruta + "\" --api";
      vector<char> bufferComando(comando.begin(), comando.end());
      bufferComando.push_back('\0');

      string directorio = ruta;
      size_t posicion = directorio.find_last_of("\\/");
      if (posicion != string::npos) {
        directorio = directorio.substr(0, posicion);
      } else {
        directorio = "";
      }

      LPCSTR directorioTrabajo = NULL;
      if (!directorio.empty()) {
        directorioTrabajo = directorio.c_str();
      }

      creado = CreateProcessA(ruta.c_str(), &bufferComando[0], NULL, NULL,
                              FALSE, CREATE_NO_WINDOW, NULL,
                              directorioTrabajo, &inicio, &proceso);
    }

    if (!creado) {
      ultimoError = "No se pudo iniciar el scraper. Error de Windows: " +
                    numeroATexto(static_cast<unsigned long>(GetLastError()));
      return false;
    }

    CloseHandle(proceso.hThread);

    procesoScraper = proceso.hProcess;
    s_procesoScraper = proceso.hProcess;
    s_pidScraper = proceso.dwProcessId;

    inicializarJobScraper();
    if (s_jobScraper != NULL) {
      AssignProcessToJobObject(s_jobScraper, proceso.hProcess);
    }

    return true;
#else
    ultimoError =
        "El inicio automatico del scraper esta preparado para Windows.";
    return false;
#endif
  }

  // =========================================================
  // LEER RESPUESTA HTTP
  // =========================================================

  bool leerRespuesta(HINTERNET solicitud, string &respuesta) {

    respuesta.clear();

    DWORD disponibles = 0;

    bool terminar = false;

    while (!terminar && WinHttpQueryDataAvailable(solicitud, &disponibles)) {

      if (disponibles == 0) {

        terminar = true;
      } else {

        vector<char> buffer(disponibles + 1);

        DWORD leidos = 0;

        BOOL leyo =
            WinHttpReadData(solicitud, &buffer[0], disponibles, &leidos);

        if (!leyo)
          return false;

        if (leidos == 0) {

          terminar = true;
        } else {

          respuesta.append(&buffer[0], leidos);
        }
      }
    }

    return true;
  }

  // =========================================================
  // CONSULTAR HEALTH
  // =========================================================

  bool consultarHealth() {

    HINTERNET sesion =
        WinHttpOpen(L"PEA-i-Cpp98/1.0", WINHTTP_ACCESS_TYPE_NO_PROXY,
                    WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);

    if (!sesion)
      return false;

    WinHttpSetTimeouts(sesion, 1000, 1000, 1000, 2000);

    HINTERNET conexion = WinHttpConnect(sesion, L"127.0.0.1", 8765, 0);

    if (!conexion) {

      WinHttpCloseHandle(sesion);

      return false;
    }

    HINTERNET solicitud =
        WinHttpOpenRequest(conexion, L"GET", L"/health", NULL,
                           WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);

    if (!solicitud) {

      WinHttpCloseHandle(conexion);

      WinHttpCloseHandle(sesion);

      return false;
    }

    BOOL enviado = WinHttpSendRequest(solicitud, WINHTTP_NO_ADDITIONAL_HEADERS,
                                      0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0);

    bool correcto = false;

    if (enviado) {

      BOOL recibido = WinHttpReceiveResponse(solicitud, NULL);

      if (recibido) {

        DWORD estado = 0;

        DWORD tamano = sizeof(estado);

        BOOL consultado = WinHttpQueryHeaders(
            solicitud, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &estado, &tamano,
            WINHTTP_NO_HEADER_INDEX);

        if (consultado && estado >= 200 && estado < 300) {

          correcto = true;
        }
      }
    }

    WinHttpCloseHandle(solicitud);

    WinHttpCloseHandle(conexion);

    WinHttpCloseHandle(sesion);

    return correcto;
  }

  // =========================================================
  // ESPERAR SERVIDOR PYTHON
  // =========================================================

  bool esperarServidor() {

    for (int intento = 0; intento < 50; ++intento) {

      if (procesoScraper != NULL &&
          WaitForSingleObject(procesoScraper, 0) == WAIT_OBJECT_0) {

        ultimoError = "PEA-i.exe termino antes de levantar la API.";

        return false;
      }

      if (consultarHealth())
        return true;

      Sleep(200);
    }

    ultimoError = "PEA-i.exe no respondio en localhost:8765.";

    return false;
  }

  // =========================================================
  // REALIZAR POST
  // =========================================================

  bool realizarPost(const string &ruta, const string &cuerpo,
                    string &respuesta) {

    respuesta.clear();

    HINTERNET sesion =
        WinHttpOpen(L"PEA-i-Cpp98/1.0", WINHTTP_ACCESS_TYPE_NO_PROXY,
                    WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);

    if (!sesion) {

      ultimoError = "WinHttpOpen fallo.";

      return false;
    }

    WinHttpSetTimeouts(sesion, 5000, 5000, 15000, 60000);

    HINTERNET conexion = WinHttpConnect(sesion, L"127.0.0.1", 8765, 0);

    if (!conexion) {

      ultimoError = "No se pudo conectar con localhost:8765.";

      WinHttpCloseHandle(sesion);

      return false;
    }

    wstring rutaWide = stringToWide(ruta);

    HINTERNET solicitud =
        WinHttpOpenRequest(conexion, L"POST", rutaWide.c_str(), NULL,
                           WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);

    if (!solicitud) {

      ultimoError = "No se pudo crear la solicitud HTTP.";

      WinHttpCloseHandle(conexion);

      WinHttpCloseHandle(sesion);

      return false;
    }

    const wchar_t *encabezados =
        L"Content-Type: application/json; charset=utf-8\r\n"
        L"Accept: text/plain\r\n";

    BOOL enviado = WinHttpSendRequest(
        solicitud, encabezados, static_cast<DWORD>(-1), (LPVOID)cuerpo.c_str(),
        static_cast<DWORD>(cuerpo.size()), static_cast<DWORD>(cuerpo.size()),
        0);

    bool correcto = false;

    if (!enviado) {

      ultimoError = "WinHttpSendRequest fallo.";
    } else {

      BOOL recibido = WinHttpReceiveResponse(solicitud, NULL);

      if (!recibido) {

        ultimoError = "WinHttpReceiveResponse fallo.";
      } else {

        DWORD estado = 0;

        DWORD tamano = sizeof(estado);

        BOOL consultado = WinHttpQueryHeaders(
            solicitud, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &estado, &tamano,
            WINHTTP_NO_HEADER_INDEX);

        if (!consultado) {

          ultimoError = "No fue posible obtener el codigo HTTP.";
        } else if (estado < 200 || estado >= 300) {

          ultimoError = "La API Python devolvio HTTP " +
                        numeroATexto(static_cast<unsigned long>(estado));

          leerRespuesta(solicitud, respuesta);
        } else {

          if (leerRespuesta(solicitud, respuesta)) {

            correcto = true;
          } else {

            ultimoError = "No se pudo leer la respuesta del scraper.";
          }
        }
      }
    }

    WinHttpCloseHandle(solicitud);

    WinHttpCloseHandle(conexion);

    WinHttpCloseHandle(sesion);

    return correcto;
  }

#endif

  // =========================================================
  // GUARDAR RESPUESTA RECIBIDA
  // =========================================================

  void guardarRespuestaBruta(const string &respuesta) {

    ofstream archivo("scraping_ultima_respuesta.txt",
                     ios::out | ios::trunc | ios::binary);

    if (archivo.is_open()) {
      archivo << respuesta;

      archivo.close();
    }
  }

  // =========================================================
  // AGREGAR AUTOR A PRODUCTO
  // =========================================================

  void agregarAutor(ProductoInvestigacion *producto,
                    const vector<string> &campos) {

    if (producto != NULL && campos.size() >= 2) {

      producto->autores.push_back(campos[1]);
    }
  }

  // =========================================================
  // PARSEAR INVESTIGADOR
  // =========================================================

  Investigador *parsearInvestigador(const string &respuesta) {

    stringstream flujo(respuesta);

    string linea;

    Investigador *investigador = NULL;

    ProductoInvestigacion *productoActual = NULL;

    bool estadoOk = false;

    bool tipoCorrecto = false;

    while (getline(flujo, linea)) {

      if (!linea.empty()) {

        vector<string> campos = separarCampos(linea);

        if (!campos.empty()) {

          if (campos[0] == "ESTADO") {

            if (campos.size() >= 2 && campos[1] == "OK")
              estadoOk = true;
          } else if (campos[0] == "ERROR") {

            if (campos.size() >= 2)
              ultimoError = campos[1];
          } else if (campos[0] == "TIPO") {

            if (campos.size() >= 2 && campos[1] == "INVESTIGADOR")
              tipoCorrecto = true;
          } else if (campos[0] == "INVESTIGADOR") {

            if (campos.size() >= 3) {

              investigador = new Investigador(
                  campos[1], campos[2], campoOpcional(campos, 3),
                  campoOpcional(campos, 4), campoOpcional(campos, 5),
                  campoOpcional(campos, 6), campoOpcional(campos, 7),
                  campoOpcional(campos, 8), campoOpcional(campos, 9));

              if (campos.size() >= 11)
                investigador->activo = convertirBooleano(campos[10]);
            }
          } else if (campos[0] == "NOMBRE_CITACIONES") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->nombreCitaciones = campos[1];
          } else if (campos[0] == "NACIONALIDAD") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->nacionalidad = campos[1];
          } else if (campos[0] == "SEXO") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->sexo = campos[1];
          } else if (campos[0] == "ESTADO_PAR_EVALUADOR") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->estadoParEvaluador = campos[1];
          } else if (campos[0] == "RESEARCHER_ID") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->researcherId = campos[1];
          } else if (campos[0] == "AUTOR_ID_SCOPUS") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->autorIdScopus = campos[1];
          } else if (campos[0] == "GOOGLE_SCHOLAR") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->googleScholar = campos[1];
          } else if (campos[0] == "RESEARCHGATE") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->researchGate = campos[1];
          } else if (campos[0] == "ACADEMIA_EDU") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->academiaEdu = campos[1];
          } else if (campos[0] == "MENDELEY") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->mendeley = campos[1];
          } else if (campos[0] == "LINKEDIN") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->linkedin = campos[1];
          } else if (campos[0] == "REPOSITORIO_INSTITUCIONAL") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->repositorioInstitucional = campos[1];
          } else if (campos[0] == "IDIOMA") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->idiomas.push_back(campos[1]);
          } else if (campos[0] == "AREA_CONOCIMIENTO") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->areasConocimiento.push_back(campos[1]);
          } else if (campos[0] == "LINEA_INVESTIGACION") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->lineasInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "FORMACION") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->formacionAcademica.push_back(campos[1]);
          } else if (campos[0] == "EXPERIENCIA") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->experienciaProfesional.push_back(campos[1]);
          } else if (campos[0] == "GRUPO_INVESTIGACION") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->gruposInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "SEMILLERO") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->semilleros.push_back(campos[1]);
          } else if (campos[0] == "PROYECTO") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->proyectos.push_back(campos[1]);
          } else if (campos[0] == "RECONOCIMIENTO") {

            if (investigador != NULL && campos.size() >= 2)
              investigador->reconocimientos.push_back(campos[1]);
          } else if (campos[0] == "PRODUCTO") {

            productoActual = productoDesdeCampos(campos);

            if (investigador != NULL && productoActual != NULL)
              investigador->agregarProducto(productoActual);
          } else if (campos[0] == "AUTOR") {

            agregarAutor(productoActual, campos);
          } else if (campos[0] == "PRODUCTO_FIN") {

            productoActual = NULL;
          }
        }
      }
    }

    if (!estadoOk || !tipoCorrecto || investigador == NULL) {

      if (investigador != NULL)
        delete investigador;

      return NULL;
    }

    return investigador;
  }

  // =========================================================
  // PARSEAR GRUPO
  // =========================================================

  bool parsearGrupo(const string &respuesta, GrupoInvestigacion *&grupo,
                    vector<Investigador *> &integrantes,
                    vector<ProductoInvestigacion *> &productos) {

    grupo = NULL;

    integrantes.clear();
    productos.clear();

    stringstream flujo(respuesta);

    string linea;

    Investigador *integranteActual = NULL;

    ProductoInvestigacion *productoActual = NULL;

    bool estadoOk = false;

    bool tipoCorrecto = false;

    while (getline(flujo, linea)) {

      if (!linea.empty()) {

        vector<string> campos = separarCampos(linea);

        if (!campos.empty()) {

          if (campos[0] == "ESTADO") {

            if (campos.size() >= 2 && campos[1] == "OK")
              estadoOk = true;
          } else if (campos[0] == "ERROR") {

            if (campos.size() >= 2)
              ultimoError = campos[1];
          } else if (campos[0] == "TIPO") {

            if (campos.size() >= 2 && campos[1] == "GRUPO")
              tipoCorrecto = true;
          } else if (campos[0] == "GRUPO") {

            if (campos.size() >= 3) {

              grupo = new GrupoInvestigacion(campos[1], campos[2]);
            }
          } else if (campos[0] == "ANIO_FORMACION") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->anioFormacion = campos[1];
          } else if (campos[0] == "DEPARTAMENTO") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->departamento = campos[1];
          } else if (campos[0] == "CIUDAD") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->ciudad = campos[1];
          } else if (campos[0] == "LIDER") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->lider = campos[1];
          } else if (campos[0] == "INFORMACION_CERTIFICADA") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->informacionCertificada = campos[1];
          } else if (campos[0] == "PAGINA_WEB") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->paginaWeb = campos[1];
          } else if (campos[0] == "EMAIL") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->email = campos[1];
          } else if (campos[0] == "CLASIFICACION") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->clasificacion = campos[1];
          } else if (campos[0] == "AREA_CONOCIMIENTO") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->areaConocimiento = campos[1];
          } else if (campos[0] == "PROGRAMA_NACIONAL_CTI") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->programaNacionalCti = campos[1];
          } else if (campos[0] == "PROGRAMA_NACIONAL_CTI_SECUNDARIO") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->programaNacionalCtiSecundario = campos[1];
          } else if (campos[0] == "PLAN_ESTRATEGICO") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->planEstrategico = campos[1];
          } else if (campos[0] == "ESTADO_ARTE") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->estadoArte = campos[1];
          } else if (campos[0] == "OBJETIVOS") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->objetivos = campos[1];
          } else if (campos[0] == "RETOS") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->retos = campos[1];
          } else if (campos[0] == "VISION") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->vision = campos[1];
          } else if (campos[0] == "INSTITUCION") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->instituciones.push_back(campos[1]);
          } else if (campos[0] == "LINEA_INVESTIGACION") {

            if (grupo != NULL && campos.size() >= 2)
              grupo->lineasInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE") {

            if (campos.size() >= 3) {

              integranteActual = new Investigador(
                  campos[1], campos[2], campoOpcional(campos, 3),
                  campoOpcional(campos, 4), campoOpcional(campos, 5),
                  campoOpcional(campos, 6), campoOpcional(campos, 7),
                  campoOpcional(campos, 8), campoOpcional(campos, 9));

              if (campos.size() >= 11)
                integranteActual->activo = convertirBooleano(campos[10]);

              integrantes.push_back(integranteActual);
            }
          } else if (campos[0] == "INTEGRANTE_NOMBRE_CITACIONES") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->nombreCitaciones = campos[1];
          } else if (campos[0] == "INTEGRANTE_NACIONALIDAD") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->nacionalidad = campos[1];
          } else if (campos[0] == "INTEGRANTE_SEXO") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->sexo = campos[1];
          } else if (campos[0] == "INTEGRANTE_ESTADO_PAR_EVALUADOR") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->estadoParEvaluador = campos[1];
          } else if (campos[0] == "INTEGRANTE_RESEARCHER_ID") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->researcherId = campos[1];
          } else if (campos[0] == "INTEGRANTE_AUTOR_ID_SCOPUS") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->autorIdScopus = campos[1];
          } else if (campos[0] == "INTEGRANTE_GOOGLE_SCHOLAR") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->googleScholar = campos[1];
          } else if (campos[0] == "INTEGRANTE_RESEARCHGATE") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->researchGate = campos[1];
          } else if (campos[0] == "INTEGRANTE_ACADEMIA_EDU") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->academiaEdu = campos[1];
          } else if (campos[0] == "INTEGRANTE_MENDELEY") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->mendeley = campos[1];
          } else if (campos[0] == "INTEGRANTE_LINKEDIN") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->linkedin = campos[1];
          } else if (campos[0] == "INTEGRANTE_REPOSITORIO_INSTITUCIONAL") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->repositorioInstitucional = campos[1];
          } else if (campos[0] == "INTEGRANTE_IDIOMA") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->idiomas.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_AREA") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->areasConocimiento.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_LINEA") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->lineasInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_FORMACION") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->formacionAcademica.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_EXPERIENCIA") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->experienciaProfesional.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_GRUPO") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->gruposInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_SEMILLERO") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->semilleros.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_PROYECTO") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->proyectos.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_RECONOCIMIENTO") {

            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->reconocimientos.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_PRODUCTO") {

            productoActual = productoDesdeCampos(campos);

            if (integranteActual != NULL && productoActual != NULL)
              integranteActual->agregarProducto(productoActual);
          } else if (campos[0] == "INTEGRANTE_FIN") {

            integranteActual = NULL;

            productoActual = NULL;
          } else if (campos[0] == "FIN_INTEGRANTE") {

            integranteActual = NULL;

            productoActual = NULL;
          } else if (campos[0] == "PRODUCTO") {

            productoActual = productoDesdeCampos(campos);

            if (productoActual != NULL)
              productos.push_back(productoActual);
          } else if (campos[0] == "AUTOR") {

            agregarAutor(productoActual, campos);
          } else if (campos[0] == "PRODUCTO_FIN") {

            productoActual = NULL;
          }
        }
      }
    }

    if (!estadoOk || !tipoCorrecto || grupo == NULL) {

      if (grupo != NULL) {

        delete grupo;

        grupo = NULL;
      }

      for (size_t i = 0; i < integrantes.size(); ++i) {

        delete integrantes[i];
      }

      for (size_t i = 0; i < productos.size(); ++i) {

        delete productos[i];
      }

      integrantes.clear();
      productos.clear();

      if (ultimoError.empty())
        ultimoError = "La respuesta de Python no contiene un grupo valido.";

      return false;
    }

    return true;
  }

public:
#ifdef _WIN32

  LectorArchivosYWeb() : ultimoError(""), procesoScraper(NULL) {}

  ~LectorArchivosYWeb() { cerrarScraperNormal(); }

  static void registrarManejadorConsola() {
    if (!s_manejadorRegistrado) {
      SetConsoleCtrlHandler(ManejadorConsola, TRUE);
      atexit(cerrarScraperAlSalir);
      s_manejadorRegistrado = true;
    }
  }

  static void cerrarScraperAlSalir() {
    if (s_procesoScraper != NULL || s_pidScraper != 0) {
      cerrarScraperNormal();
    }
  }

  static void cerrarScraperNormal() {
    if (!(s_procesoScraper == NULL && s_pidScraper == 0)) {
      s_ultimoTipoCierre = "CIERRE_NORMAL (Desde menu principal)";
      registrarEventoCierre(
          "CIERRE_NORMAL",
          "Salida ordenada del sistema desde el menu principal (Opcion 6).");
      matarProcesoScraper();
    }
  }

  static void cerrarScraperForzado(DWORD tipoControl) {
    s_ultimoTipoCierre = "CIERRE_FORZADO (Ventana cerrada con la 'X' o senal)";
    string motivo = "Cierre forzado de la ventana de consola.";
    if (tipoControl == CTRL_CLOSE_EVENT) {
      motivo = "Ventana de consola cerrada directamente con la 'X' de Windows "
               "(CTRL_CLOSE_EVENT).";
    } else if (tipoControl == CTRL_C_EVENT) {
      motivo =
          "Interrupcion forzada mediante CTRL+C por el usuario (CTRL_C_EVENT).";
    } else if (tipoControl == CTRL_BREAK_EVENT) {
      motivo = "Interrupcion forzada CTRL+BREAK (CTRL_BREAK_EVENT).";
    } else if (tipoControl == CTRL_SHUTDOWN_EVENT ||
               tipoControl == CTRL_LOGOFF_EVENT) {
      motivo =
          "Cierre de sesion o apagado forzado del sistema operativo Windows.";
    }

    registrarEventoCierre("CIERRE_FORZADO", motivo);
    matarProcesoScraper();
  }

  bool estaScraperActivo() const {
    if (s_procesoScraper == NULL && s_pidScraper == 0) {
      return false;
    }
    if (s_procesoScraper != NULL) {
      DWORD codigoSalida = 0;
      if (GetExitCodeProcess(s_procesoScraper, &codigoSalida) &&
          codigoSalida == STILL_ACTIVE) {
        return true;
      }
    }
    return false;
  }

  DWORD obtenerPidScraper() const { return s_pidScraper; }

  string obtenerUltimoTipoCierre() const { return s_ultimoTipoCierre; }

  vector<string> obtenerUltimosRegistrosLog(int maxLineas) const {
    vector<string> lineas;
    ifstream archivo("scraper_cierre.log");
    if (!archivo.is_open()) {
      lineas.push_back(
          "Sin historial registrado todavia en scraper_cierre.log");
      return lineas;
    }
    string l;
    vector<string> todas;
    while (getline(archivo, l)) {
      if (!l.empty()) {
        todas.push_back(l);
      }
    }
    archivo.close();
    if (todas.empty()) {
      lineas.push_back("El archivo scraper_cierre.log esta vacio.");
      return lineas;
    }
    int inicio = static_cast<int>(todas.size()) - maxLineas;
    if (inicio < 0)
      inicio = 0;
    for (size_t i = static_cast<size_t>(inicio); i < todas.size(); ++i) {
      lineas.push_back(todas[i]);
    }
    return lineas;
  }

#else

  LectorArchivosYWeb() : ultimoError("") {}

  ~LectorArchivosYWeb() {}

  static void registrarManejadorConsola() {}
  static void cerrarScraperAlSalir() {}
  static void cerrarScraperNormal() {}
  static void cerrarScraperForzado(int) {}
  bool estaScraperActivo() const { return false; }
  unsigned long obtenerPidScraper() const { return 0; }
  string obtenerUltimoTipoCierre() const { return "N/A"; }
  vector<string> obtenerUltimosRegistrosLog(int) const {
    vector<string> v;
    v.push_back("No disponible en sistemas no Windows.");
    return v;
  }

#endif

  // ---------------------------------------------------------
  // OBTENER ULTIMO ERROR
  // ---------------------------------------------------------

  string getUltimoError() const { return ultimoError; }

  string getRutaScraper() {

#ifdef _WIN32

    return obtenerRutaScraper();

#else

    return "";

#endif
  }

  // ---------------------------------------------------------
  // VALIDACION DE URLS DE MINCIENCIAS (CvLAC Y GrupLAC)
  // ---------------------------------------------------------

  static string limpiarEspaciosTexto(const string &texto) {
    size_t inicio = 0;
    while (inicio < texto.size() &&
           (texto[inicio] == ' ' || texto[inicio] == '\t' ||
            texto[inicio] == '\r' || texto[inicio] == '\n')) {
      inicio++;
    }
    if (inicio >= texto.size()) {
      return "";
    }
    size_t fin = texto.size() - 1;
    while (fin > inicio && (texto[fin] == ' ' || texto[fin] == '\t' ||
                            texto[fin] == '\r' || texto[fin] == '\n')) {
      fin--;
    }
    return texto.substr(inicio, fin - inicio + 1);
  }

  static string aMinusculasTexto(const string &texto) {
    string resultado = texto;
    for (size_t i = 0; i < resultado.size(); ++i) {
      char c = resultado[i];
      if (c >= 'A' && c <= 'Z') {
        resultado[i] = static_cast<char>(c + ('a' - 'A'));
      }
    }
    return resultado;
  }

  static string sanitizarRutaArchivo(const string &texto) {
    string limpia = limpiarEspaciosTexto(texto);
    if (limpia.size() >= 2) {
      char primero = limpia[0];
      char ultimo = limpia[limpia.size() - 1];
      if ((primero == '"' && ultimo == '"') || (primero == '\'' && ultimo == '\'')) {
        limpia = limpia.substr(1, limpia.size() - 2);
        limpia = limpiarEspaciosTexto(limpia);
      }
    }
    return limpia;
  }

  static bool validarUrlMinciencias(const string &tipo,
                                    const string &urlOriginal,
                                    string &urlNormalizada,
                                    string &mensajeError) {
    urlNormalizada.clear();
    mensajeError.clear();

    string urlLimpia = limpiarEspaciosTexto(urlOriginal);
    if (urlLimpia.empty()) {
      mensajeError = "Debe ingresar una URL para procesar la carga.";
      return false;
    }

    string urlConProtocolo = urlLimpia;
    string urlMinTemp = aMinusculasTexto(urlLimpia);
    if (urlMinTemp.substr(0, 7) != "http://" &&
        urlMinTemp.substr(0, 8) != "https://") {
      urlConProtocolo = "https://" + urlLimpia;
    }

    string urlMinus = aMinusculasTexto(urlConProtocolo);

    string sinProto = urlMinus;
    if (sinProto.substr(0, 8) == "https://") {
      sinProto = sinProto.substr(8);
    } else if (sinProto.substr(0, 7) == "http://") {
      sinProto = sinProto.substr(7);
    }

    size_t posFinHost = sinProto.find_first_of("/?#:");
    string host;
    if (posFinHost == string::npos) {
      host = sinProto;
    } else {
      host = sinProto.substr(0, posFinHost);
    }

    if (host != "scienti.minciencias.gov.co") {
      mensajeError = "URL invalida: El enlace debe pertenecer al dominio "
                     "oficial 'scienti.minciencias.gov.co'.";
      return false;
    }

    string tipoMin = aMinusculasTexto(tipo);

    if (tipoMin == "investigador") {
      if (urlMinus.find("/gruplac") != string::npos) {
        mensajeError =
            "Incompatibilidad de tipo: La URL ingresada corresponde a un grupo "
            "(GrupLAC) y no a un investigador (CvLAC). Seleccione la opcion de "
            "cargar grupo si desea registrar este enlace.";
        return false;
      }
      if (urlMinus.find("/cvlac") == string::npos) {
        mensajeError =
            "URL de investigador invalida: El enlace debe corresponder a un "
            "perfil CvLAC (debe contener '/cvlac').";
        return false;
      }
    } else if (tipoMin == "grupo") {
      if (urlMinus.find("/cvlac") != string::npos) {
        mensajeError =
            "Incompatibilidad de tipo: La URL ingresada corresponde a un "
            "investigador (CvLAC) y no a un grupo (GrupLAC). Seleccione la "
            "opcion de cargar investigador si desea registrar este enlace.";
        return false;
      }
      if (urlMinus.find("/gruplac") == string::npos) {
        mensajeError = "URL de grupo invalida: El enlace debe corresponder a "
                       "un grupo GrupLAC (debe contener '/gruplac').";
        return false;
      }
    } else {
      mensajeError = "Tipo de entidad no reconocido: '" + tipo + "'.";
      return false;
    }

    urlNormalizada = urlConProtocolo;
    return true;
  }

  // ---------------------------------------------------------
  // CARGAR INVESTIGADOR DESDE CVLAC
  // ---------------------------------------------------------

  Investigador *cargarInvestigadorDesdeWeb(const string &url) {

    string urlNormalizada;
    string errorValidacion;
    if (!validarUrlMinciencias("investigador", url, urlNormalizada,
                               errorValidacion)) {
      ultimoError = errorValidacion;
      gotoxy(15, 11);
      cout << "Validacion de URL fallida:        ";
      gotoxy(15, 12);
      cout << "URL: " << url;
      gotoxy(15, 13);
      cout << "Error: " << ultimoError;
      return NULL;
    }

    gotoxy(15, 11);
    cout << "Cargando investigador desde CvLAC...";

    gotoxy(15, 12);
    cout << "URL: " << urlNormalizada;

#ifdef _WIN32

    ultimoError = "";

    if (!iniciarScraperPython()) {

      gotoxy(15, 13);
      cout << "Error: " << ultimoError;

      return NULL;
    }

    if (!esperarServidor()) {

      gotoxy(15, 13);
      cout << "Error: " << ultimoError;

      return NULL;
    }

    string cuerpo = "{\"tipoBusqueda\":\"investigador\","
                    "\"url\":\"" +
                    escaparJson(urlNormalizada) + "\"}";

    string respuesta;

    if (!realizarPost("/scraping", cuerpo, respuesta)) {

      gotoxy(15, 13);
      cout << "Error: " << ultimoError;

      return NULL;
    }

    guardarRespuestaBruta(respuesta);

    Investigador *investigador = parsearInvestigador(respuesta);

    if (investigador == NULL) {

      if (ultimoError.empty())
        ultimoError = "No se pudo interpretar la respuesta del scraper.";

      gotoxy(15, 13);
      cout << "Error: " << ultimoError;

      return NULL;
    }

    return investigador;

#else

    (void)url;

    ultimoError = "El puente HTTP del scraper esta preparado para Windows.";

    gotoxy(15, 13);
    cout << "Error: " << ultimoError;

    return NULL;

#endif
  }

  // ---------------------------------------------------------
  // CARGAR GRUPO DESDE GRUPLAC
  // ---------------------------------------------------------

  bool cargarGrupoDesdeWeb(const string &url, GrupoInvestigacion *&grupo,
                           vector<Investigador *> &integrantes,
                           vector<ProductoInvestigacion *> &productos) {

    string urlNormalizada;
    string errorValidacion;
    if (!validarUrlMinciencias("grupo", url, urlNormalizada, errorValidacion)) {
      ultimoError = errorValidacion;
      grupo = NULL;
      integrantes.clear();
      productos.clear();
      gotoxy(15, 11);
      cout << "Validacion de URL fallida:        ";
      gotoxy(15, 12);
      cout << "URL: " << url;
      gotoxy(15, 13);
      cout << "Error: " << ultimoError;
      return false;
    }

    gotoxy(15, 11);
    cout << "Cargando grupo desde GrupLAC...";

    gotoxy(15, 12);
    cout << "URL: " << urlNormalizada;

#ifdef _WIN32

    ultimoError = "";

    grupo = NULL;

    integrantes.clear();
    productos.clear();

    if (!iniciarScraperPython()) {

      gotoxy(15, 13);
      cout << "Error: " << ultimoError;

      return false;
    }

    if (!esperarServidor()) {

      gotoxy(15, 13), cout << "Error: " << ultimoError;

      return false;
    }

    string cuerpo = "{\"tipoBusqueda\":\"grupo\","
                    "\"url\":\"" +
                    escaparJson(urlNormalizada) + "\"}";

    string respuesta;

    if (!realizarPost("/scraping", cuerpo, respuesta)) {

      gotoxy(15, 13);
      cout << "Error: " << ultimoError;

      return false;
    }

    guardarRespuestaBruta(respuesta);

    if (!parsearGrupo(respuesta, grupo, integrantes, productos)) {

      if (ultimoError.empty())
        ultimoError = "No se pudo interpretar la respuesta del scraper.";

      gotoxy(15, 13);
      cout << "Error: " << ultimoError;

      return false;
    }

    return true;

#else

    (void)url;
    (void)grupo;
    (void)integrantes;
    (void)productos;

    ultimoError = "El puente HTTP del scraper esta preparado para Windows.";

    gotoxy(15, 13);
    cout << "Error: " << ultimoError;

    return false;

#endif
  }

  // ---------------------------------------------------------
  // CARGAR DESDE ARCHIVO (PUENTE HTTP CON PYTHON)
  // ---------------------------------------------------------

  bool cargarDesdeArchivo(const string &tipoArchivo, const string &rutaArchivo,
                          string &respuesta) {
#ifdef _WIN32
    ultimoError = "";

    if (!iniciarScraperPython()) {
      return false;
    }

    if (!esperarServidor()) {
      return false;
    }

    string cuerpo = "{\"tipoArchivo\":\"" + escaparJson(tipoArchivo) +
                    "\",\"ruta\":\"" + escaparJson(rutaArchivo) + "\"}";

    if (!realizarPost("/cargar-archivo", cuerpo, respuesta)) {
      return false;
    }

    guardarRespuestaBruta(respuesta);
    return true;
#else
    (void)tipoArchivo;
    (void)rutaArchivo;
    (void)respuesta;
    ultimoError = "El puente HTTP del scraper esta preparado para Windows.";
    return false;
#endif
  }

  // ---------------------------------------------------------
  // PARSEAR LOTE (MULTIPLES GRUPOS E INVESTIGADORES)
  // ---------------------------------------------------------

  bool parsearLote(const string &respuesta,
                   vector<GrupoInvestigacion *> &grupos,
                   vector<vector<Investigador *> > &integrantesGrupos,
                   vector<vector<ProductoInvestigacion *> > &productosGrupos,
                   vector<Investigador *> &investigadores) {

    grupos.clear();
    integrantesGrupos.clear();
    productosGrupos.clear();
    investigadores.clear();

    stringstream flujo(respuesta);
    string linea;

    GrupoInvestigacion *grupoActual = NULL;
    vector<Investigador *> integrantesActuales;
    vector<ProductoInvestigacion *> productosActuales;
    Investigador *integranteActual = NULL;

    Investigador *investigadorActual = NULL;
    ProductoInvestigacion *productoActual = NULL;

    bool estadoOk = false;
    bool esInvestigadorUnico = false;
    bool esGrupoUnico = false;

    while (getline(flujo, linea)) {
      if (!linea.empty()) {
        vector<string> campos = separarCampos(linea);
        if (!campos.empty()) {
          if (campos[0] == "ESTADO") {
            if (campos.size() >= 2 && campos[1] == "OK") {
              estadoOk = true;
            }
          } else if (campos[0] == "ERROR") {
            if (campos.size() >= 2) {
              ultimoError = campos[1];
            }
          } else if (campos[0] == "TIPO") {
            if (campos.size() >= 2) {
              if (campos[1] == "INVESTIGADOR") {
                esInvestigadorUnico = true;
              } else if (campos[1] == "GRUPO") {
                esGrupoUnico = true;
              }
            }
          } else if (campos[0] == "GRUPO") {
            if (campos.size() >= 3) {
              grupoActual = new GrupoInvestigacion(campos[1], campos[2]);
              integrantesActuales.clear();
              productosActuales.clear();
              integranteActual = NULL;
              productoActual = NULL;
            }
          } else if (campos[0] == "ANIO_FORMACION") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->anioFormacion = campos[1];
          } else if (campos[0] == "DEPARTAMENTO") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->departamento = campos[1];
            else if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->departamento = campos[1];
          } else if (campos[0] == "CIUDAD") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->ciudad = campos[1];
            else if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->ciudad = campos[1];
          } else if (campos[0] == "LIDER") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->lider = campos[1];
          } else if (campos[0] == "INFORMACION_CERTIFICADA") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->informacionCertificada = campos[1];
          } else if (campos[0] == "PAGINA_WEB") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->paginaWeb = campos[1];
          } else if (campos[0] == "EMAIL") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->email = campos[1];
          } else if (campos[0] == "CLASIFICACION") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->clasificacion = campos[1];
          } else if (campos[0] == "AREA_CONOCIMIENTO") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->areaConocimiento = campos[1];
            else if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->areasConocimiento.push_back(campos[1]);
          } else if (campos[0] == "PROGRAMA_NACIONAL_CTI") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->programaNacionalCti = campos[1];
          } else if (campos[0] == "PROGRAMA_NACIONAL_CTI_SECUNDARIO") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->programaNacionalCtiSecundario = campos[1];
          } else if (campos[0] == "PLAN_ESTRATEGICO") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->planEstrategico = campos[1];
          } else if (campos[0] == "ESTADO_ARTE") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->estadoArte = campos[1];
          } else if (campos[0] == "OBJETIVOS") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->objetivos = campos[1];
          } else if (campos[0] == "RETOS") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->retos = campos[1];
          } else if (campos[0] == "VISION") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->vision = campos[1];
          } else if (campos[0] == "INSTITUCION") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->instituciones.push_back(campos[1]);
          } else if (campos[0] == "LINEA_INVESTIGACION") {
            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->lineasInvestigacion.push_back(campos[1]);
            else if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->lineasInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE") {
            if (campos.size() >= 3) {
              integranteActual = new Investigador(
                  campos[1], campos[2], campoOpcional(campos, 3),
                  campoOpcional(campos, 4), campoOpcional(campos, 5),
                  campoOpcional(campos, 6), campoOpcional(campos, 7),
                  campoOpcional(campos, 8), campoOpcional(campos, 9));
              if (campos.size() >= 11)
                integranteActual->activo = convertirBooleano(campos[10]);
              integrantesActuales.push_back(integranteActual);
              productoActual = NULL;
            }
          } else if (campos[0] == "INTEGRANTE_NOMBRE_CITACIONES") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->nombreCitaciones = campos[1];
          } else if (campos[0] == "INTEGRANTE_NACIONALIDAD") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->nacionalidad = campos[1];
          } else if (campos[0] == "INTEGRANTE_SEXO") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->sexo = campos[1];
          } else if (campos[0] == "INTEGRANTE_ESTADO_PAR_EVALUADOR") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->estadoParEvaluador = campos[1];
          } else if (campos[0] == "INTEGRANTE_RESEARCHER_ID") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->researcherId = campos[1];
          } else if (campos[0] == "INTEGRANTE_AUTOR_ID_SCOPUS") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->autorIdScopus = campos[1];
          } else if (campos[0] == "INTEGRANTE_GOOGLE_SCHOLAR") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->googleScholar = campos[1];
          } else if (campos[0] == "INTEGRANTE_RESEARCHGATE") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->researchGate = campos[1];
          } else if (campos[0] == "INTEGRANTE_ACADEMIA_EDU") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->academiaEdu = campos[1];
          } else if (campos[0] == "INTEGRANTE_MENDELEY") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->mendeley = campos[1];
          } else if (campos[0] == "INTEGRANTE_LINKEDIN") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->linkedin = campos[1];
          } else if (campos[0] == "INTEGRANTE_REPOSITORIO_INSTITUCIONAL") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->repositorioInstitucional = campos[1];
          } else if (campos[0] == "INTEGRANTE_IDIOMA") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->idiomas.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_FORMACION") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->formacionAcademica.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_EXPERIENCIA") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->experienciaProfesional.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_GRUPO") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->gruposInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_SEMILLERO") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->semilleros.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_PROYECTO") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->proyectos.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_RECONOCIMIENTO") {
            if (integranteActual != NULL && campos.size() >= 2)
              integranteActual->reconocimientos.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_PRODUCTO") {
            productoActual = productoDesdeCampos(campos);
            if (integranteActual != NULL && productoActual != NULL)
              integranteActual->agregarProducto(productoActual);
          } else if (campos[0] == "FIN_INTEGRANTE" || campos[0] == "INTEGRANTE_FIN") {
            integranteActual = NULL;
            productoActual = NULL;
          } else if (campos[0] == "FIN_GRUPO") {
            if (grupoActual != NULL) {
              grupos.push_back(grupoActual);
              integrantesGrupos.push_back(integrantesActuales);
              productosGrupos.push_back(productosActuales);
              grupoActual = NULL;
              integrantesActuales.clear();
              productosActuales.clear();
            }
            productoActual = NULL;
          } else if (campos[0] == "INVESTIGADOR") {
            if (campos.size() >= 3) {
              investigadorActual = new Investigador(
                  campos[1], campos[2], campoOpcional(campos, 3),
                  campoOpcional(campos, 4), campoOpcional(campos, 5),
                  campoOpcional(campos, 6), campoOpcional(campos, 7),
                  campoOpcional(campos, 8), campoOpcional(campos, 9));
              if (campos.size() >= 11)
                investigadorActual->activo = convertirBooleano(campos[10]);
              productoActual = NULL;
            }
          } else if (campos[0] == "NOMBRE_CITACIONES") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->nombreCitaciones = campos[1];
          } else if (campos[0] == "NACIONALIDAD") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->nacionalidad = campos[1];
          } else if (campos[0] == "SEXO") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->sexo = campos[1];
          } else if (campos[0] == "ESTADO_PAR_EVALUADOR") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->estadoParEvaluador = campos[1];
          } else if (campos[0] == "RESEARCHER_ID") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->researcherId = campos[1];
          } else if (campos[0] == "AUTOR_ID_SCOPUS") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->autorIdScopus = campos[1];
          } else if (campos[0] == "GOOGLE_SCHOLAR") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->googleScholar = campos[1];
          } else if (campos[0] == "RESEARCHGATE") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->researchGate = campos[1];
          } else if (campos[0] == "ACADEMIA_EDU") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->academiaEdu = campos[1];
          } else if (campos[0] == "MENDELEY") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->mendeley = campos[1];
          } else if (campos[0] == "LINKEDIN") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->linkedin = campos[1];
          } else if (campos[0] == "REPOSITORIO_INSTITUCIONAL") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->repositorioInstitucional = campos[1];
          } else if (campos[0] == "IDIOMA") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->idiomas.push_back(campos[1]);
          } else if (campos[0] == "FORMACION") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->formacionAcademica.push_back(campos[1]);
          } else if (campos[0] == "EXPERIENCIA") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->experienciaProfesional.push_back(campos[1]);
          } else if (campos[0] == "GRUPO_INVESTIGACION") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->gruposInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "SEMILLERO") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->semilleros.push_back(campos[1]);
          } else if (campos[0] == "PROYECTO") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->proyectos.push_back(campos[1]);
          } else if (campos[0] == "RECONOCIMIENTO") {
            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->reconocimientos.push_back(campos[1]);
          } else if (campos[0] == "PRODUCTO") {
            productoActual = productoDesdeCampos(campos);
            if (productoActual != NULL) {
              if (grupoActual != NULL) {
                productosActuales.push_back(productoActual);
              } else if (investigadorActual != NULL) {
                investigadorActual->agregarProducto(productoActual);
              }
            }
          } else if (campos[0] == "AUTOR") {
            agregarAutor(productoActual, campos);
          } else if (campos[0] == "PRODUCTO_FIN") {
            productoActual = NULL;
          } else if (campos[0] == "FIN_INVESTIGADOR") {
            if (investigadorActual != NULL) {
              investigadores.push_back(investigadorActual);
              investigadorActual = NULL;
            }
            productoActual = NULL;
          }
        }
      }
    }

    if (grupoActual != NULL) {
      grupos.push_back(grupoActual);
      integrantesGrupos.push_back(integrantesActuales);
      productosGrupos.push_back(productosActuales);
      grupoActual = NULL;
      integrantesActuales.clear();
      productosActuales.clear();
    }
    if (investigadorActual != NULL) {
      investigadores.push_back(investigadorActual);
      investigadorActual = NULL;
    }

    if (esInvestigadorUnico && investigadores.empty()) {
      Investigador *soloInv = parsearInvestigador(respuesta);
      if (soloInv != NULL) {
        investigadores.push_back(soloInv);
      }
    } else if (esGrupoUnico && grupos.empty()) {
      GrupoInvestigacion *soloGrp = NULL;
      vector<Investigador *> integs;
      vector<ProductoInvestigacion *> prods;
      if (parsearGrupo(respuesta, soloGrp, integs, prods) && soloGrp != NULL) {
        grupos.push_back(soloGrp);
        integrantesGrupos.push_back(integs);
        productosGrupos.push_back(prods);
      }
    }

    if (!estadoOk || (grupos.empty() && investigadores.empty())) {
      if (ultimoError.empty()) {
        ultimoError =
            "No se pudieron extraer entidades validas de la respuesta.";
      }
      return false;
    }

    return true;
  }
};

#ifdef _WIN32
HANDLE LectorArchivosYWeb::s_procesoScraper = NULL;
DWORD LectorArchivosYWeb::s_pidScraper = 0;
HANDLE LectorArchivosYWeb::s_jobScraper = NULL;
bool LectorArchivosYWeb::s_manejadorRegistrado = false;
string LectorArchivosYWeb::s_ultimoTipoCierre =
    "NINGUNO (Aun no iniciado o activo)";
#endif

// =========================================================================
// PERSISTENCIA DE ARCHIVOS
// =========================================================================

class PersistenciaArchivos {

private:
  const string ARCHIVO_INVESTIGADORES;
  const string ARCHIVO_GRUPOS;

  // =========================================================
  // SEPARAR CAMPOS DE UNA LINEA
  // =========================================================

  vector<string> separarCampos(const string &linea) {

    vector<string> campos;
    string campo;

    for (size_t i = 0; i < linea.size(); ++i) {

      if (linea[i] == '\t') {

        campos.push_back(campo);

        campo = "";
      } else {

        campo += linea[i];
      }
    }

    campos.push_back(campo);

    return campos;
  }

  // =========================================================
  // CONVERTIR TEXTO A BOOLEANO
  // =========================================================

  bool convertirBooleano(const string &valor) {

    return valor == "1" || valor == "true" || valor == "TRUE" ||
           valor == "si" || valor == "SI";
  }

  // =========================================================
  // BOOLEANO A TEXTO
  // =========================================================

  string booleanoATexto(bool valor) {

    if (valor)
      return "1";

    return "0";
  }

  // =========================================================
  // SANITIZAR TEXTO
  // =========================================================

  string sanitizar(const string &valor) {

    string salida = valor;

    for (size_t i = 0; i < salida.size(); ++i) {

      if (salida[i] == '\t' || salida[i] == '\r' || salida[i] == '\n') {

        salida[i] = ' ';
      }
    }

    return salida;
  }

  // =========================================================
  // OBTENER CAMPO OPCIONAL
  // =========================================================

  string campoOpcional(const vector<string> &campos, size_t indice) {

    if (indice < campos.size())
      return campos[indice];

    return "";
  }

  // =========================================================
  // ESCRIBIR LISTA
  // =========================================================

  void escribirLista(ofstream &archivo, const string &etiqueta,
                     const vector<string> &lista) {

    for (size_t i = 0; i < lista.size(); ++i) {

      archivo << etiqueta << '\t' << sanitizar(lista[i]) << "\n";
    }
  }

  // =========================================================
  // ESCRIBIR PRODUCTO
  // =========================================================

  void escribirProducto(ofstream &archivo, const string &etiqueta,
                        ProductoInvestigacion *producto) {

    if (producto) {

      archivo << etiqueta << '\t' << sanitizar(producto->idProducto) << '\t'
              << sanitizar(producto->titulo) << '\t'
              << sanitizar(producto->categoria) << '\t'
              << booleanoATexto(producto->validado) << '\t' << producto->anio
              << '\t' << sanitizar(producto->tipoProducto) << '\t'
              << sanitizar(producto->subtipo) << '\t'
              << sanitizar(producto->doi) << '\t' << sanitizar(producto->isbn)
              << '\t' << sanitizar(producto->revista) << '\t'
              << sanitizar(producto->editorial) << '\t'
              << sanitizar(producto->disponibilidad) << '\t'
              << sanitizar(producto->institucion) << '\t'
              << sanitizar(producto->ciudad) << '\t'
              << sanitizar(producto->pais) << '\t'
              << sanitizar(producto->numeroContrato) << '\t'
              << sanitizar(producto->descripcion) << '\t'
              << sanitizar(producto->palabrasClave) << '\t'
              << sanitizar(producto->areas) << "\n";

      escribirLista(archivo, "AUTOR", producto->autores);

      archivo << "PRODUCTO_FIN\n";
    }
  }

public:
  PersistenciaArchivos()
      : ARCHIVO_INVESTIGADORES("investigadores.txt"),
        ARCHIVO_GRUPOS("grupos.txt") {}

  // =========================================================
  // VERIFICACION DE EXISTENCIA DE ARCHIVOS
  // =========================================================

  bool existeArchivo(const string &ruta) const {
    ifstream archivo(ruta.c_str());
    return archivo.is_open();
  }

  bool existeArchivoInvestigadores() const {
    return existeArchivo(ARCHIVO_INVESTIGADORES);
  }

  bool existeArchivoGrupos() const { return existeArchivo(ARCHIVO_GRUPOS); }

  bool existenArchivosPersistencia() const {
    return existeArchivoInvestigadores() && existeArchivoGrupos();
  }

  string getArchivoInvestigadores() const { return ARCHIVO_INVESTIGADORES; }

  string getArchivoGrupos() const { return ARCHIVO_GRUPOS; }

  // =========================================================
  // GUARDAR INVESTIGADORES
  // =========================================================

  bool guardarInvestigadores(ListaInvestigadores &lista) {

    ofstream archivo(ARCHIVO_INVESTIGADORES.c_str(), ios::trunc);

    if (!archivo.is_open()) {
      return false;
    }

    archivo << "TIPO\tINVESTIGADORES\n";

    NodoInvestigador *actual = lista.getCabeza();

    while (actual) {

      Investigador *inv = actual->investigador;

      archivo << "INVESTIGADOR\t" << sanitizar(inv->codigoRh) << '\t'
              << sanitizar(inv->nombre) << '\t' << sanitizar(inv->correo)
              << '\t' << sanitizar(inv->orcid) << '\t'
              << sanitizar(inv->institucion) << '\t'
              << sanitizar(inv->departamento) << '\t' << sanitizar(inv->ciudad)
              << '\t' << sanitizar(inv->categoriaInvestigador) << '\t'
              << sanitizar(inv->perfil) << '\t' << booleanoATexto(inv->activo)
              << "\n";

      archivo << "NOMBRE_CITACIONES\t" << sanitizar(inv->nombreCitaciones)
              << "\n";
      archivo << "NACIONALIDAD\t" << sanitizar(inv->nacionalidad) << "\n";
      archivo << "SEXO\t" << sanitizar(inv->sexo) << "\n";
      archivo << "ESTADO_PAR_EVALUADOR\t" << sanitizar(inv->estadoParEvaluador)
              << "\n";
      archivo << "RESEARCHER_ID\t" << sanitizar(inv->researcherId) << "\n";
      archivo << "AUTOR_ID_SCOPUS\t" << sanitizar(inv->autorIdScopus) << "\n";
      archivo << "GOOGLE_SCHOLAR\t" << sanitizar(inv->googleScholar) << "\n";
      archivo << "RESEARCHGATE\t" << sanitizar(inv->researchGate) << "\n";
      archivo << "ACADEMIA_EDU\t" << sanitizar(inv->academiaEdu) << "\n";
      archivo << "MENDELEY\t" << sanitizar(inv->mendeley) << "\n";
      archivo << "LINKEDIN\t" << sanitizar(inv->linkedin) << "\n";
      archivo << "REPOSITORIO_INSTITUCIONAL\t"
              << sanitizar(inv->repositorioInstitucional) << "\n";

      escribirLista(archivo, "IDIOMA", inv->idiomas);

      escribirLista(archivo, "AREA_CONOCIMIENTO", inv->areasConocimiento);

      escribirLista(archivo, "LINEA_INVESTIGACION", inv->lineasInvestigacion);

      escribirLista(archivo, "FORMACION", inv->formacionAcademica);

      escribirLista(archivo, "EXPERIENCIA", inv->experienciaProfesional);

      escribirLista(archivo, "GRUPO_INVESTIGACION", inv->gruposInvestigacion);

      escribirLista(archivo, "SEMILLERO", inv->semilleros);

      escribirLista(archivo, "PROYECTO", inv->proyectos);

      escribirLista(archivo, "RECONOCIMIENTO", inv->reconocimientos);

      NodoProducto *producto = inv->productos;

      while (producto) {

        escribirProducto(archivo, "PRODUCTO", producto->producto);

        producto = producto->sig;
      }

      archivo << "FIN_INVESTIGADOR\n";

      actual = actual->sig;
    }

    archivo << "FIN\n";

    archivo.close();

    return true;
  }

  // =========================================================
  // CARGAR INVESTIGADORES
  // =========================================================

  bool cargarInvestigadores(ListaInvestigadores &lista) {

    ifstream archivo(ARCHIVO_INVESTIGADORES.c_str());

    if (!archivo.is_open()) {
      return false;
    }

    lista.limpiar();

    string linea;

    Investigador *investigadorActual = NULL;

    ProductoInvestigacion *productoActual = NULL;

    bool huboError = false;

    bool huboDatos = false;

    while (getline(archivo, linea) && !huboError) {

      if (!linea.empty()) {

        vector<string> campos = separarCampos(linea);

        if (!campos.empty()) {

          if (campos[0] == "INVESTIGADOR") {

            if (campos.size() >= 4) {

              investigadorActual = new Investigador(
                  campos[1], campos[2], campos[3], campoOpcional(campos, 4),
                  campoOpcional(campos, 5), campoOpcional(campos, 6),
                  campoOpcional(campos, 7), campoOpcional(campos, 8),
                  campoOpcional(campos, 9));

              if (campos.size() >= 11)
                investigadorActual->activo = convertirBooleano(campos[10]);

              lista.agregar(investigadorActual);

              huboDatos = true;
            } else {

              huboError = true;
            }
          } else if (campos[0] == "NOMBRE_CITACIONES") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->nombreCitaciones = campos[1];
          } else if (campos[0] == "NACIONALIDAD") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->nacionalidad = campos[1];
          } else if (campos[0] == "SEXO") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->sexo = campos[1];
          } else if (campos[0] == "ESTADO_PAR_EVALUADOR") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->estadoParEvaluador = campos[1];
          } else if (campos[0] == "RESEARCHER_ID") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->researcherId = campos[1];
          } else if (campos[0] == "AUTOR_ID_SCOPUS") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->autorIdScopus = campos[1];
          } else if (campos[0] == "GOOGLE_SCHOLAR") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->googleScholar = campos[1];
          } else if (campos[0] == "RESEARCHGATE") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->researchGate = campos[1];
          } else if (campos[0] == "ACADEMIA_EDU") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->academiaEdu = campos[1];
          } else if (campos[0] == "MENDELEY") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->mendeley = campos[1];
          } else if (campos[0] == "LINKEDIN") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->linkedin = campos[1];
          } else if (campos[0] == "REPOSITORIO_INSTITUCIONAL") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->repositorioInstitucional = campos[1];
          } else if (campos[0] == "IDIOMA") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->idiomas.push_back(campos[1]);
          } else if (campos[0] == "AREA_CONOCIMIENTO") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->areasConocimiento.push_back(campos[1]);
          } else if (campos[0] == "LINEA_INVESTIGACION") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->lineasInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "FORMACION") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->formacionAcademica.push_back(campos[1]);
          } else if (campos[0] == "EXPERIENCIA") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->experienciaProfesional.push_back(campos[1]);
          } else if (campos[0] == "GRUPO_INVESTIGACION") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->gruposInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "SEMILLERO") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->semilleros.push_back(campos[1]);
          } else if (campos[0] == "PROYECTO") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->proyectos.push_back(campos[1]);
          } else if (campos[0] == "RECONOCIMIENTO") {

            if (investigadorActual != NULL && campos.size() >= 2)
              investigadorActual->reconocimientos.push_back(campos[1]);
          } else if (campos[0] == "PRODUCTO") {

            if (investigadorActual != NULL && campos.size() >= 6) {

              productoActual = new ProductoInvestigacion(
                  campos[1], campos[2], campos[3], convertirBooleano(campos[4]),
                  atoi(campos[5].c_str()), campoOpcional(campos, 6),
                  campoOpcional(campos, 7), campoOpcional(campos, 8),
                  campoOpcional(campos, 9), campoOpcional(campos, 10),
                  campoOpcional(campos, 11), campoOpcional(campos, 12),
                  campoOpcional(campos, 13), campoOpcional(campos, 14),
                  campoOpcional(campos, 15), campoOpcional(campos, 16),
                  campoOpcional(campos, 17), campoOpcional(campos, 18),
                  campoOpcional(campos, 19));

              investigadorActual->agregarProducto(productoActual);
            } else {

              huboError = true;
            }
          } else if (campos[0] == "AUTOR") {

            if (productoActual != NULL && campos.size() >= 2)
              productoActual->autores.push_back(campos[1]);
          } else if (campos[0] == "PRODUCTO_FIN") {

            productoActual = NULL;
          } else if (campos[0] == "FIN_INVESTIGADOR") {

            investigadorActual = NULL;

            productoActual = NULL;
          }
        }
      }
    }

    archivo.close();

    if (huboError || !huboDatos)
      return false;

    return true;
  }

  // =========================================================
  // GUARDAR GRUPOS
  // =========================================================

  bool guardarGrupos(MultilistaGrupos &grupos) {

    ofstream archivo(ARCHIVO_GRUPOS.c_str(), ios::trunc);

    if (!archivo.is_open()) {
      return false;
    }

    archivo << "TIPO\tGRUPOS\n";

    NodoGrupo *grupo = grupos.getCabeza();

    while (grupo) {

      GrupoInvestigacion *g = grupo->grupo;

      archivo << "GRUPO\t" << sanitizar(g->nroGrupo) << '\t'
              << sanitizar(g->nombreGrupo) << "\n";

      archivo << "ANIO_FORMACION\t" << sanitizar(g->anioFormacion) << "\n";

      archivo << "DEPARTAMENTO\t" << sanitizar(g->departamento) << "\n";

      archivo << "CIUDAD\t" << sanitizar(g->ciudad) << "\n";

      archivo << "LIDER\t" << sanitizar(g->lider) << "\n";

      archivo << "INFORMACION_CERTIFICADA\t"
              << sanitizar(g->informacionCertificada) << "\n";

      archivo << "PAGINA_WEB\t" << sanitizar(g->paginaWeb) << "\n";

      archivo << "EMAIL\t" << sanitizar(g->email) << "\n";

      archivo << "CLASIFICACION\t" << sanitizar(g->clasificacion) << "\n";

      archivo << "AREA_CONOCIMIENTO\t" << sanitizar(g->areaConocimiento)
              << "\n";

      archivo << "PROGRAMA_NACIONAL_CTI\t" << sanitizar(g->programaNacionalCti)
              << "\n";

      archivo << "PROGRAMA_NACIONAL_CTI_SECUNDARIO\t"
              << sanitizar(g->programaNacionalCtiSecundario) << "\n";

      archivo << "PLAN_ESTRATEGICO\t" << sanitizar(g->planEstrategico) << "\n";

      archivo << "ESTADO_ARTE\t" << sanitizar(g->estadoArte) << "\n";

      archivo << "OBJETIVOS\t" << sanitizar(g->objetivos) << "\n";

      archivo << "RETOS\t" << sanitizar(g->retos) << "\n";

      archivo << "VISION\t" << sanitizar(g->vision) << "\n";

      escribirLista(archivo, "INSTITUCION", g->instituciones);

      escribirLista(archivo, "LINEA_INVESTIGACION", g->lineasInvestigacion);

      NodoInvestigador *inv = grupo->hijoIntegrantes;

      while (inv) {

        Investigador *investigador = inv->investigador;

        archivo << "INTEGRANTE\t" << sanitizar(investigador->codigoRh) << '\t'
                << sanitizar(investigador->nombre) << '\t'
                << sanitizar(investigador->correo) << '\t'
                << sanitizar(investigador->orcid) << '\t'
                << sanitizar(investigador->institucion) << '\t'
                << sanitizar(investigador->departamento) << '\t'
                << sanitizar(investigador->ciudad) << '\t'
                << sanitizar(investigador->categoriaInvestigador) << '\t'
                << sanitizar(investigador->perfil) << '\t'
                << booleanoATexto(investigador->activo) << "\n";

        archivo << "INTEGRANTE_NOMBRE_CITACIONES\t"
                << sanitizar(investigador->nombreCitaciones) << "\n";
        archivo << "INTEGRANTE_NACIONALIDAD\t"
                << sanitizar(investigador->nacionalidad) << "\n";
        archivo << "INTEGRANTE_SEXO\t" << sanitizar(investigador->sexo) << "\n";
        archivo << "INTEGRANTE_ESTADO_PAR_EVALUADOR\t"
                << sanitizar(investigador->estadoParEvaluador) << "\n";
        archivo << "INTEGRANTE_RESEARCHER_ID\t"
                << sanitizar(investigador->researcherId) << "\n";
        archivo << "INTEGRANTE_AUTOR_ID_SCOPUS\t"
                << sanitizar(investigador->autorIdScopus) << "\n";
        archivo << "INTEGRANTE_GOOGLE_SCHOLAR\t"
                << sanitizar(investigador->googleScholar) << "\n";
        archivo << "INTEGRANTE_RESEARCHGATE\t"
                << sanitizar(investigador->researchGate) << "\n";
        archivo << "INTEGRANTE_ACADEMIA_EDU\t"
                << sanitizar(investigador->academiaEdu) << "\n";
        archivo << "INTEGRANTE_MENDELEY\t" << sanitizar(investigador->mendeley)
                << "\n";
        archivo << "INTEGRANTE_LINKEDIN\t" << sanitizar(investigador->linkedin)
                << "\n";
        archivo << "INTEGRANTE_REPOSITORIO_INSTITUCIONAL\t"
                << sanitizar(investigador->repositorioInstitucional) << "\n";

        escribirLista(archivo, "INTEGRANTE_IDIOMA", investigador->idiomas);

        escribirLista(archivo, "INTEGRANTE_AREA",
                      investigador->areasConocimiento);

        escribirLista(archivo, "INTEGRANTE_LINEA",
                      investigador->lineasInvestigacion);

        escribirLista(archivo, "INTEGRANTE_FORMACION",
                      investigador->formacionAcademica);

        escribirLista(archivo, "INTEGRANTE_EXPERIENCIA",
                      investigador->experienciaProfesional);

        escribirLista(archivo, "INTEGRANTE_GRUPO",
                      investigador->gruposInvestigacion);

        escribirLista(archivo, "INTEGRANTE_SEMILLERO",
                      investigador->semilleros);

        escribirLista(archivo, "INTEGRANTE_PROYECTO", investigador->proyectos);

        escribirLista(archivo, "INTEGRANTE_RECONOCIMIENTO",
                      investigador->reconocimientos);

        NodoProducto *producto = investigador->productos;

        while (producto) {

          escribirProducto(archivo, "INTEGRANTE_PRODUCTO", producto->producto);

          producto = producto->sig;
        }

        archivo << "FIN_INTEGRANTE\n";

        inv = inv->sig;
      }

      NodoProducto *productoGrupo = grupo->hijoProductos;

      while (productoGrupo) {

        escribirProducto(archivo, "PRODUCTO", productoGrupo->producto);

        productoGrupo = productoGrupo->sig;
      }

      archivo << "FIN_GRUPO\n";

      grupo = grupo->sig;
    }

    archivo << "FIN\n";

    archivo.close();

    return true;
  }

  // =========================================================
  // CARGAR GRUPOS
  // =========================================================

  bool cargarGrupos(MultilistaGrupos &grupos) {

    ifstream archivo(ARCHIVO_GRUPOS.c_str());

    if (!archivo.is_open()) {
      return false;
    }

    grupos.limpiar();

    string linea;

    NodoGrupo *grupoActual = NULL;

    ProductoInvestigacion *productoActual = NULL;

    bool huboError = false;

    bool huboDatos = false;

    while (getline(archivo, linea) && !huboError) {

      if (!linea.empty()) {

        vector<string> campos = separarCampos(linea);

        if (!campos.empty()) {

          if (campos[0] == "GRUPO") {

            if (campos.size() >= 3) {

              grupos.agregarGrupo(new GrupoInvestigacion(campos[1], campos[2]));

              grupoActual = grupos.buscarGrupo(campos[1]);

              huboDatos = true;
            } else {

              huboError = true;
            }
          } else if (campos[0] == "ANIO_FORMACION") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->anioFormacion = campos[1];
          } else if (campos[0] == "DEPARTAMENTO") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->departamento = campos[1];
          } else if (campos[0] == "CIUDAD") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->ciudad = campos[1];
          } else if (campos[0] == "LIDER") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->lider = campos[1];
          } else if (campos[0] == "INFORMACION_CERTIFICADA") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->informacionCertificada = campos[1];
          } else if (campos[0] == "PAGINA_WEB") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->paginaWeb = campos[1];
          } else if (campos[0] == "EMAIL") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->email = campos[1];
          } else if (campos[0] == "CLASIFICACION") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->clasificacion = campos[1];
          } else if (campos[0] == "AREA_CONOCIMIENTO") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->areaConocimiento = campos[1];
          } else if (campos[0] == "PROGRAMA_NACIONAL_CTI") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->programaNacionalCti = campos[1];
          } else if (campos[0] == "PROGRAMA_NACIONAL_CTI_SECUNDARIO") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->programaNacionalCtiSecundario = campos[1];
          } else if (campos[0] == "PLAN_ESTRATEGICO") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->planEstrategico = campos[1];
          } else if (campos[0] == "ESTADO_ARTE") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->estadoArte = campos[1];
          } else if (campos[0] == "OBJETIVOS") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->objetivos = campos[1];
          } else if (campos[0] == "RETOS") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->retos = campos[1];
          } else if (campos[0] == "VISION") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->vision = campos[1];
          } else if (campos[0] == "INSTITUCION") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->instituciones.push_back(campos[1]);
          } else if (campos[0] == "LINEA_INVESTIGACION") {

            if (grupoActual != NULL && campos.size() >= 2)
              grupoActual->grupo->lineasInvestigacion.push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE") {

            if (grupoActual != NULL && campos.size() >= 4) {

              Investigador *integrante = new Investigador(
                  campos[1], campos[2], campos[3], campoOpcional(campos, 4),
                  campoOpcional(campos, 5), campoOpcional(campos, 6),
                  campoOpcional(campos, 7), campoOpcional(campos, 8),
                  campoOpcional(campos, 9));

              if (campos.size() >= 11)
                integrante->activo = convertirBooleano(campos[10]);

              grupos.agregarIntegrante(grupoActual->grupo->nroGrupo,
                                       integrante);

              grupoActual = grupos.buscarGrupo(grupoActual->grupo->nroGrupo);

              productoActual = NULL;
            } else {

              huboError = true;
            }
          } else if (campos[0] == "INTEGRANTE_NOMBRE_CITACIONES") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->nombreCitaciones =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_NACIONALIDAD") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->nacionalidad =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_SEXO") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->sexo = campos[1];
          } else if (campos[0] == "INTEGRANTE_ESTADO_PAR_EVALUADOR") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->estadoParEvaluador =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_RESEARCHER_ID") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->researcherId =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_AUTOR_ID_SCOPUS") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->autorIdScopus =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_GOOGLE_SCHOLAR") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->googleScholar =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_RESEARCHGATE") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->researchGate =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_ACADEMIA_EDU") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->academiaEdu =
                  campos[1];
          } else if (campos[0] == "INTEGRANTE_MENDELEY") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->mendeley = campos[1];
          } else if (campos[0] == "INTEGRANTE_LINKEDIN") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->linkedin = campos[1];
          } else if (campos[0] == "INTEGRANTE_REPOSITORIO_INSTITUCIONAL") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador
                  ->repositorioInstitucional = campos[1];
          } else if (campos[0] == "INTEGRANTE_IDIOMA") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->idiomas.push_back(
                  campos[1]);
          } else if (campos[0] == "INTEGRANTE_AREA") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->areasConocimiento
                  .push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_LINEA") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->lineasInvestigacion
                  .push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_FORMACION") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->formacionAcademica
                  .push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_EXPERIENCIA") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->experienciaProfesional
                  .push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_GRUPO") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->gruposInvestigacion
                  .push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_SEMILLERO") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->semilleros.push_back(
                  campos[1]);
          } else if (campos[0] == "INTEGRANTE_PROYECTO") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->proyectos.push_back(
                  campos[1]);
          } else if (campos[0] == "INTEGRANTE_RECONOCIMIENTO") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 2)
              grupoActual->hijoIntegrantes->investigador->reconocimientos
                  .push_back(campos[1]);
          } else if (campos[0] == "INTEGRANTE_PRODUCTO") {

            if (grupoActual != NULL && grupoActual->hijoIntegrantes != NULL &&
                campos.size() >= 6) {

              productoActual = new ProductoInvestigacion(
                  campos[1], campos[2], campos[3], convertirBooleano(campos[4]),
                  atoi(campos[5].c_str()), campoOpcional(campos, 6),
                  campoOpcional(campos, 7), campoOpcional(campos, 8),
                  campoOpcional(campos, 9), campoOpcional(campos, 10),
                  campoOpcional(campos, 11), campoOpcional(campos, 12),
                  campoOpcional(campos, 13), campoOpcional(campos, 14),
                  campoOpcional(campos, 15), campoOpcional(campos, 16),
                  campoOpcional(campos, 17), campoOpcional(campos, 18),
                  campoOpcional(campos, 19));

              grupoActual->hijoIntegrantes->investigador->agregarProducto(
                  productoActual);
            } else {

              huboError = true;
            }
          } else if (campos[0] == "PRODUCTO") {

            if (grupoActual != NULL && campos.size() >= 6) {

              productoActual = new ProductoInvestigacion(
                  campos[1], campos[2], campos[3], convertirBooleano(campos[4]),
                  atoi(campos[5].c_str()), campoOpcional(campos, 6),
                  campoOpcional(campos, 7), campoOpcional(campos, 8),
                  campoOpcional(campos, 9), campoOpcional(campos, 10),
                  campoOpcional(campos, 11), campoOpcional(campos, 12),
                  campoOpcional(campos, 13), campoOpcional(campos, 14),
                  campoOpcional(campos, 15), campoOpcional(campos, 16),
                  campoOpcional(campos, 17), campoOpcional(campos, 18),
                  campoOpcional(campos, 19));

              grupos.agregarProducto(grupoActual->grupo->nroGrupo,
                                     productoActual);
            } else {

              huboError = true;
            }
          } else if (campos[0] == "AUTOR") {

            if (productoActual != NULL && campos.size() >= 2)
              productoActual->autores.push_back(campos[1]);
          } else if (campos[0] == "PRODUCTO_FIN") {

            productoActual = NULL;
          } else if (campos[0] == "FIN_INTEGRANTE") {

            productoActual = NULL;
          } else if (campos[0] == "FIN_GRUPO") {

            grupoActual = NULL;

            productoActual = NULL;
          }
        }
      }
    }

    archivo.close();

    if (huboError || !huboDatos)
      return false;

    return true;
  }
};

// =========================================================================
// MOTOR DE CONSOLA//
// =========================================================================
// MOTOR DE CONSOLA
// =========================================================================

class MotorConsolaC {

private:
  // =========================================================
  // ESTRUCTURAS PRINCIPALES
  // =========================================================

  ListaInvestigadores listasInv;

  MultilistaGrupos multilistas;

  // =========================================================
  // MODULO DE LECTURA WEB
  // =========================================================

  LectorArchivosYWeb lectorWeb;

  // =========================================================
  // MODULO DE PERSISTENCIA
  // =========================================================

  PersistenciaArchivos persistencia;

  // =========================================================
  // GESTOR DE PRODUCTOS UNICOS (CONTROL DE DUPLICADOS)
  // =========================================================

  GestorProductosUnicos gestorProductos;

  // =========================================================
  // DIBUJAR MARCO
  // =========================================================

  void dibujarMarco() {

#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif

    gotoxy(10, 2);
    cout << "==========================================================";

    gotoxy(10, 3);
    cout << "|        PROYECTO PEA-i (Programa Estadistico UPC)       |";

    gotoxy(10, 4);
    cout << "==========================================================";
  }

  // =========================================================
  // PAUSAR
  // =========================================================

  void pausar() {

    gotoxy(10, 20);
    cout << "Presione cualquier tecla para continuar...";

    _getch();
  }

  // =========================================================
  // CONTEO AUXILIAR DE ENTIDADES
  // =========================================================

  int contarInvestigadoresTotales() {
    int c = 0;
    NodoInvestigador *act = listasInv.getCabeza();
    while (act != NULL) {
      c++;
      act = act->sig;
    }
    return c;
  }

  int contarGruposTotales() {
    int c = 0;
    NodoGrupo *act = multilistas.getCabeza();
    while (act != NULL) {
      c++;
      act = act->sig;
    }
    return c;
  }

  // =========================================================
  // REPORTES ANALITICOS Y PRODUCTOS UNICOS
  // =========================================================

  void mostrarListadoProductosUnicos() {
    dibujarMarco();
    gotoxy(12, 5);
    cout << "--- LISTADO DE PRODUCTOS UNICOS Y VINCULACIONES ---";

    const vector<RegistroProductoUnico> &cat = gestorProductos.getCatalogo();
    if (cat.empty()) {
      gotoxy(12, 8);
      cout << "No hay productos cargados en el sistema.";
    } else {
      int y = 7;
      size_t i = 0;
      while (i < cat.size() && y < 18) {
        gotoxy(12, y++);
        string tit = cat[i].producto->titulo;
        if (tit.size() > 40) {
          tit = tit.substr(0, 37) + "...";
        }
        cout << (i + 1) << ". " << tit << " (" << cat[i].producto->anio << ")";

        gotoxy(15, y++);
        cout << "Cat: " << cat[i].producto->categoria;
        if (cat[i].aparicionesTotales > 1) {
          cout << " | COMPARTIDO (" << cat[i].aparicionesTotales
               << " apariciones)";
        }
        y++;
        i++;
      }
    }
    pausar();
  }

  void mostrarDistribucionCategorias() {
    dibujarMarco();
    gotoxy(12, 5);
    cout << "--- DISTRIBUCION DE PRODUCTOS UNICOS POR CATEGORIA ---";

    vector<string> categorias = gestorProductos.obtenerCategoriasDisponibles();
    if (categorias.empty()) {
      gotoxy(12, 8);
      cout << "No hay categorias de productos para mostrar.";
    } else {
      int y = 8;
      size_t i = 0;
      while (i < categorias.size() && y < 18) {
        int cantidad = gestorProductos.contarPorCategoria(categorias[i]);
        gotoxy(14, y++);
        string nombreCat = categorias[i];
        if (nombreCat.size() > 35) {
          nombreCat = nombreCat.substr(0, 32) + "...";
        }
        cout << "- " << nombreCat << ": " << cantidad << " producto(s)";
        i++;
      }
    }
    pausar();
  }

  void mostrarDistribucionAnios() {
    dibujarMarco();
    gotoxy(12, 5);
    cout << "--- DISTRIBUCION TEMPORAL DE PRODUCTOS UNICOS ---";

    vector<int> anios = gestorProductos.obtenerAniosDisponibles();
    if (anios.empty()) {
      gotoxy(12, 8);
      cout << "No hay anos de productos registrados.";
    } else {
      size_t a1 = 0;
      while (a1 < anios.size()) {
        size_t a2 = a1 + 1;
        while (a2 < anios.size()) {
          if (anios[a1] > anios[a2]) {
            int temp = anios[a1];
            anios[a1] = anios[a2];
            anios[a2] = temp;
          }
          a2++;
        }
        a1++;
      }

      int y = 8;
      size_t i = 0;
      while (i < anios.size() && y < 18) {
        int cantidad = gestorProductos.contarPorAnio(anios[i]);
        gotoxy(16, y++);
        cout << "- Anio " << anios[i] << ": " << cantidad
             << " producto(s) unico(s)";
        i++;
      }
    }
    pausar();
  }

  void menuReportesEstadisticos() {
    gestorProductos.consolidar(listasInv, multilistas);

    int subOpcion = 0;
    while (subOpcion != 4) {
      dibujarMarco();
      gotoxy(12, 5);
      cout << "--- REPORTES ANALITICOS Y PRODUCTOS UNICOS (PEA-i) ---";

      gotoxy(12, 7);
      cout << "Total Investigadores : " << contarInvestigadoresTotales();
      gotoxy(12, 8);
      cout << "Total Grupos         : " << contarGruposTotales();
      gotoxy(12, 9);
      cout << "Productos Brutos     : " << gestorProductos.obtenerTotalBruto();
      gotoxy(12, 10);
      cout << "Productos Unicos     : "
           << gestorProductos.obtenerTotalUnicos() << " (Netos reales)";
      gotoxy(12, 11);
      cout << "Duplicados/Compart.  : "
           << gestorProductos.obtenerTotalDuplicados()
           << " (Entre grupos e investigadores)";

      gotoxy(12, 13);
      cout << "1. Ver Listado Detallado de Productos Unicos";
      gotoxy(12, 14);
      cout << "2. Distribucion por Categoria de Producto";
      gotoxy(12, 15);
      cout << "3. Distribucion Temporal por Anio";
      gotoxy(12, 16);
      cout << "4. Regresar al Menu Principal";

      gotoxy(12, 18);
      cout << "Seleccione una opcion: ";
      cin >> subOpcion;

      if (cin.fail()) {
        cin.clear();
        cin.ignore(10000, '\n');
        subOpcion = 0;
      }

      if (subOpcion == 1) {
        mostrarListadoProductosUnicos();
      } else if (subOpcion == 2) {
        mostrarDistribucionCategorias();
      } else if (subOpcion == 3) {
        mostrarDistribucionAnios();
      } else if (subOpcion == 4) {
        // Regresar de forma limpia
      } else {
        gotoxy(12, 20);
        cout << "Opcion no valida.";
        pausar();
      }
    }
  }

  // =========================================================
  // CARGAR INVESTIGADOR
  // =========================================================

  void cargarInvestigador() {

    dibujarMarco();

    gotoxy(15, 6);
    cout << "--- CARGAR INVESTIGADOR DESDE CvLAC ---";

    gotoxy(15, 8);
    cout << "Ingrese la URL:";

    gotoxy(15, 9);

    cin >> ws;

    string url;

    getline(cin, url);

    string urlValida;
    string errVal;
    if (!LectorArchivosYWeb::validarUrlMinciencias("investigador", url,
                                                   urlValida, errVal)) {
      gotoxy(15, 11);
      cout << "Error de validacion de URL:";
      if (errVal.find("Incompatibilidad") != string::npos) {
        gotoxy(15, 13);
        cout << "La URL ingresada corresponde a un grupo (GrupLAC).";
        gotoxy(15, 14);
        cout << "Utilice la opcion '2. Cargar Grupo (GrupLAC)'.";
      } else if (errVal.find("scienti.minciencias.gov.co") != string::npos) {
        gotoxy(15, 13);
        cout << "El enlace debe pertenecer al dominio oficial:";
        gotoxy(15, 14);
        cout << "scienti.minciencias.gov.co";
      } else {
        gotoxy(15, 13);
        cout << errVal;
      }
      pausar();
    } else {

      url = urlValida;

      // -----------------------------------------------------
      // LLAMAR AL LECTOR WEB
      // -----------------------------------------------------

      Investigador *investigador =

          lectorWeb.cargarInvestigadorDesdeWeb(url);

      // -----------------------------------------------------
      // ALMACENAR RESULTADO
      // -----------------------------------------------------

      if (investigador != NULL) {

        if (listasInv.buscarCoincidencia(investigador) != NULL) {

          delete investigador;

          gotoxy(15, 15);
          cout << "El investigador ya se encuentra cargado.";
        } else {

          listasInv.agregar(investigador);
          gestorProductos.consolidar(listasInv, multilistas);

          gotoxy(15, 15);
          cout << "Investigador cargado en memoria.";
          gotoxy(15, 16);
          cout << "Para guardar en disco use la opcion 5.";
        }
      } else {

        gotoxy(15, 15);
        cout << "No se pudo cargar el investigador.";
      }

      pausar();
    }
  }

  // =========================================================
  // CARGAR GRUPO
  // =========================================================

  void cargarGrupo() {

    dibujarMarco();

    gotoxy(15, 6);
    cout << "--- CARGAR GRUPO DESDE GrupLAC ---";

    gotoxy(15, 8);
    cout << "Ingrese la URL:";

    gotoxy(15, 9);

    cin >> ws;

    string url;

    getline(cin, url);

    string urlValida;
    string errVal;
    if (!LectorArchivosYWeb::validarUrlMinciencias("grupo", url, urlValida,
                                                   errVal)) {
      gotoxy(15, 11);
      cout << "Error de validacion de URL:";
      if (errVal.find("Incompatibilidad") != string::npos) {
        gotoxy(15, 13);
        cout << "La URL ingresada corresponde a un investigador (CvLAC).";
        gotoxy(15, 14);
        cout << "Utilice la opcion '1. Cargar Investigador (CvLAC)'.";
      } else if (errVal.find("scienti.minciencias.gov.co") != string::npos) {
        gotoxy(15, 13);
        cout << "El enlace debe pertenecer al dominio oficial:";
        gotoxy(15, 14);
        cout << "scienti.minciencias.gov.co";
      } else {
        gotoxy(15, 13);
        cout << errVal;
      }
      pausar();
    } else {

      url = urlValida;

      // -----------------------------------------------------
      // LLAMAR AL LECTOR WEB
      // -----------------------------------------------------

      GrupoInvestigacion *grupo = NULL;

      vector<Investigador *> integrantes;

      vector<ProductoInvestigacion *> productos;

      bool cargado =
          lectorWeb.cargarGrupoDesdeWeb(url, grupo, integrantes, productos);

      // -----------------------------------------------------
      // ALMACENAR RESULTADO
      // -----------------------------------------------------

      if (cargado && grupo != NULL) {

        if (multilistas.buscarGrupoCoincidencia(grupo) != NULL) {

          for (size_t i = 0; i < integrantes.size(); ++i) {

            delete integrantes[i];
          }

          for (size_t i = 0; i < productos.size(); ++i) {

            delete productos[i];
          }

          delete grupo;

          gotoxy(15, 15);
          cout << "El grupo ya se encuentra cargado.";
        } else {

          string numeroGrupo = grupo->nroGrupo;

          multilistas.agregarGrupo(grupo);

          for (size_t i = 0; i < integrantes.size(); ++i) {

            multilistas.agregarIntegrante(numeroGrupo, integrantes[i]);
          }

          for (size_t i = 0; i < productos.size(); ++i) {

            multilistas.agregarProducto(numeroGrupo, productos[i]);
          }

          integrantes.clear();
          productos.clear();
          gestorProductos.consolidar(listasInv, multilistas);

          gotoxy(15, 15);
          cout << "Grupo cargado en memoria.";
          gotoxy(15, 16);
          cout << "Para guardar en disco use la opcion 5.";
        }
      } else {

        gotoxy(15, 15);
        cout << "No se pudo cargar el grupo.";
      }

      pausar();
    }
  }

  // =========================================================
  // ESTADO DEL SCRAPER Y HISTORIAL DE CIERRE
  // =========================================================

  void mostrarEstadoScraper() {

    dibujarMarco();

    gotoxy(15, 5);
    cout << "--- ESTADO DEL SCRAPER Y CONTROL DE PROCESOS ---";

    string ruta = lectorWeb.getRutaScraper();
    gotoxy(15, 7);
    cout << "Ruta detectada : ";
    if (ruta.empty()) {
      cout << "No encontrado (PEA-i-Scraper.exe / PEA-i.exe)";
    } else {
      cout << ruta;
    }

    bool activo = lectorWeb.estaScraperActivo();
    gotoxy(15, 8);
    cout << "Estado proceso : ";
    if (activo) {
      cout << "EN EJECUCION (PID: " << lectorWeb.obtenerPidScraper() << ")";
    } else {
      cout << "DETENIDO / INACTIVO";
    }

    gotoxy(15, 10);
    cout << "Ultimo tipo de cierre registrado:";
    gotoxy(17, 11);
    cout << lectorWeb.obtenerUltimoTipoCierre();

    gotoxy(15, 13);
    cout << "Ultimos registros (scraper_cierre.log):";
    vector<string> logs = lectorWeb.obtenerUltimosRegistrosLog(3);
    int y = 14;
    for (size_t i = 0; i < logs.size() && y < 17; ++i) {
      gotoxy(17, y++);
      string texto = logs[i];
      if (texto.size() > 55) {
        texto = texto.substr(0, 52) + "...";
      }
      cout << texto;
    }

    gotoxy(15, 18);
    cout << "1. Detener scraper ahora  |  2. Regresar: ";
    int subOpcion = 0;
    cin >> subOpcion;

    if (cin.fail()) {
      cin.clear();
      cin.ignore(10000, '\n');
      subOpcion = 2;
    }

    if (subOpcion == 1) {
      lectorWeb.cerrarScraperNormal();
      gotoxy(15, 20);
      cout << "Scraper detenido con exito.";
      pausar();
    }
  }

  // =========================================================
  // CARGAR DESDE ARCHIVO PDF (CvLAC / GrupLAC / LOTES MIXTOS)
  // =========================================================

  void cargarDesdePdfConsola() {
    dibujarMarco();
    gotoxy(12, 5);
    cout << "--- CARGAR DESDE ARCHIVO PDF (CvLAC / GrupLAC / Lotes) ---";

    gotoxy(12, 7);
    cout << "Arrastre y suelte el archivo PDF aqui o ingrese la ruta:";
    gotoxy(12, 8);
    cout << "(Ejemplo: C:\\datos\\investigadores.pdf)";
    gotoxy(12, 10);
    cout << "Ruta del archivo: ";

    cin >> ws;
    string entradaRuta;
    getline(cin, entradaRuta);

    string rutaLimpia = LectorArchivosYWeb::sanitizarRutaArchivo(entradaRuta);

    if (rutaLimpia.empty()) {
      gotoxy(12, 12);
      cout << "Error: No se ingreso ninguna ruta de archivo.";
      pausar();
    } else {
      string rutaMin = LectorArchivosYWeb::aMinusculasTexto(rutaLimpia);
      bool esPdf = false;
      if (rutaMin.size() >= 4) {
        if (rutaMin.substr(rutaMin.size() - 4) == ".pdf") {
          esPdf = true;
        }
      }

      if (!esPdf) {
        gotoxy(12, 12);
        cout << "Error: El archivo debe tener extension .pdf";
        gotoxy(12, 13);
        cout << "Ruta recibida: " << rutaLimpia;
        pausar();
      } else {
        ifstream archivoPrueba(rutaLimpia.c_str(), ios::binary);
        if (!archivoPrueba.is_open()) {
          gotoxy(12, 12);
          cout << "Error: No se puede abrir o no existe el archivo indicado.";
          gotoxy(12, 13);
          cout << "Ruta: " << rutaLimpia;
          pausar();
        } else {
          archivoPrueba.close();

          gotoxy(12, 12);
          cout << "Procesando documento con el extractor inteligente...";
          gotoxy(12, 13);
          cout << "Esto puede tardar unos segundos segun la longitud...";

          string respuesta;
          bool exitoHttp =
              lectorWeb.cargarDesdeArchivo("pdf", rutaLimpia, respuesta);

          if (!exitoHttp) {
            gotoxy(12, 15);
            cout << "Error en la comunicacion o procesamiento:";
            gotoxy(12, 16);
            string err = lectorWeb.getUltimoError();
            if (err.empty()) {
              err = "Fallo en el servicio extractor del scraper.";
            }
            if (err.size() > 55) {
              err = err.substr(0, 52) + "...";
            }
            cout << err;
            pausar();
          } else {
            vector<GrupoInvestigacion *> gruposNuevos;
            vector<vector<Investigador *> > integrantesNuevos;
            vector<vector<ProductoInvestigacion *> > productosNuevos;
            vector<Investigador *> investigadoresNuevos;

            bool parseoOk = lectorWeb.parsearLote(
                respuesta, gruposNuevos, integrantesNuevos, productosNuevos,
                investigadoresNuevos);

            if (!parseoOk) {
              gotoxy(12, 15);
              cout << "Error interpretando la respuesta del extractor:";
              gotoxy(12, 16);
              string err = lectorWeb.getUltimoError();
              if (err.empty()) {
                err = "El archivo no contiene registros validos de MinCiencias.";
              }
              if (err.size() > 55) {
                err = err.substr(0, 52) + "...";
              }
              cout << err;
              pausar();
            } else {
              int agregadosInv = 0;
              int omitidosInv = 0;
              size_t idxInv = 0;
              while (idxInv < investigadoresNuevos.size()) {
                Investigador *inv = investigadoresNuevos[idxInv];
                if (inv != NULL) {
                  if (listasInv.buscarCoincidencia(inv) != NULL) {
                    delete inv;
                    investigadoresNuevos[idxInv] = NULL;
                    omitidosInv++;
                  } else {
                    listasInv.agregar(inv);
                    agregadosInv++;
                  }
                }
                idxInv++;
              }

              int agregadosGrupos = 0;
              int omitidosGrupos = 0;
              size_t idxGrp = 0;
              while (idxGrp < gruposNuevos.size()) {
                GrupoInvestigacion *grp = gruposNuevos[idxGrp];
                if (grp != NULL) {
                  if (multilistas.buscarGrupoCoincidencia(grp) != NULL) {
                    size_t k = 0;
                    while (k < integrantesNuevos[idxGrp].size()) {
                      delete integrantesNuevos[idxGrp][k];
                      integrantesNuevos[idxGrp][k] = NULL;
                      k++;
                    }
                    k = 0;
                    while (k < productosNuevos[idxGrp].size()) {
                      delete productosNuevos[idxGrp][k];
                      productosNuevos[idxGrp][k] = NULL;
                      k++;
                    }
                    delete grp;
                    gruposNuevos[idxGrp] = NULL;
                    omitidosGrupos++;
                  } else {
                    string numGrupo = grp->nroGrupo;
                    multilistas.agregarGrupo(grp);

                    size_t k = 0;
                    while (k < integrantesNuevos[idxGrp].size()) {
                      multilistas.agregarIntegrante(
                          numGrupo, integrantesNuevos[idxGrp][k]);
                      k++;
                    }

                    k = 0;
                    while (k < productosNuevos[idxGrp].size()) {
                      multilistas.agregarProducto(
                          numGrupo, productosNuevos[idxGrp][k]);
                      k++;
                    }
                    agregadosGrupos++;
                  }
                }
                idxGrp++;
              }

              // Consolidar productos unicos y control de duplicados
              gestorProductos.consolidar(listasInv, multilistas);

              dibujarMarco();
              gotoxy(12, 5);
              cout << "=== RESULTADO DE EXTRACCION INTELIGENTE (PDF) ===";

              gotoxy(12, 7);
              cout << "Investigadores procesados: "
                   << (agregadosInv + omitidosInv);
              gotoxy(14, 8);
              cout << "- Incorporados: " << agregadosInv
                   << "  |  Ya existentes: " << omitidosInv;

              gotoxy(12, 10);
              cout << "Grupos procesados       : "
                   << (agregadosGrupos + omitidosGrupos);
              gotoxy(14, 11);
              cout << "- Incorporados: " << agregadosGrupos
                   << "  |  Ya existentes: " << omitidosGrupos;

              gotoxy(12, 13);
              cout << "Catalogo consolidado    : "
                   << gestorProductos.obtenerTotalUnicos() << " productos netos";
              gotoxy(14, 14);
              cout << "(Duplicados/compartidos detectados: "
                   << gestorProductos.obtenerTotalDuplicados() << ")";

              gotoxy(12, 16);
              cout << "Datos cargados en memoria. Para guardar en disco,";
              gotoxy(12, 17);
              cout << "utilice la opcion '5. Guardar Datos' del menu.";

              pausar();
            }
          }
        }
      }
    }
  }

  // =========================================================
  // CARGAR DESDE ARCHIVO CSV (CvLAC / GrupLAC / LOTES MIXTOS)
  // =========================================================

  void cargarDesdeCsvConsola() {
    dibujarMarco();
    gotoxy(12, 5);
    cout << "--- CARGAR DESDE ARCHIVO CSV (CvLAC / GrupLAC / Lotes) ---";

    gotoxy(12, 7);
    cout << "Arrastre y suelte el archivo CSV aqui o ingrese la ruta:";
    gotoxy(12, 8);
    cout << "(Ejemplo: C:\\datos\\investigadores.csv)";
    gotoxy(12, 10);
    cout << "Ruta del archivo: ";

    cin >> ws;
    string entradaRuta;
    getline(cin, entradaRuta);

    string rutaLimpia = LectorArchivosYWeb::sanitizarRutaArchivo(entradaRuta);

    if (rutaLimpia.empty()) {
      gotoxy(12, 12);
      cout << "Error: No se ingreso ninguna ruta de archivo.";
      pausar();
    } else {
      string rutaMin = LectorArchivosYWeb::aMinusculasTexto(rutaLimpia);
      bool esCsv = false;
      if (rutaMin.size() >= 4) {
        if (rutaMin.substr(rutaMin.size() - 4) == ".csv") {
          esCsv = true;
        }
      }

      if (!esCsv) {
        gotoxy(12, 12);
        cout << "Error: El archivo debe tener extension .csv";
        gotoxy(12, 13);
        cout << "Ruta recibida: " << rutaLimpia;
        pausar();
      } else {
        ifstream archivoPrueba(rutaLimpia.c_str(), ios::binary);
        if (!archivoPrueba.is_open()) {
          gotoxy(12, 12);
          cout << "Error: No se puede abrir o no existe el archivo indicado.";
          gotoxy(12, 13);
          cout << "Ruta: " << rutaLimpia;
          pausar();
        } else {
          archivoPrueba.close();

          gotoxy(12, 12);
          cout << "Procesando archivo CSV con el extractor MinCiencias...";
          gotoxy(12, 13);
          cout << "Validando estructura tabular y consistencia de datos...";

          string respuesta;
          bool exitoHttp =
              lectorWeb.cargarDesdeArchivo("csv", rutaLimpia, respuesta);

          if (!exitoHttp) {
            gotoxy(12, 15);
            cout << "Error en la comunicacion o procesamiento:";
            gotoxy(12, 16);
            string err = lectorWeb.getUltimoError();
            if (err.empty()) {
              err = "Fallo en el servicio extractor del scraper.";
            }
            if (err.size() > 55) {
              err = err.substr(0, 52) + "...";
            }
            cout << err;
            pausar();
          } else {
            vector<GrupoInvestigacion *> gruposNuevos;
            vector<vector<Investigador *> > integrantesNuevos;
            vector<vector<ProductoInvestigacion *> > productosNuevos;
            vector<Investigador *> investigadoresNuevos;

            bool parseoOk = lectorWeb.parsearLote(
                respuesta, gruposNuevos, integrantesNuevos, productosNuevos,
                investigadoresNuevos);

            if (!parseoOk) {
              gotoxy(12, 15);
              cout << "Error interpretando la respuesta del extractor CSV:";
              gotoxy(12, 16);
              string err = lectorWeb.getUltimoError();
              if (err.empty()) {
                err = "El archivo CSV no contiene registros validos de MinCiencias.";
              }
              if (err.size() > 55) {
                err = err.substr(0, 52) + "...";
              }
              cout << err;
              pausar();
            } else {
              int prodsInvDetectados = 0;
              int idiomasInvDetectados = 0;
              if (!investigadoresNuevos.empty()) {
                if (investigadoresNuevos[0] != NULL) {
                  prodsInvDetectados = investigadoresNuevos[0]->contarProductos();
                  idiomasInvDetectados = static_cast<int>(investigadoresNuevos[0]->idiomas.size());
                }
              }

              string liderGrpDetectado = "";
              if (!gruposNuevos.empty()) {
                if (gruposNuevos[0] != NULL) {
                  liderGrpDetectado = gruposNuevos[0]->lider;
                }
              }

              int agregadosInv = 0;
              int omitidosInv = 0;
              size_t idxInv = 0;
              while (idxInv < investigadoresNuevos.size()) {
                Investigador *inv = investigadoresNuevos[idxInv];
                if (inv != NULL) {
                  if (listasInv.buscarCoincidencia(inv) != NULL) {
                    delete inv;
                    investigadoresNuevos[idxInv] = NULL;
                    omitidosInv++;
                  } else {
                    listasInv.agregar(inv);
                    agregadosInv++;
                  }
                }
                idxInv++;
              }

              int agregadosGrupos = 0;
              int omitidosGrupos = 0;
              size_t idxGrp = 0;
              while (idxGrp < gruposNuevos.size()) {
                GrupoInvestigacion *grp = gruposNuevos[idxGrp];
                if (grp != NULL) {
                  if (multilistas.buscarGrupoCoincidencia(grp) != NULL) {
                    size_t k = 0;
                    while (k < integrantesNuevos[idxGrp].size()) {
                      delete integrantesNuevos[idxGrp][k];
                      integrantesNuevos[idxGrp][k] = NULL;
                      k++;
                    }
                    k = 0;
                    while (k < productosNuevos[idxGrp].size()) {
                      delete productosNuevos[idxGrp][k];
                      productosNuevos[idxGrp][k] = NULL;
                      k++;
                    }
                    delete grp;
                    gruposNuevos[idxGrp] = NULL;
                    omitidosGrupos++;
                  } else {
                    string numGrupo = grp->nroGrupo;
                    multilistas.agregarGrupo(grp);

                    size_t k = 0;
                    while (k < integrantesNuevos[idxGrp].size()) {
                      multilistas.agregarIntegrante(
                          numGrupo, integrantesNuevos[idxGrp][k]);
                      k++;
                    }

                    k = 0;
                    while (k < productosNuevos[idxGrp].size()) {
                      multilistas.agregarProducto(
                          numGrupo, productosNuevos[idxGrp][k]);
                      k++;
                    }
                    agregadosGrupos++;
                  }
                }
                idxGrp++;
              }

              // Consolidar productos unicos y control de duplicados
              gestorProductos.consolidar(listasInv, multilistas);

              dibujarMarco();
              gotoxy(12, 5);
              cout << "=== RESULTADO DE IMPORTACION CSV (MinCiencias) ===";

              gotoxy(12, 7);
              cout << "Investigadores procesados: "
                   << (agregadosInv + omitidosInv);
              gotoxy(14, 8);
              cout << "- Incorporados: " << agregadosInv
                   << "  |  Ya existentes: " << omitidosInv;

              if (agregadosInv > 0 || omitidosInv > 0) {
                gotoxy(14, 9);
                cout << "- Detalle: " << prodsInvDetectados
                     << " productos, " << idiomasInvDetectados
                     << " idiomas";
              }

              gotoxy(12, 11);
              cout << "Grupos procesados       : "
                   << (agregadosGrupos + omitidosGrupos);
              gotoxy(14, 12);
              cout << "- Incorporados: " << agregadosGrupos
                   << "  |  Ya existentes: " << omitidosGrupos;

              if (agregadosGrupos > 0 || omitidosGrupos > 0) {
                gotoxy(14, 13);
                if (liderGrpDetectado.empty()) {
                  liderGrpDetectado = "No registrado";
                }
                if (liderGrpDetectado.size() > 28) {
                  liderGrpDetectado = liderGrpDetectado.substr(0, 25) + "...";
                }
                cout << "- Lider: " << liderGrpDetectado;
              }

              gotoxy(12, 15);
              cout << "Catalogo consolidado    : "
                   << gestorProductos.obtenerTotalUnicos() << " productos netos";
              gotoxy(14, 16);
              cout << "(Duplicados/compartidos detectados: "
                   << gestorProductos.obtenerTotalDuplicados() << ")";

              gotoxy(12, 18);
              cout << "Datos cargados en memoria. Para guardar en disco,";
              gotoxy(12, 19);
              cout << "utilice la opcion '5. Guardar Datos' del menu.";

              pausar();
            }
          }
        }
      }
    }
  }

  // =========================================================
  // MENU CARGAR DATOS
  // =========================================================

  void menuCargarDatos() {

    int opcion = 0;

    while (opcion != 6) {

      dibujarMarco();

      gotoxy(15, 6);
      cout << "--- CARGAR DATOS ---";
      gotoxy(15, 8);
      cout << "1. Cargar Investigador desde Web (CvLAC)";
      gotoxy(15, 9);
      cout << "2. Cargar Grupo desde Web (GrupLAC)";
      gotoxy(15, 10);
      cout << "3. Cargar desde Archivo PDF (CvLAC / GrupLAC / Lotes)";
      gotoxy(15, 11);
      cout << "4. Cargar desde Archivo CSV (CvLAC / GrupLAC / Lotes)";
      gotoxy(15, 12);
      cout << "5. Estado y Registro de Cierre del Scraper";
      gotoxy(15, 13);
      cout << "6. Regresar";
      gotoxy(15, 15);
      cout << "Seleccione una opcion: ";

      cin >> opcion;

      if (cin.fail()) {
        cin.clear();
        cin.ignore(10000, '\n');
        opcion = 0;
      }

      if (opcion == 1) {
        cargarInvestigador();
      } else if (opcion == 2) {
        cargarGrupo();
      } else if (opcion == 3) {
        cargarDesdePdfConsola();
      } else if (opcion == 4) {
        cargarDesdeCsvConsola();
      } else if (opcion == 5) {
        mostrarEstadoScraper();
      } else if (opcion == 6) {
        // Regresar al menu anterior.
      } else {
        gotoxy(15, 17);
        cout << "Opcion no valida.";
        pausar();
      }
    }
  }

public:
  // =========================================================
  // PERSISTENCIA Y CARGA INICIAL
  // =========================================================

  bool existenArchivosPersistencia() const {
    return persistencia.existenArchivosPersistencia();
  }

  bool existeArchivoInvestigadores() const {
    return persistencia.existeArchivoInvestigadores();
  }

  bool existeArchivoGrupos() const {
    return persistencia.existeArchivoGrupos();
  }

  bool cargarPersistencia() {
    bool invOK = persistencia.cargarInvestigadores(listasInv);
    bool gruposOK = persistencia.cargarGrupos(multilistas);
    if (invOK && gruposOK) {
      gestorProductos.consolidar(listasInv, multilistas);
      return true;
    }
    listasInv.limpiar();
    multilistas.limpiar();
    return false;
  }

  void cargarDatosIniciales() {
    if (existenArchivosPersistencia()) {
      if (!cargarPersistencia()) {
        iniciarSemilla();
      }
    } else {
      iniciarSemilla();
    }
  }

  // =========================================================
  // SEMILLA DE PRUEBA
  // =========================================================

  void iniciarSemilla() {

    // -----------------------------------------------------
    // INVESTIGADOR
    // -----------------------------------------------------

    Investigador *inv =

        new Investigador("001", "Dr. Juan Perez", "jperez@upc.edu.co");

    listasInv.agregar(inv);

    // -----------------------------------------------------
    // GRUPO
    // -----------------------------------------------------

    GrupoInvestigacion *grupo =

        new GrupoInvestigacion("G8", "Grupo de Investigacion UPC");

    multilistas.agregarGrupo(grupo);

    // -----------------------------------------------------
    // INTEGRANTE DEL GRUPO
    // -----------------------------------------------------

    // Es una copia independiente.
    Investigador *integrante =

        new Investigador("001", "Dr. Juan Perez", "jperez@upc.edu.co");

    multilistas.agregarIntegrante("G8", integrante);

    // -----------------------------------------------------
    // PRODUCTO
    // -----------------------------------------------------

    ProductoInvestigacion *producto =

        new ProductoInvestigacion("P001",
                                  "Sistema de informacion para investigacion",
                                  "Articulo", true, 2025);

    multilistas.agregarProducto("G8", producto);
    gestorProductos.consolidar(listasInv, multilistas);
  }

  // =========================================================
  // MENU PRINCIPAL
  // =========================================================

  void menuPrincipal() {

    int opcion = 0;

    while (opcion != 6) {

      dibujarMarco();

      gotoxy(15, 6);
      cout << "1. Gestionar Investigadores";
      gotoxy(15, 7);
      cout << "2. Gestionar Grupos";
      gotoxy(15, 8);
      cout << "3. Reportes Analiticos (Hipercubo)";
      gotoxy(15, 9);
      cout << "4. Cargar Datos";
      gotoxy(15, 10);
      cout << "5. Guardar Datos";
      gotoxy(15, 11);
      cout << "6. Salir";
      gotoxy(15, 13);
      cout << "Seleccione una opcion: ";

      cin >> opcion;

      if (cin.fail()) {
        cin.clear();
        cin.ignore(10000, '\n');
        opcion = 0;
      }

      if (opcion == 1) {

        // =================================================
        // INVESTIGADORES
        // =================================================

        dibujarMarco();
        gotoxy(15, 6);
        cout << "--- GESTION DE INVESTIGADORES ---";
        gotoxy(15, 8);
        cout << "Listado actual:";

        int y = 10;
        NodoInvestigador *act = listasInv.getCabeza();

        while (act && y < 19) {

          gotoxy(15, y++);
          cout << "- " << act->investigador->nombre << " ("
               << act->investigador->codigoRh << ") ["
               << act->investigador->contarProductos() << " prods]";

          act = act->sig;
        }

        pausar();
      } else if (opcion == 2) {

        // =================================================
        // GRUPOS
        // =================================================

        dibujarMarco();
        gotoxy(15, 6);
        cout << "--- GESTION DE GRUPOS ---";
        gotoxy(15, 8);
        cout << "Listado actual:";

        int y = 10;
        NodoGrupo *act = multilistas.getCabeza();

        while (act && y < 19) {

          gotoxy(15, y++);
          string liderGrp = act->grupo->lider;
          if (liderGrp.empty()) {
            liderGrp = "Sin lider";
          }
          if (liderGrp.size() > 18) {
            liderGrp = liderGrp.substr(0, 15) + "..";
          }
          cout << "- " << act->grupo->nombreGrupo << " ("
               << act->grupo->nroGrupo << ") [Lider: "
               << liderGrp << "]";

          act = act->sig;
        }

        pausar();
      } else if (opcion == 3) {

        // =================================================
        // REPORTES ANALITICOS Y GESTION DE PRODUCTOS UNICOS
        // =================================================

        menuReportesEstadisticos();
      } else if (opcion == 4) {

        // =================================================
        // CARGAR DATOS
        // =================================================

        menuCargarDatos();
      } else if (opcion == 5) {

        // =================================================
        // GUARDAR DATOS
        // =================================================

        dibujarMarco();
        gotoxy(15, 6);
        cout << "--- GUARDAR DATOS ---";

        bool investigadoresOK = persistencia.guardarInvestigadores(listasInv);

        bool gruposOK = persistencia.guardarGrupos(multilistas);

        gotoxy(15, 9);

        if (investigadoresOK && gruposOK) {

          cout << "Todos los datos fueron "
               << "guardados correctamente.";
        } else {

          cout << "Ocurrio un error al guardar "
               << "los datos.";
        }

        pausar();
      } else if (opcion == 6) {

        // =================================================
        // SALIR
        // =================================================

        dibujarMarco();
        gotoxy(15, 8);
        cout << "--- SALIDA DEL SISTEMA ---";
        gotoxy(15, 10);
        cout << "Tipo de salida: Cierre normal desde menu principal.";
        gotoxy(15, 12);
        cout << "Deteniendo proceso scraper (si esta activo)...";
        lectorWeb.cerrarScraperNormal();
        gotoxy(15, 14);
        cout << "Servicios finalizados con exito.";
        gotoxy(15, 16);
        cout << "Saliendo del sistema...";
        Sleep(800);
      } else {

        // =================================================
        // OPCION INVALIDA
        // =================================================

        gotoxy(15, 14);
        cout << "Opcion no valida.";
        pausar();
      }
    }
  }
};

// =========================================================================
// FUNCION PRINCIPAL
// =========================================================================

int main() {

#ifdef _WIN32

  SetConsoleOutputCP(CP_UTF8);

  LectorArchivosYWeb::registrarManejadorConsola();

#endif

  MotorConsolaC motor;

  // ---------------------------------------------------------
  // CARGA DE DATOS INICIAL
  // ---------------------------------------------------------
  // Si existen los archivos de persistencia (investigadores.txt y
  // grupos.txt), se lee la informacion contenida en ellos.
  // De lo contrario, se carga la semilla normal como habitualmente.
  // ---------------------------------------------------------

  if (motor.existenArchivosPersistencia()) {
    if (!motor.cargarPersistencia()) {
      motor.iniciarSemilla();
    }
  } else {
    motor.iniciarSemilla();
  }

  // ---------------------------------------------------------
  // INICIAR MENU
  // ---------------------------------------------------------

  motor.menuPrincipal();

  return 0;
}
