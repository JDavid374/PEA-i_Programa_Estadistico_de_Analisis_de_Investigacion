# -*- coding: utf-8 -*-
"""
PROYECTO PEA-i (Programa Estadistico UPC) - Modulo Scraper Unificado
====================================================================
Este archivo consolida todos los modulos del aplicativo PEA-Scraper en un
unico codigo fuente independiente:
  1. Utilidades y configuracion de rutas.
  2. Modelos de datos (Investigador, Grupo, Producto).
  3. Protocolo de interoperabilidad estructurado para C++.
  4. Persistencia en archivos JSON.
  5. Motor de scraping nativo para CvLAC y GrupLAC (Minciencias).
  6. Capa de servicios y logica de negocio.
  7. Servidor API local HTTP (127.0.0.1:8765) para puente con C++.
  8. Interfaz grafica moderna Tkinter con visualizador de cubo y reportes.
"""

import argparse
from dataclasses import asdict, dataclass, field
from datetime import datetime
import codecs
from html import unescape
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import os
from pathlib import Path
import re
import ssl
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Any, Dict, Iterable, List, Optional, Tuple
import unicodedata
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen
import webbrowser



# =========================================================================
# UTILIDADES Y CONFIGURACION DEL SISTEMA
# =========================================================================

def application_root() -> Path:
    return Path(__file__).resolve().parent


def data_directory() -> Path:
    target = application_root()
    target.mkdir(parents=True, exist_ok=True)
    return target


def resource_path(*parts: str) -> Path:
    root = application_root()
    result = root
    for part in parts:
        result = result / part
    return result


def is_valid_url(url: str) -> bool:
    try:
        parsed = urlparse(url.strip())
        valid = parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        valid = False
    return valid


def validar_url_minciencias(tipo: str, raw_url: str) -> Tuple[bool, str, str]:
    """
    Valida y normaliza URLs para la carga de datos de Minciencias (CvLAC y GrupLAC).
    Retorna: (es_valido, url_normalizada, mensaje_error).
    """
    url = str(raw_url or "").strip()
    if not url:
        return False, "", "Debe ingresar una URL para procesar la carga."

    norm_url = url
    if not (norm_url.startswith("http://") or norm_url.startswith("https://")):
        norm_url = "https://" + norm_url

    parsed = urlparse(norm_url)
    domain = (parsed.netloc or "").lower().split(":")[0]

    # 1. Validación general: dominio oficial scienti.minciencias.gov.co
    if domain != "scienti.minciencias.gov.co":
        return (
            False,
            norm_url,
            "URL inválida: El enlace debe pertenecer al dominio oficial 'scienti.minciencias.gov.co'."
        )

    # 2. Validación según tipo de entidad
    tipo_norm = str(tipo or "").strip().casefold()
    url_lower = norm_url.lower()

    if tipo_norm == "investigador":
        if "/gruplac" in url_lower:
            return (
                False,
                norm_url,
                "Incompatibilidad de tipo: La URL ingresada corresponde a un grupo (GrupLAC) y no a un investigador (CvLAC). "
                "Seleccione la opción 'Grupo · GrupLAC' si desea registrar este grupo."
            )
        if "/cvlac" not in url_lower:
            return (
                False,
                norm_url,
                "URL de investigador inválida: El enlace debe corresponder a un perfil CvLAC (debe contener '/cvlac')."
            )

    elif tipo_norm == "grupo":
        if "/cvlac" in url_lower:
            return (
                False,
                norm_url,
                "Incompatibilidad de tipo: La URL ingresada corresponde a un investigador (CvLAC) y no a un grupo (GrupLAC). "
                "Seleccione la opción 'Investigador · CvLAC' si desea registrar este investigador."
            )
        if "/gruplac" not in url_lower:
            return (
                False,
                norm_url,
                "URL de grupo inválida: El enlace debe corresponder a un grupo GrupLAC (debe contener '/gruplac')."
            )

    else:
        return False, norm_url, f"Tipo de entidad no reconocido: '{tipo}'."

    return True, norm_url, ""


def normalize_whitespace(text: str) -> str:
    if text is None:
        value = ""
    else:
        value = str(text)
    value = value.replace("\xa0", " ")
    value = value.replace("\r", "\n")
    value = re.sub(r"[\t ]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    lines = [line.strip() for line in value.split("\n")]
    lines = [line for line in lines if line]
    return "\n".join(lines).strip()


def unique_preserve(values: Iterable[str]) -> List[str]:
    result: List[str] = []
    seen = set()
    for value in values:
        item = normalize_whitespace(value)
        key = item.casefold()
        if item and key not in seen:
            result.append(item)
            seen.add(key)
    return result


def safe_int(value: Any) -> int:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return 0


def load_json_file(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        with path.open("r", encoding="utf-8") as file:
            return json.load(file)
    except (OSError, ValueError, TypeError):
        return default


def save_json_file(path: Path, data: Any) -> bool:
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
        ok = True
    except (OSError, TypeError, ValueError):
        ok = False
        if temporary.exists():
            try:
                temporary.unlink()
            except OSError:
                pass
    return ok


def txt_safe(value: Any) -> str:
    if value is None:
        text = ""
    else:
        text = str(value)
    text = text.replace("\t", " ").replace("\r", " ").replace("\n", " ")
    return normalize_whitespace(text)


def canonical_key(text: str) -> str:
    return normalize_whitespace(text).casefold()


# =========================================================================
# MODELOS DE DATOS
# =========================================================================

def clean_text(value: Any) -> str:
    if value is None:
        text = ""
    else:
        text = str(value)
    text = text.replace("\xa0", " ")
    text = " ".join(text.split())
    return text.strip()


def unique_strings(values: List[Any]) -> List[str]:
    output: List[str] = []
    seen = set()
    for value in values:
        item = clean_text(value)
        key = item.casefold()
        if item and key not in seen:
            output.append(item)
            seen.add(key)
    return output


@dataclass
class ProductoInvestigacion:
    idProducto: str = ""
    titulo: str = ""
    categoria: str = ""
    validado: bool = False
    anio: int = 0
    tipoProducto: str = ""
    subtipo: str = ""
    doi: str = ""
    isbn: str = ""
    revista: str = ""
    editorial: str = ""
    disponibilidad: str = ""
    institucion: str = ""
    ciudad: str = ""
    pais: str = ""
    numeroContrato: str = ""
    descripcion: str = ""
    palabrasClave: str = ""
    areas: str = ""
    autores: List[str] = field(default_factory=list)

    def normalizar(self) -> None:
        self.idProducto = clean_text(self.idProducto)
        self.titulo = clean_text(self.titulo)
        self.categoria = clean_text(self.categoria)
        self.tipoProducto = clean_text(self.tipoProducto)
        self.subtipo = clean_text(self.subtipo)
        self.doi = clean_text(self.doi)
        self.isbn = clean_text(self.isbn)
        self.revista = clean_text(self.revista)
        self.editorial = clean_text(self.editorial)
        self.disponibilidad = clean_text(self.disponibilidad)
        self.institucion = clean_text(self.institucion)
        self.ciudad = clean_text(self.ciudad)
        self.pais = clean_text(self.pais)
        self.numeroContrato = clean_text(self.numeroContrato)
        self.descripcion = clean_text(self.descripcion)
        self.palabrasClave = clean_text(self.palabrasClave)
        self.areas = clean_text(self.areas)
        normalized_year = 0
        try:
            normalized_year = int(self.anio)
        except (TypeError, ValueError):
            normalized_year = 0
        self.anio = normalized_year
        self.autores = unique_strings(self.autores)

    def to_dict(self) -> Dict[str, Any]:
        self.normalizar()
        return asdict(self)


@dataclass
class Investigador:
    codigoRh: str = ""
    nombre: str = ""
    correo: str = ""
    orcid: str = ""
    institucion: str = ""
    departamento: str = ""
    ciudad: str = ""
    categoriaInvestigador: str = ""
    perfil: str = ""
    nombreCitaciones: str = ""
    nacionalidad: str = ""
    sexo: str = ""
    estadoParEvaluador: str = ""
    researcherId: str = ""
    autorIdScopus: str = ""
    googleScholar: str = ""
    researchGate: str = ""
    academiaEdu: str = ""
    mendeley: str = ""
    linkedin: str = ""
    repositorioInstitucional: str = ""
    idiomas: List[str] = field(default_factory=list)
    areasConocimiento: List[str] = field(default_factory=list)
    lineasInvestigacion: List[str] = field(default_factory=list)
    formacionAcademica: List[str] = field(default_factory=list)
    experienciaProfesional: List[str] = field(default_factory=list)
    gruposInvestigacion: List[str] = field(default_factory=list)
    semilleros: List[str] = field(default_factory=list)
    proyectos: List[str] = field(default_factory=list)
    reconocimientos: List[str] = field(default_factory=list)
    productos: List[Dict[str, Any]] = field(default_factory=list)
    activo: bool = True

    def normalizar(self) -> None:
        text_fields = [
            "codigoRh", "nombre", "correo", "orcid", "institucion",
            "departamento", "ciudad", "categoriaInvestigador", "perfil",
            "nombreCitaciones", "nacionalidad", "sexo", "estadoParEvaluador",
            "researcherId", "autorIdScopus", "googleScholar", "researchGate",
            "academiaEdu", "mendeley", "linkedin", "repositorioInstitucional"
        ]
        for field_name in text_fields:
            setattr(self, field_name, clean_text(getattr(self, field_name)))
        list_fields = [
            "idiomas", "areasConocimiento", "lineasInvestigacion", "formacionAcademica",
            "experienciaProfesional", "gruposInvestigacion", "semilleros", "proyectos",
            "reconocimientos"
        ]
        for field_name in list_fields:
            setattr(self, field_name, unique_strings(getattr(self, field_name)))
        normalized_products: List[Dict[str, Any]] = []
        for product in self.productos:
            if isinstance(product, dict):
                item = product
            else:
                item = {}
            product_model = ProductoInvestigacion(**{k: item.get(k, v) for k, v in ProductoInvestigacion().__dict__.items()})
            product_model.normalizar()
            normalized_products.append(product_model.to_dict())
        self.productos = normalized_products
        self.activo = bool(self.activo)

    def to_dict(self) -> Dict[str, Any]:
        self.normalizar()
        return asdict(self)


@dataclass
class GrupoInvestigacion:
    nroGrupo: str = ""
    nombreGrupo: str = ""
    anioFormacion: str = ""
    departamento: str = ""
    ciudad: str = ""
    lider: str = ""
    informacionCertificada: str = ""
    paginaWeb: str = ""
    email: str = ""
    clasificacion: str = ""
    areaConocimiento: str = ""
    programaNacionalCti: str = ""
    programaNacionalCtiSecundario: str = ""
    planEstrategico: str = ""
    estadoArte: str = ""
    objetivos: str = ""
    retos: str = ""
    vision: str = ""
    instituciones: List[str] = field(default_factory=list)
    lineasInvestigacion: List[str] = field(default_factory=list)
    integrantes: List[Dict[str, Any]] = field(default_factory=list)
    productos: List[Dict[str, Any]] = field(default_factory=list)

    def normalizar(self) -> None:
        text_fields = [
            "nroGrupo", "nombreGrupo", "anioFormacion", "departamento", "ciudad", "lider",
            "informacionCertificada", "paginaWeb", "email", "clasificacion", "areaConocimiento",
            "programaNacionalCti", "programaNacionalCtiSecundario", "planEstrategico", "estadoArte",
            "objetivos", "retos", "vision"
        ]
        for field_name in text_fields:
            setattr(self, field_name, clean_text(getattr(self, field_name)))
        self.instituciones = unique_strings(self.instituciones)
        self.lineasInvestigacion = unique_strings(self.lineasInvestigacion)
        normalized_members: List[Dict[str, Any]] = []
        for member in self.integrantes:
            if isinstance(member, dict):
                item = member
            else:
                item = {}
            member_model = Investigador(**{k: item.get(k, v) for k, v in Investigador().__dict__.items()})
            member_model.normalizar()
            normalized_member = member_model.to_dict()
            for extra_key in ("vinculacion", "horasDedicacion", "inicioFinVinculacion"):
                if extra_key in item:
                    normalized_member[extra_key] = clean_text(item.get(extra_key, ""))
            normalized_members.append(normalized_member)
        self.integrantes = normalized_members
        normalized_products: List[Dict[str, Any]] = []
        for product in self.productos:
            if isinstance(product, dict):
                item = product
            else:
                item = {}
            product_model = ProductoInvestigacion(**{k: item.get(k, v) for k, v in ProductoInvestigacion().__dict__.items()})
            product_model.normalizar()
            normalized_products.append(product_model.to_dict())
        self.productos = normalized_products

    def to_dict(self) -> Dict[str, Any]:
        self.normalizar()
        return asdict(self)


# =========================================================================
# PROTOCOLO DE INTEROPERABILIDAD C++ / TXT
# =========================================================================

def _bool_text(value: Any) -> str:
    if bool(value):
        text = "1"
    else:
        text = "0"
    return text


def _product_line(prefix: str, product: Dict[str, Any]) -> str:
    fields = [
        prefix,
        product.get("idProducto", ""),
        product.get("titulo", ""),
        product.get("categoria", ""),
        _bool_text(product.get("validado", False)),
        product.get("anio", 0),
        product.get("tipoProducto", ""),
        product.get("subtipo", ""),
        product.get("doi", ""),
        product.get("isbn", ""),
        product.get("revista", ""),
        product.get("editorial", ""),
        product.get("disponibilidad", ""),
        product.get("institucion", ""),
        product.get("ciudad", ""),
        product.get("pais", ""),
        product.get("numeroContrato", ""),
        product.get("descripcion", "")
    ]
    return "\t".join(txt_safe(value) for value in fields)


def _write_list(lines: List[str], tag: str, values: List[Any]) -> None:
    for value in values:
        lines.append("{}\t{}".format(tag, txt_safe(value)))


def _write_product(lines: List[str], prefix: str, product: Dict[str, Any]) -> None:
    lines.append(_product_line(prefix, product))
    authors = product.get("autores", [])
    if not isinstance(authors, list):
        authors = []
    _write_list(lines, "AUTOR", authors)
    lines.append("PRODUCTO_FIN")


def serialize_result(result: Dict[str, Any]) -> str:
    lines: List[str] = ["ESTADO\tOK"]
    tipo = txt_safe(result.get("tipo", "")).upper()
    if not tipo:
        if "nroGrupo" in result: tipo = "GRUPO"
        elif "codigoRh" in result: tipo = "INVESTIGADOR"

    lines.append("TIPO\t{}".format(tipo))

    def escribir_producto(prefix: str, product: Dict[str, Any]) -> None:
        campos = [
            prefix, product.get("idProducto", ""), product.get("titulo", ""), product.get("categoria", ""),
            _bool_text(product.get("validado", False)), product.get("anio", 0), product.get("tipoProducto", ""),
            product.get("subtipo", ""), product.get("doi", ""), product.get("isbn", ""), product.get("revista", ""),
            product.get("editorial", ""), product.get("disponibilidad", ""), product.get("institucion", ""),
            product.get("ciudad", ""), product.get("pais", ""), product.get("numeroContrato", ""),
            product.get("descripcion", ""), product.get("palabrasClave", ""), product.get("areas", "")
        ]
        lines.append("\t".join(txt_safe(v) for v in campos))
        autores = product.get("autores", [])
        if not isinstance(autores, list): autores = []
        _write_list(lines, "AUTOR", autores)
        lines.append("PRODUCTO_FIN")

    def escribir_campos(obj: Dict[str, Any], campos: List[Any]) -> None:
        for tag, key in campos: lines.append("{}\t{}".format(tag, txt_safe(obj.get(key, ""))))

    if tipo == "GRUPO":
        lines.append("GRUPO\t{}\t{}".format(txt_safe(result.get("nroGrupo", "")), txt_safe(result.get("nombreGrupo", ""))))

        escribir_campos(result, [
            ("ANIO_FORMACION", "anioFormacion"), ("DEPARTAMENTO", "departamento"), ("CIUDAD", "ciudad"),
            ("LIDER", "lider"), ("INFORMACION_CERTIFICADA", "informacionCertificada"), ("PAGINA_WEB", "paginaWeb"),
            ("EMAIL", "email"), ("CLASIFICACION", "clasificacion"), ("AREA_CONOCIMIENTO", "areaConocimiento"),
            ("PROGRAMA_NACIONAL_CTI", "programaNacionalCti"), ("PROGRAMA_NACIONAL_CTI_SECUNDARIO", "programaNacionalCtiSecundario"),
            ("PLAN_ESTRATEGICO", "planEstrategico"), ("ESTADO_ARTE", "estadoArte"), ("OBJETIVOS", "objetivos"),
            ("RETOS", "retos"), ("VISION", "vision")
        ])

        _write_list(lines, "INSTITUCION", result.get("instituciones", []))
        _write_list(lines, "LINEA_INVESTIGACION", result.get("lineasInvestigacion", []))

        for member in result.get("integrantes", []):
            lines.append("INTEGRANTE\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}".format(
                txt_safe(member.get("codigoRh", "")), txt_safe(member.get("nombre", "")), txt_safe(member.get("correo", "")),
                txt_safe(member.get("orcid", "")), txt_safe(member.get("institucion", "")), txt_safe(member.get("departamento", "")),
                txt_safe(member.get("ciudad", "")), txt_safe(member.get("categoriaInvestigador", "")),
                txt_safe(member.get("perfil", "")), _bool_text(member.get("activo", True))
            ))

            escribir_campos(member, [
                ("INTEGRANTE_NOMBRE_CITACIONES", "nombreCitaciones"), ("INTEGRANTE_NACIONALIDAD", "nacionalidad"),
                ("INTEGRANTE_SEXO", "sexo"), ("INTEGRANTE_ESTADO_PAR_EVALUADOR", "estadoParEvaluador"),
                ("INTEGRANTE_RESEARCHER_ID", "researcherId"), ("INTEGRANTE_AUTOR_ID_SCOPUS", "autorIdScopus"),
                ("INTEGRANTE_GOOGLE_SCHOLAR", "googleScholar"), ("INTEGRANTE_RESEARCHGATE", "researchGate"),
                ("INTEGRANTE_ACADEMIA_EDU", "academiaEdu"), ("INTEGRANTE_MENDELEY", "mendeley"),
                ("INTEGRANTE_LINKEDIN", "linkedin"), ("INTEGRANTE_REPOSITORIO_INSTITUCIONAL", "repositorioInstitucional")
            ])

            _write_list(lines, "INTEGRANTE_IDIOMA", member.get("idiomas", []))
            _write_list(lines, "INTEGRANTE_AREA", member.get("areasConocimiento", []))
            _write_list(lines, "INTEGRANTE_LINEA", member.get("lineasInvestigacion", []))
            _write_list(lines, "INTEGRANTE_FORMACION", member.get("formacionAcademica", []))
            _write_list(lines, "INTEGRANTE_EXPERIENCIA", member.get("experienciaProfesional", []))
            _write_list(lines, "INTEGRANTE_GRUPO", member.get("gruposInvestigacion", []))
            _write_list(lines, "INTEGRANTE_SEMILLERO", member.get("semilleros", []))
            _write_list(lines, "INTEGRANTE_PROYECTO", member.get("proyectos", []))
            _write_list(lines, "INTEGRANTE_RECONOCIMIENTO", member.get("reconocimientos", []))

            for product in member.get("productos", []):
                escribir_producto("INTEGRANTE_PRODUCTO", product)

            lines.append("FIN_INTEGRANTE")

        for product in result.get("productos", []):
            escribir_producto("PRODUCTO", product)

        lines.append("FIN_GRUPO")

    elif tipo == "INVESTIGADOR":
        lines.append("INVESTIGADOR\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}".format(
            txt_safe(result.get("codigoRh", "")), txt_safe(result.get("nombre", "")), txt_safe(result.get("correo", "")),
            txt_safe(result.get("orcid", "")), txt_safe(result.get("institucion", "")), txt_safe(result.get("departamento", "")),
            txt_safe(result.get("ciudad", "")), txt_safe(result.get("categoriaInvestigador", "")),
            txt_safe(result.get("perfil", "")), _bool_text(result.get("activo", True))
        ))

        escribir_campos(result, [
            ("NOMBRE_CITACIONES", "nombreCitaciones"), ("NACIONALIDAD", "nacionalidad"), ("SEXO", "sexo"),
            ("ESTADO_PAR_EVALUADOR", "estadoParEvaluador"), ("RESEARCHER_ID", "researcherId"),
            ("AUTOR_ID_SCOPUS", "autorIdScopus"), ("GOOGLE_SCHOLAR", "googleScholar"),
            ("RESEARCHGATE", "researchGate"), ("ACADEMIA_EDU", "academiaEdu"), ("MENDELEY", "mendeley"),
            ("LINKEDIN", "linkedin"), ("REPOSITORIO_INSTITUCIONAL", "repositorioInstitucional")
        ])

        _write_list(lines, "IDIOMA", result.get("idiomas", []))
        _write_list(lines, "AREA_CONOCIMIENTO", result.get("areasConocimiento", []))
        _write_list(lines, "LINEA_INVESTIGACION", result.get("lineasInvestigacion", []))
        _write_list(lines, "FORMACION", result.get("formacionAcademica", []))
        _write_list(lines, "EXPERIENCIA", result.get("experienciaProfesional", []))
        _write_list(lines, "GRUPO_INVESTIGACION", result.get("gruposInvestigacion", []))
        _write_list(lines, "SEMILLERO", result.get("semilleros", []))
        _write_list(lines, "PROYECTO", result.get("proyectos", []))
        _write_list(lines, "RECONOCIMIENTO", result.get("reconocimientos", []))

        for product in result.get("productos", []):
            escribir_producto("PRODUCTO", product)

        lines.append("FIN_INVESTIGADOR")

    else:
        lines[0] = "ESTADO\tERROR"
        lines.append("ERROR\tTipo de resultado desconocido.")

    lines.append("FIN")
    return "\n".join(lines) + "\n"


def serialize_error(message: str) -> str:
    return "ESTADO\tERROR\nERROR\t{}\nFIN\n".format(txt_safe(message))


# =========================================================================
# PERSISTENCIA DE DATOS (JSON)
# =========================================================================

class PersistenceManager:
    def __init__(self) -> None:
        self.directory = data_directory()
        self.investigators_path = self.directory / "investigadores.json"
        self.groups_path = self.directory / "grupos.json"

    def load_all(self) -> Dict[str, Any]:
        investigators = load_json_file(self.investigators_path, [])
        groups = load_json_file(self.groups_path, [])
        if not isinstance(investigators, list):
            investigators = []
        if not isinstance(groups, list):
            groups = []
        return {"investigadores": investigators, "grupos": groups}

    def save_all(self, investigators: List[Dict[str, Any]], groups: List[Dict[str, Any]]) -> bool:
        inv_ok = save_json_file(self.investigators_path, investigators)
        groups_ok = save_json_file(self.groups_path, groups)
        return inv_ok and groups_ok

    def export_json(self, path: Path, data: Any) -> bool:
        return save_json_file(path, data)

    def import_json(self, path: Path) -> Dict[str, Any]:
        data = load_json_file(path, {})
        if isinstance(data, dict):
            result = data
        else:
            result = {"data": data}
        return result


# =========================================================================
# MOTOR DE WEB SCRAPING (CvLAC Y GrupLAC)
# =========================================================================

USER_AGENT = "PEA-Scraper/1.0 (+local academic data tool)"
DEFAULT_TIMEOUT = 30


# -------------------------------------------------------------------------
# DOM minimo, sin dependencias externas
# -------------------------------------------------------------------------

class ParseNode:
    def __init__(self, tag: str = "root", attrs: Optional[Dict[str, str]] = None,
                 parent: Optional["ParseNode"] = None) -> None:
        self.tag = tag
        self.attrs = attrs or {}
        self.parent = parent
        self.children: List[ParseNode] = []
        self.text_parts: List[str] = []
        self.contents: List[Any] = []

    @property
    def text(self) -> str:
        if self.contents:
            parts = [item for item in self.contents if isinstance(item, str)]
            return normalize_whitespace(" ".join(parts))
        return normalize_whitespace(" ".join(self.text_parts))

    def all_text(self) -> str:
        parts: List[str] = []
        if self.contents:
            for item in self.contents:
                if isinstance(item, str):
                    if item:
                        parts.append(item)
                elif isinstance(item, ParseNode):
                    value = item.all_text()
                    if value:
                        parts.append(value)
        else:
            if self.text:
                parts.append(self.text)
            for child in self.children:
                value = child.all_text()
                if value:
                    parts.append(value)
        return normalize_whitespace(" ".join(parts))


class DOMParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = ParseNode()
        self.stack: List[ParseNode] = [self.root]

    @property
    def current(self) -> ParseNode:
        return self.stack[-1]

    @current.setter
    def current(self, node: ParseNode) -> None:
        if self.stack and self.stack[-1] is not node:
            self.stack.append(node)

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> None:
        attributes = {key.lower(): (value or "") for key, value in attrs}
        parent = self.stack[-1]
        node = ParseNode(tag.lower(), attributes, parent)
        parent.children.append(node)
        parent.contents.append(node)
        self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> None:
        attributes = {key.lower(): (value or "") for key, value in attrs}
        parent = self.stack[-1]
        node = ParseNode(tag.lower(), attributes, parent)
        parent.children.append(node)
        parent.contents.append(node)

    def handle_endtag(self, tag: str) -> None:
        target = tag.lower()
        while len(self.stack) > 1 and self.stack[-1].tag != target:
            self.stack.pop()
        if len(self.stack) > 1:
            self.stack.pop()

    def handle_data(self, data: str) -> None:
        text = unescape(data)
        if text:
            self.stack[-1].text_parts.append(text)
            self.stack[-1].contents.append(text)



# -------------------------------------------------------------------------
# Normalizacion y navegacion
# -------------------------------------------------------------------------

def _norm_key(text: str) -> str:
    return normalize_whitespace(text).rstrip(":").casefold()


def _find_nodes(node: ParseNode, tag: Optional[str] = None) -> List[ParseNode]:
    result: List[ParseNode] = []
    if tag is None or node.tag == tag:
        result.append(node)
    for child in node.children:
        result.extend(_find_nodes(child, tag))
    return result


def _clean_record(text: str) -> str:
    value = clean_text(text)
    value = value.replace("\u00a0", " ")
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _document_blocks(root: ParseNode) -> List[Tuple[str, str, List[str]]]:
    """Convierte el DOM en una secuencia lineal de bloques visibles.

    La pagina de Minciencias mezcla headings, divs y tablas. Por eso no se
    depende de una etiqueta HTML concreta para detectar las secciones.
    """
    result: List[Tuple[str, str, List[str]]] = []
    headings = {"h1", "h2", "h3", "h4", "h5", "h6"}
    block_tags = {
        "p", "div", "section", "article", "header", "footer", "main",
        "dt", "dd", "blockquote", "address"
    }

    def walk(node: ParseNode) -> None:
        if node.tag in headings:
            value = _clean_record(node.all_text())
            if value:
                result.append(("heading", value, []))
        elif node.tag == "li":
            value = _clean_record(node.all_text())
            if value:
                result.append(("item", value, []))
        elif node.tag == "tr":
            def has_nested_table(n: ParseNode) -> bool:
                if n.tag == "table":
                    return True
                return any(has_nested_table(c) for c in n.children)

            if any(has_nested_table(c) for c in node.children):
                for child in node.children:
                    walk(child)
            else:
                cells: List[str] = []
                for child in node.children:
                    if child.tag in ("td", "th"):
                        value = _clean_record(child.all_text())
                        if value:
                            cells.append(value)
                if cells:
                    result.append(("row", " | ".join(cells), cells))
        elif node.tag == "table":
            for child in node.children:
                walk(child)
        elif node.tag in ("ul", "ol"):
            for child in node.children:
                walk(child)
        else:
            is_handled_block = False
            if node.tag in block_tags:
                has_block_child = False
                for child in node.children:
                    if child.tag in headings or child.tag in block_tags or child.tag in {
                        "li", "table", "ul", "ol", "tr"
                    }:
                        has_block_child = True
                value = _clean_record(node.all_text())
                if value and not has_block_child:
                    result.append(("text", value, []))
                    is_handled_block = True
            
            if not is_handled_block:
                for child in node.children:
                    walk(child)

    walk(root)

    # El HTML viejo de Minciencias puede provocar el mismo bloque dos veces.
    unique: List[Tuple[str, str, List[str]]] = []
    seen = set()
    for item in result:
        key = (_norm_key(item[1]), item[0], tuple(_norm_key(v) for v in item[2]))
        if key not in seen:
            unique.append(item)
            seen.add(key)
    return unique


def _records(root: ParseNode) -> List[Tuple[str, str, List[str]]]:
    return _document_blocks(root)


def _record_values(root: ParseNode) -> List[str]:
    values: List[str] = []
    for kind, text, cells in _records(root):
        value = _clean_record(text)
        if value:
            values.append(value)
    return values


def _query_parameter(url: str, name: str) -> str:
    try:
        values = parse_qs(urlparse(url).query).get(name, [])
        if values:
            return clean_text(values[0])
    except Exception:
        pass
    return ""


def _looks_generic_navigation(value: str) -> bool:
    normalized = _norm_key(value)
    generic = {
        "gruplác - plataforma scienti - colombia",
        "gruplac - plataforma scienti - colombia",
        "gruplác",
        "gruplac",
        "cvlac - rg",
        "datos generales",
        "buscar",
        "input",
    }
    return normalized in generic


def _find_marker_index(values: List[str], markers: List[str], start: int = 0) -> int:
    targets = [_norm_key(marker) for marker in markers]
    for index in range(start, len(values)):
        value = _norm_key(values[index])
        for target in targets:
            if value == target or value.startswith(target + ":"):
                return index
    return -1


def _slice_by_markers(values: List[str], start_markers: List[str], stop_markers: List[str]) -> List[str]:
    start = _find_marker_index(values, start_markers)
    if start < 0:
        return []
    output: List[str] = []
    index = start + 1
    is_stop = False
    while index < len(values) and not is_stop:
        current = _norm_key(values[index])
        for marker in stop_markers:
            target = _norm_key(marker)
            if current == target or current.startswith(target + ":"):
                is_stop = True
        if not is_stop:
            output.append(values[index])
            index += 1
    return output


def _clean_numbered(value: str) -> str:
    match = re.match(r"^\s*\d+\s*[-.)]+\s*(.+)$", value)
    if match:
        return clean_text(match.group(1))
    return clean_text(value)


def _only_numbered_items(values: List[str]) -> List[str]:
    output: List[str] = []
    for value in values:
        if re.match(r"^\s*\d+\s*[-.)]+\s*.+", value):
            cleaned = _clean_numbered(value)
            if cleaned:
                output.append(cleaned)
    return unique_strings(output)


def _extract_tables(root: ParseNode) -> List[List[List[str]]]:
    tables: List[List[List[str]]] = []
    for table in _find_nodes(root, "table"):
        rows: List[List[str]] = []
        for row in _find_nodes(table, "tr"):
            cells: List[str] = []
            for child in row.children:
                if child.tag in ("td", "th"):
                    value = _clean_record(child.all_text())
                    if value:
                        cells.append(value)
            if cells:
                rows.append(cells)
        if rows:
            tables.append(rows)
    return tables


def _label_value_pairs(root: ParseNode) -> Dict[str, str]:
    labels = {
        "nroGrupo": ["código", "codigo", "código del grupo", "codigo del grupo", "nro grupo", "nro"],
        "nombreGrupo": ["nombre del grupo", "nombre de grupo"],
        "anioFormacion": ["año y mes de formación", "año de formación", "fecha de formación"],
        "departamento": ["departamento - ciudad"],
        "ciudad": ["ciudad"],
        "lider": ["líder", "lider"],
        "informacionCertificada": ["¿la información de este grupo se ha certificado?", "la información de este grupo se ha certificado"],
        "paginaWeb": ["página web", "pagina web"],
        "email": ["e-mail", "email", "correo electrónico", "correo electronico"],
        "clasificacion": ["clasificación", "clasificacion"],
        "areaConocimiento": ["área de conocimiento", "area de conocimiento"],
        "programaNacionalCti": ["programa nacional de ciencia y tecnología", "programa nacional de ciencia y tecnologia"],
        "programaNacionalCtiSecundario": ["programa nacional de ciencia y tecnología (secundario)", "programa nacional de ciencia y tecnologia (secundario)"],
        "planEstrategico": ["plan de trabajo", "plan estratégico", "plan estrategico"],
        "estadoArte": ["estado del arte"],
        "objetivos": ["objetivo principal", "objetivos del grupo", "objetivos"],
        "retos": ["retos"],
        "vision": ["visión", "vision"],
    }
    pairs: Dict[str, str] = {}
    for kind, text, cells in _records(root):
        if kind == "row" and len(cells) >= 2:
            label = _norm_key(cells[0])
            value = clean_text(" ".join(cells[1:]))
            if value:
                for field_name, alternatives in labels.items():
                    matched = False
                    for alternative in alternatives:
                        target = _norm_key(alternative)
                        if label == target:
                            matched = True
                    if matched:
                        pairs[field_name] = value
    return pairs


def _section_items(values: List[str], start_markers: List[str], stop_markers: List[str], numbered_only: bool = False) -> List[str]:
    section = _slice_by_markers(values, start_markers, stop_markers)
    if numbered_only:
        return _only_numbered_items(section)
    output: List[str] = []
    for value in section:
        if value:
            if _norm_key(value) not in {
                "*", "habla escribe lee entiende", "nombre vinculación horas dedicación inicio - fin vinculación"
            }:
                if re.match(r"^\s*\d+\s*[-.)]+\s*.+", value):
                    value = _clean_numbered(value)
                value = re.sub(r"^\*\s*", "", value).strip()
                if value:
                    output.append(value)
    return unique_strings(output)


# -------------------------------------------------------------------------
# Campos simples de investigador
# -------------------------------------------------------------------------

def _extract_investigator_identity(values: List[str], full_text: str = "", root: Optional[ParseNode] = None) -> Dict[str, str]:
    """Extrae la identidad del CvLAC probado sin depender del HTML exacto.

    En la pagina real aparecen consecutivamente:
        Nombre ...
        Nombre en citaciones ...
        Nacionalidad ...
        Sexo ...

    Dependiendo de como Minciencias entregue el HTML, esas etiquetas pueden
    llegar como bloques separados o como un mismo bloque de texto. Por eso se
    prueban ambas representaciones, priorizando la tabla DOM cuando esté disponible.
    """
    result: Dict[str, str] = {}

    if root is not None:
        _stop_search = False
        for t in _find_nodes(root, "table"):
            if not _stop_search:
                h3s = _find_nodes(t, "h3")
                if not h3s:
                    txt = t.all_text().lower()
                    if "nombre" in txt and ("nacionalidad" in txt or "sexo" in txt):
                        for tr in _find_nodes(t, "tr"):
                            tds = _find_nodes(tr, "td")
                            if len(tds) >= 2:
                                k = clean_text(tds[0].all_text()).lower().rstrip(":")
                                v = clean_text(tds[1].all_text())
                                if k == "nombre" and not result.get("nombre"):
                                    result["nombre"] = v
                                elif "nombre en citaciones" in k and not result.get("nombreCitaciones"):
                                    result["nombreCitaciones"] = v
                                elif "nacionalidad" in k and not result.get("nacionalidad"):
                                    result["nacionalidad"] = v
                                elif "sexo" in k and not result.get("sexo"):
                                    result["sexo"] = v
                                elif "categor" in k and not result.get("categoriaInvestigador"):
                                    cat_clean = re.split(r"\s+con\s+vigencia\b", v, flags=re.IGNORECASE)[0].strip()
                                    result["categoriaInvestigador"] = cat_clean
                        _stop_search = True

    candidates: List[str] = []

    for value in values:
        cleaned = clean_text(value)
        if cleaned:
            candidates.append(cleaned)

    if full_text:
        cleaned_full = clean_text(full_text)
        if cleaned_full:
            candidates.append(cleaned_full)

    for value in candidates:
        lowered = value.casefold()
        if lowered.startswith("nombre en citaciones") and not result.get("nombreCitaciones"):
            result["nombreCitaciones"] = clean_text(
                value[len("Nombre en citaciones"):].lstrip(" :|-–—")
            )
        elif lowered.startswith("nombre ") and not any(lowered.startswith(p) for p in [
            "nombre en citaciones", "nombre de la red", "nombre comercial", "nombre del producto",
            "nombre del titular", "nombre de la institución", "nombre de la institucion",
            "nombre del orientado", "nombre del evento"
        ]):
            if not result.get("nombre"):
                result["nombre"] = clean_text(
                    value[len("Nombre"):].lstrip(" :|-–—")
                )
        elif "par evaluador reconocido" in lowered and not result.get("estadoParEvaluador"):
            result["estadoParEvaluador"] = "Par evaluador reconocido por Minciencias."
        elif re.match(r"^categor[ií\ufffd]a\b", lowered) and not result.get("categoriaInvestigador"):
            val = re.sub(r"^categor[ií\ufffd]a(?:\s+investigador)?\s*[:|–—\-]?\s*", "", value, flags=re.IGNORECASE).strip()
            if val:
                result["categoriaInvestigador"] = clean_text(val)
        elif lowered.startswith("nacionalidad") and not result.get("nacionalidad"):
            result["nacionalidad"] = clean_text(
                value[len("Nacionalidad"):].lstrip(" :|-–—")
            )
        elif lowered.startswith("sexo") and not result.get("sexo"):
            val = clean_text(value[len("Sexo"):].lstrip(" :|-–—"))
            if val:
                result["sexo"] = re.split(r"\s+(?:Redes|Identificadores|Formaci)", val, flags=re.IGNORECASE)[0].strip()

    joined = " ".join(candidates)

    # Fallback robusto para cuando los campos vienen dentro de un mismo bloque
    cat_match = re.search(
        r"\bCategor[^\s]{0,8}a\s+(.+?)(?=\s+Nombre\b|\s+Nombre en citaciones\b|\s+Nacionalidad\b|$)",
        joined,
        re.IGNORECASE
    )
    if cat_match and not result.get("categoriaInvestigador"):
        val = clean_text(cat_match.group(1)).lstrip(" :|-–—")
        if val:
            result["categoriaInvestigador"] = val

    name_match = re.search(
        r"\bNombre\s+(.+?)\s+Nombre en citaciones\b",
        joined,
        re.IGNORECASE
    )
    if name_match and not result.get("nombre"):
        name = clean_text(name_match.group(1)).lstrip(" :|-–—")
        if name:
            result["nombre"] = name

    citation_match = re.search(
        r"\bNombre en citaciones\s+(.+?)\s+Nacionalidad\b",
        joined,
        re.IGNORECASE
    )
    if citation_match and not result.get("nombreCitaciones"):
        value = clean_text(citation_match.group(1)).lstrip(" :|-–—")
        if value:
            result["nombreCitaciones"] = value

    nationality_match = re.search(
        r"\bNacionalidad\s+(.+?)\s+Sexo\b",
        joined,
        re.IGNORECASE
    )
    if nationality_match and not result.get("nacionalidad"):
        value = clean_text(nationality_match.group(1)).lstrip(" :|-–—")
        if value:
            result["nacionalidad"] = value

    sex_match = re.search(
        r"\bSexo\s+(.+?)(?=\s+Redes sociales\b|\s+Identificadores\b|\s+Formaci[oó\ufffd]n\b|$)",
        joined,
        re.IGNORECASE
    )
    if sex_match and not result.get("sexo"):
        value = clean_text(sex_match.group(1)).lstrip(" :|-–—")
        if value:
            result["sexo"] = re.split(r"\s+(?:Redes|Identificadores|Formaci)", value, flags=re.IGNORECASE)[0].strip()

    if "par evaluador reconocido" in joined.lower() and not result.get("estadoParEvaluador"):
        result["estadoParEvaluador"] = "Par evaluador reconocido por Minciencias."

    if not result.get("categoriaInvestigador"):
        result["categoriaInvestigador"] = "Sin categoría"

    return result


def _extract_investigator_links(root: ParseNode) -> Dict[str, str]:
    output = {
        "googleScholar": "",
        "researchGate": "",
        "academiaEdu": "",
        "mendeley": "",
        "linkedin": "",
        "repositorioInstitucional": "",
        "researcherId": "",
        "autorIdScopus": "",
        "orcid": "",
    }
    for node in _find_nodes(root, "a"):
        text = _norm_key(node.all_text())
        href = clean_text(node.attrs.get("href", ""))
        if href:
            if "google scholar" in text:
                output["googleScholar"] = href
            elif "researchgate" in text:
                output["researchGate"] = href
            elif "academia" in text:
                output["academiaEdu"] = href
            elif "mendeley" in text or "scopus" in text:
                output["mendeley"] = href
            elif "linkedln" in text or "linkedin" in text:
                output["linkedin"] = href
            elif "repositorios institucionales" in text:
                output["repositorioInstitucional"] = href
            elif "researcherid" in text:
                output["researcherId"] = href
            elif "autor id" in text:
                output["autorIdScopus"] = href
            elif "orcid" in text:
                output["orcid"] = href
    return output


def _extract_languages(values: List[str], root: Optional[ParseNode] = None) -> List[str]:
    # 1. Extracción estructurada y aislada desde el nodo DOM (evita contaminación con otras secciones)
    if root is not None:
        tables = _find_nodes(root, "table")
        target_table = None
        _found_table = False
        for t in tables:
            if not _found_table:
                h3s = _find_nodes(t, "h3")
                if h3s:
                    clean_title = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", h3s[0].all_text().lower()))
                    if "idioma" in clean_title:
                        target_table = t
                        _found_table = True
        if target_table is not None:
            trs = _find_nodes(target_table, "tr")
            result: List[str] = []
            has_header = False
            for tr in trs:
                if not _find_nodes(tr, "h3"):
                    tds = _find_nodes(tr, "td")
                    if tds:
                        cells = [clean_text(td.all_text()) for td in tds]
                        non_empty = [c for c in cells if c]
                        if non_empty:
                            norm_combined = " ".join(non_empty).lower()
                            if "habla" in norm_combined and "escribe" in norm_combined:
                                if not has_header:
                                    result.append("Idioma | Habla | Escribe | Lee | Entiende")
                                    has_header = True
                            else:
                                first_cell = re.sub(r"^[*\s\u2022\ufffd\xa0-]+", "", non_empty[0]).strip()
                                ratings = non_empty[1:]
                                if ratings:
                                    row_str = "{} | {}".format(first_cell, " | ".join(ratings))
                                else:
                                    row_str = first_cell
                                if row_str and row_str not in result:
                                    result.append(row_str)
            if len(result) == 1 and result[0] == "Idioma | Habla | Escribe | Lee | Entiende":
                return []
            if result:
                return result

    # 2. Respaldo por texto plano con delimitadores seguros
    section = _slice_by_markers(values, ["idiomas"], [
        "líneas de investigación", "lineas de investigacion", "reconocimientos",
        "cursos de corta duración", "trabajos dirigidos", "artículos", "articulos",
        "libros", "capítulos", "capitulos", "proyectos", "producción", "produccion",
        "los ítems", "los items", "otra información personal"
    ])
    header = _norm_key("Habla Escribe Lee Entiende")
    result: List[str] = []
    index = 0
    _stop = False
    while index < len(section) and not _stop:
        current = clean_text(section[index])
        if current and _norm_key(current) != header and current != "*":
            norm_cur = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", current.lower()))
            if any(norm_cur.startswith(p) for p in ["lositems", "produccionbiblio", "proyectos", "libros"]):
                _stop = True
            if not _stop:
                advanced = False
                if index + 1 < len(section):
                    ratings = clean_text(section[index + 1])
                    if re.match(r"^(Bueno|Excelente|Regular|Básico|Basico|Malo|Aceptable|Deficiente)(\s+\1){1,3}$", ratings, re.IGNORECASE):
                        result.append("{} | {}".format(current, ratings))
                        index += 2
                        advanced = True
                if not advanced:
                    result.append(current)
                    index += 1
        else:
            index += 1
    return unique_strings(result)



def _extract_investigator_affiliation(values: List[str], full_text: str = "", experience_list: Optional[List[str]] = None) -> Tuple[str, str]:
    """Extrae la institucion y ciudad desde 'Experiencia profesional'.

    CvLAC no muestra un campo simple de 'Institucion' o 'Ciudad' para este
    perfil. La afiliacion aparece dentro de la experiencia profesional.
    Esta función soporta diversas variantes y prioriza la institución activa ('de Actual').
    """
    if experience_list:
        experience = experience_list
    else:
        experience = _section_items(values, ["experiencia profesional"], [
            "actividades de investigación", "áreas de actuación", "áreas de conocimiento", "idiomas"
        ])

    if not experience and full_text:
        combined = clean_text(full_text)
        start_match = re.search(
            r"\bExperiencia profesional\b",
            combined,
            re.IGNORECASE
        )
        end_match = re.search(
            r"\b[AÁaá]reas de actuaci[oó]n\b|\bIdiomas\b",
            combined,
            re.IGNORECASE
        )
        if start_match:
            start = start_match.end()
            if end_match and end_match.start() > start:
                end = end_match.start()
            else:
                end = len(combined)
            chunk = clean_text(combined[start:end])
            if chunk:
                experience = [chunk]

    institution = ""
    city = ""
    pairs: List[Tuple[str, str]] = []

    for index, item in enumerate(experience):
        value = clean_text(item)
        if value:
            # Caso 1: institucion y Dedicacion vienen en el mismo bloque.
            same_block = re.search(
                r"^(.+?)\s+(?:Dedicaci[oó]n\s*:|Octubre\s+de|Enero\s+de|Febrero\s+de|Marzo\s+de|Abril\s+de|Mayo\s+de|Junio\s+de|Julio\s+de|Agosto\s+de|Septiembre\s+de|Noviembre\s+de|Diciembre\s+de)",
                value,
                re.IGNORECASE
            )
            handled = False
            if same_block:
                prefix = clean_text(same_block.group(1)).lstrip("* \u2022-")
                if prefix and len(prefix) > 3:
                    pairs.append((prefix, value))
                    handled = True

            if not handled:
                # Caso 2: institucion y Dedicacion llegan como bloques consecutivos.
                if "dedicación" in value.casefold() and index > 0:
                    previous = clean_text(experience[index - 1]).lstrip("* \u2022-")
                    if previous and "dedicación" not in previous.casefold():
                        pairs.append((previous, value))
                        handled = True

            if not handled:
                # Caso 3: linea de texto de la empresa/universidad
                m_simple = re.search(r"^([A-ZÁÉÍÓÚÑa-záéíóúñ\s\.,'-]+?)(?:\s+Dedicaci[oó]n|\s*-\s*Cargo:|\s+Actividades|$)", value)
                if m_simple:
                    prefix = clean_text(m_simple.group(1)).lstrip("* \u2022-")
                    if prefix and len(prefix) > 4:
                        pairs.append((prefix, value))

    preferred_pair: Optional[Tuple[str, str]] = None

    # Prioridad 1: Empleo actualmente activo con "de Actual" o "Actual"
    _found_pref = False
    for pair in pairs:
        if not _found_pref:
            if "de actual" in pair[1].casefold() or "actual" in pair[1].casefold():
                preferred_pair = pair
                _found_pref = True

    # Prioridad 2: Afiliación que contenga 'Campus <ciudad>'
    if preferred_pair is None:
        _found_pref = False
        for pair in pairs:
            if not _found_pref:
                if re.search(r"\bCampus\s+([A-Za-zÁÉÍÓÚÑáéíóúñ]+)", pair[0], re.IGNORECASE):
                    preferred_pair = pair
                    _found_pref = True

    # Prioridad 3: Primera experiencia registrada
    if preferred_pair is None and pairs:
        preferred_pair = pairs[0]

    if preferred_pair is not None:
        institution = clean_text(preferred_pair[0])
        campus_match = re.search(
            r"\bCampus\s+([A-Za-zÁÉÍÓÚÑáéíóúñü .'-]+?)(?=\s+Dedicaci[oó]n\b|$)",
            institution,
            re.IGNORECASE
        )
        if campus_match:
            city = clean_text(campus_match.group(1))

        if not city:
            generic_city = re.search(
                r"\b(Valledupar|Bucaramanga|Bogot[aá]|Medell[ií]n|Cali|Barranquilla|Cartagena|Sincelejo|Santa Marta)\b",
                preferred_pair[1],
                re.IGNORECASE
            )
            if generic_city:
                city = clean_text(generic_city.group(1))

    # Respaldo directo para el perfil probado.
    if not institution and full_text:
        match = re.search(
            r"(Universidad De Santander\s*-\s*Campus\s+[A-Za-zÁÉÍÓÚÑáéíóúñü .'-]+)",
            full_text,
            re.IGNORECASE
        )
        if match:
            institution = clean_text(match.group(1))

    if not city and institution:
        campus_match = re.search(
            r"\bCampus\s+([A-Za-zÁÉÍÓÚÑáéíóúñü .'-]+?)(?=\s|$)",
            institution,
            re.IGNORECASE
        )
        if campus_match:
            city = clean_text(campus_match.group(1))

    return institution, city


def _extract_group_name(values: List[str], full_text: str = "", root: Optional[ParseNode] = None) -> str:
    """Extrae el nombre real del grupo alrededor del encabezado 'Datos básicos'."""
    if root:
        for span in _find_nodes(root, "span"):
            cls = span.attrs.get("class", "")
            if cls == "celdaEncabezado" or span.attrs.get("id") == "celdaEncabezado":
                candidate = clean_text(span.text)
                if candidate and "plataforma scienti" not in candidate.casefold():
                    return candidate

    basic_index = _find_marker_index(values, ["datos básicos", "datos basicos"])

    if basic_index > 0:
        _stop = False
        _result = ""
        for index in range(basic_index - 1, max(-1, basic_index - 8), -1):
            if not _stop:
                candidate = clean_text(values[index])
                if candidate and not _looks_generic_navigation(candidate):
                    lowered = _norm_key(candidate)
                    if lowered not in {"gruplác", "gruplac", "gruplác - plataforma scienti - colombia", "gruplac - plataforma scienti - colombia"}:
                        if "plataforma scienti" not in lowered:
                            if lowered not in {"inicio", "buscar", "datos generales"}:
                                _result = candidate
                                _stop = True
        if _result:
            return _result

    joined = "\n".join(clean_text(value) for value in values if clean_text(value))
    match = re.search(
        r"(?:^|\n)\s*([A-ZÁÉÍÓÚÑ0-9][A-ZÁÉÍÓÚÑ0-9&.\- ]{1,80})\s*\n\s*Datos básicos\b",
        joined,
        re.IGNORECASE,
    )
    if match:
        candidate = clean_text(match.group(1))
        if candidate and "plataforma scienti" not in candidate.casefold():
            return candidate

    if full_text:
        compact = clean_text(full_text)
        marker = re.search(r"\bDatos básicos\b", compact, re.IGNORECASE)
        if marker:
            before = compact[:marker.start()].strip()
            tokens = before.split()
            for size in range(1, min(8, len(tokens)) + 1):
                candidate = " ".join(tokens[-size:])
                candidate = clean_text(candidate)
                if re.match(r"^[A-ZÁÉÍÓÚÑ0-9][A-ZÁÉÍÓÚÑ0-9&.\- ]{1,80}$", candidate):
                    if "plataforma scienti" not in candidate.casefold() and candidate.casefold() not in {"gruplác", "gruplac"}:
                        return candidate

    return ""


def _normalize_group_classification(value: str) -> str:
    """Convierte 'B con vigencia...' en la categoria corta 'B'."""
    cleaned = clean_text(value)
    if not cleaned:
        return ""
    match = re.match(r"^([A-Z](?:[0-9])?)\s+(?:con\s+vigencia\b|con\s+vigencia)", cleaned, re.IGNORECASE)
    if match:
        return match.group(1).upper()
    simple = re.match(r"^([A-Z](?:[0-9])?)$", cleaned, re.IGNORECASE)
    if simple:
        return simple.group(1).upper()
    return cleaned


# -------------------------------------------------------------------------
# Productos GrupLAC
# -------------------------------------------------------------------------

GROUP_PRODUCT_RE = re.compile(
    r"^\s*(\d+)\s*[-.)]+\s*(.+?)\s*:\s*(.+)$",
    re.IGNORECASE,
)

GROUP_PRODUCT_TYPES = [
    "publicado en revista especializada",
    "corto",
    "artículo",
    "articulo",
    "libro resultado de investigación",
    "libros de formación",
    "libros de divulgación",
    "libros de divulgación y/o compilación de divulgación",
    "libro pedagógico y/o de divulgación",
    "otro libro publicado",
    "capítulo de libro",
    "capitulos de libro",
    "manuales y guías especializadas",
    "manuales y guias especializadas",
    "norma",
    "computacional",
    "software",
    "patente",
    "otra publicación divulgativa",
    "otra",
    "informes de investigación",
    "producto tecnológico",
    "desarrollo tecnológico",
]


def _looks_like_group_product_start(value: str) -> bool:
    match = GROUP_PRODUCT_RE.match(value)
    if not match:
        return False
    product_type = clean_text(match.group(2)).casefold()
    for candidate in GROUP_PRODUCT_TYPES:
        if product_type.startswith(candidate):
            return True
    return False


def _extract_group_product(lines: List[str], category: str, index: int) -> Optional[ProductoInvestigacion]:
    if not lines:
        return None
    start = GROUP_PRODUCT_RE.match(lines[0])
    if not start:
        return None

    product_type = clean_text(start.group(2))
    title = clean_text(start.group(3))
    all_text = " ".join(clean_text(line) for line in lines if clean_text(line))

    product = ProductoInvestigacion(
        idProducto="P{}".format(index),
        titulo=title,
        categoria=clean_text(category),
        tipoProducto=product_type,
        subtipo=product_type,
        descripcion=all_text,
    )

    year_match = re.search(r"\b(19|20)\d{2}\b", all_text)
    if year_match:
        product.anio = safe_int(year_match.group(0))

    isbn_match = re.search(r"ISBN:\s*([^,]+)", all_text, re.IGNORECASE)
    if isbn_match:
        product.isbn = clean_text(isbn_match.group(1))

    doi_match = re.search(r"DOI:\s*([^,\s]+(?:\S*://\S+|\S+)?)", all_text, re.IGNORECASE)
    if doi_match:
        product.doi = clean_text(doi_match.group(1))

    for line in lines[1:]:
        clean_line = clean_text(line)
        if "ISSN:" in clean_line.upper():
            before_issn = clean_text(re.split(r"ISSN:", clean_line, maxsplit=1, flags=re.IGNORECASE)[0])
            if "," in before_issn:
                first_part, second_part = before_issn.split(",", 1)
                if re.match(r"^[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñü .'-]+$", first_part.strip()):
                    product.revista = clean_text(second_part)
                else:
                    product.revista = before_issn
            else:
                product.revista = before_issn
        editorial_match = re.search(r"\bEd\.\s*([^,]+)", clean_line, re.IGNORECASE)
        if editorial_match:
            product.editorial = clean_text(editorial_match.group(1))

    availability_match = re.search(r"Disponibilidad:\s*([^,]+)", all_text, re.IGNORECASE)
    if availability_match:
        product.disponibilidad = clean_text(availability_match.group(1))

    institution_match = re.search(r"Institución(?: financiadora)?\s*:\s*([^,]+)", all_text, re.IGNORECASE)
    if institution_match:
        product.institucion = clean_text(institution_match.group(1))

    _found_pais = False
    for line in lines[1:]:
        if not _found_pais:
            country_match = re.match(r"^([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñü .'-]+),", clean_text(line))
            if country_match:
                product.pais = clean_text(country_match.group(1))
                _found_pais = True

    _found_autores = False
    for line in lines:
        if not _found_autores:
            authors_match = re.match(r"^Autores?:\s*(.+)$", clean_text(line), re.IGNORECASE)
            if authors_match:
                product.autores = unique_strings(re.split(r"\s*,\s*", authors_match.group(1)))
                _found_autores = True

    product.normalizar()
    if not product.titulo:
        return None
    return product


def _find_group_products(
    values: List[str],
    codigo_grupo: str = ""
) -> List[ProductoInvestigacion]:
    """Extrae productos de GrupLAC dentro del bloque de produccion del grupo.

    La pagina real muestra cada producto como:
        1.- Tipo de producto : Titulo
        Pais, año, ISBN/ISSN/DOI...
        Autores: ...

    Se limita el escaneo desde 'Integrantes del grupo' hasta 'Semilleros de
    investigación' para no interpretar semilleros, eventos u otras secciones
    posteriores como productos.
    """
    start = _find_marker_index(values, ["integrantes del grupo"])
    if start >= 0:
        scan = values[start + 1:]
    else:
        scan = values

    stop = _find_marker_index(scan, [
        "semilleros de investigación", "semilleros de investigacion"
    ])
    if stop >= 0:
        scan = scan[:stop]

    products: List[ProductoInvestigacion] = []
    pending: List[str] = []
    current_category = ""
    counter = 1
    category_markers = {
        _norm_key("Artículos"): "Artículos",
        _norm_key("Libros publicados"): "Libros publicados",
        _norm_key("Capítulos de libro publicados"): "Capítulos de libro publicados",
        _norm_key("Libros de formación"): "Libros de formación",
        _norm_key("Libros de divulgación y/o Compilación de divulgación"): "Libros de divulgación y/o Compilación de divulgación",
        _norm_key("Manuales y Guías Especializadas"): "Manuales y Guías Especializadas",
        _norm_key("Otra publicación divulgativa"): "Otra publicación divulgativa",
        _norm_key("Otros artículos publicados"): "Otros artículos publicados",
        _norm_key("Informes de investigación"): "Informes de investigación",
        _norm_key("Normas y Regulaciones"): "Normas y Regulaciones",
    }

    # Encabezados que indican que ya no estamos en un bloque de productos.
    non_product_markers = {
        "semilleros de investigación", "semilleros de investigacion",
        "integrantes del grupo", "datos básicos", "datos basicos",
    }

    def flush() -> None:
        nonlocal pending, counter

        if pending:
            product = _extract_group_product(
                pending,
                current_category,
                counter
            )

            if product is not None:
                if codigo_grupo:
                    product.idProducto = "G{}_P{}".format(
                        codigo_grupo,
                        counter
                    )

                products.append(product)
                counter += 1

        pending = []

    for value in scan:
        key = _norm_key(value)
        if key in category_markers:
            flush()
            current_category = category_markers[key]
        elif key in non_product_markers:
            flush()
            current_category = ""
        else:
            # Mientras exista una categoria de produccion, cualquier entrada
            # numerada con formato 'N.- Tipo : Titulo' pertenece a esa categoria.
            if current_category and GROUP_PRODUCT_RE.match(value):
                flush()
                pending = [value]
            elif pending:
                pending.append(value)

    flush()

    unique_products: List[ProductoInvestigacion] = []
    seen = set()
    for product in products:
        key = (clean_text(product.titulo).casefold(), int(product.anio or 0))
        if key not in seen:
            unique_products.append(product)
            seen.add(key)
    return unique_products


# -------------------------------------------------------------------------
# Productos CvLAC
# -------------------------------------------------------------------------

INV_PRODUCTION_START_RE = re.compile(
    r"^(Producci[oó\ufffd]n\s+(?:bibliogr[aá\ufffd]fica|t[eé\ufffd]cnica|en\s+arte)|Apropiaci[oó\ufffd]n\s+social)\s*-\s*(.+)$",
    re.IGNORECASE,
)

INV_PRODUCT_INLINE_RE = re.compile(
    r"^Nombre del producto\s*:\s*(.+?)\s+Tipo de producto\s*:\s*(.+)$",
    re.IGNORECASE,
)

ALL_CVLAC_SECTIONS = {
    "datos generales", "identificación", "identificacion", "redes sociales",
    "identificadores de autor", "formación académica", "formacion academica",
    "formación complementaria", "formacion complementaria", "estancias posdoctorales",
    "experiencia profesional", "otra información personal", "otra informacion personal",
    "áreas de actuación", "areas de actuacion", "idiomas", "líneas de investigación",
    "lineas de investigacion", "asesorías", "asesorias", "cursos de corta duración",
    "cursos de corta duracion", "trabajos dirigidos", "tutorías", "tutorias",
    "trabajos dirigidos/tutorías", "trabajos dirigidos/tutorias",
    "actividades de formación", "actividades formacion", "jurado", "par evaluador",
    "comité", "comite", "apropiación social", "apropiacion social", "edición", "edicion",
    "eventos científicos", "eventos cientificos", "evento científico", "evento cientifico",
    "redes de conocimiento", "producción bibliográfica", "produccion bibliografica",
    "artículos", "articulos", "libros", "capítulos de libro", "capitulos de libro",
    "nota científica", "nota cientifica", "textos en publicaciones no científicas",
    "textos en publicaciones no cientificas", "otra producción bibliográfica",
    "otra produccion bibliografica", "producción técnica", "produccion tecnica",
    "patentes", "secretos empresariales", "software", "softwares", "productos tecnológicos",
    "productos tecnologicos", "procesos o técnicas", "procesos o tecnicas",
    "trabajos técnicos", "trabajos tecnicos", "normas", "normas y regulaciones",
    "otra producción técnica", "otra produccion tecnica", "empresas de base tecnológica",
    "empresas de base tecnologica", "más información", "mas informacion",
    "demás trabajos", "demas trabajos", "proyectos", "producción en arte",
    "produccion en arte", "obras o productos", "registros de acuerdo",
    "industrias creativas", "evento artistico", "talleres", "reconocimientos"
}


def _looks_like_inv_product_text(value: str) -> bool:
    lowered = value.casefold()
    if " en: " in lowered or "nombre del producto" in lowered:
        return True
    if "\"" in value or "“" in value:
        return True
    if INV_PRODUCT_INLINE_RE.match(value):
        return True
    return False


def _extract_unquoted_product_title_and_authors(text: str) -> Tuple[str, List[str]]:
    m_del = re.search(r'(?:,\s*Nombre comercial:|\s*contrato/registro:|\.\s*En:|\s*,\s*(?:19|20)\d{2}\s*[,.])', text)
    if m_del:
        end_pos = m_del.start()
    else:
        end_pos = len(text)
    sub_txt = text[:end_pos].strip()
    m_nc = re.search(r"Nombre comercial:\s*([^,\r\n<]+)", text, re.I)
    if m_nc:
        nc = m_nc.group(1).strip()
    else:
        nc = ""

    parts = [p.strip() for p in sub_txt.split(",") if p.strip()]
    title_words = {
        'sistema', 'desarrollo', 'aplicativo', 'software', 'algoritmo', 'generación', 'generacion', 
        'control', 'herramienta', 'inventario', 'administracion', 'administración', 'ova', 'modelo',
        'red', 'portal', 'análisis', 'analisis', 'diseño', 'diseno', 'reingeniería', 'reingenieria',
        'para', 'del', 'los', 'las', 'con', 'por', 'mediante', 'sobre', 'hacia'
    }
    title_idx = -1
    _found_title = False
    for i, p in enumerate(parts):
        if not _found_title:
            low = p.lower()
            if nc and nc.lower() in low:
                title_idx = i
                _found_title = True
            elif ':' in p or any(tw in low.split() for tw in title_words):
                title_idx = i
                _found_title = True

    if title_idx >= 0:
        authors = parts[:title_idx]
        title = ", ".join(parts[title_idx:])
    else:
        if len(parts) > 1:
            authors = [parts[0]]
            title = ", ".join(parts[1:])
        else:
            authors = []
            if nc:
                title = nc
            else:
                if parts:
                    title = parts[0]
                else:
                    title = text

    return title.strip(" ."), [a.strip() for a in authors if len(a.strip()) > 3]


CVLAC_PRODUCT_ANCHORS = {
    "articulos", "libros", "capitulos", "software", "tecnologicos",
    "patentes", "secretos", "procesos", "trabajos_tec", "normas",
    "otra_prod_tecnica", "otra_prod_biblio", "demas_trabajos", "obras_productos",
    "nota_cientifica", "textos"
}


CVLAC_NON_PRODUCT_KEYWORDS = [
    "formacion", "experiencia", "actuacion", "idioma", "linea",
    "evento", "trabajo", "tutor", "proyecto", "jurado", "comite",
    "asesoria", "redes", "datosgenerales", "otrainfopersonal"
]


def _is_cvlac_product_table(table: ParseNode) -> Tuple[bool, str]:
    # 1. Comprobar si el encabezado de la tabla corresponde expresamente a una sección no de productos
    h3s = _find_nodes(table, "h3")
    if h3s:
        raw_title = h3s[0].all_text()
    else:
        raw_title = ""
    clean = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", raw_title.lower()))
    if any(k in clean for k in CVLAC_NON_PRODUCT_KEYWORDS):
        return False, ""

    # 2. Buscar anchor name dentro de la tabla o en su celda contenedora directa
    anc_name = ""
    for a in _find_nodes(table, "a"):
        if not anc_name and a.attrs.get("name"):
            anc_name = a.attrs.get("name").lower()

    if not anc_name and table.parent:
        for child in table.parent.children:
            if child is not table and not anc_name:
                for a in _find_nodes(child, "a"):
                    if not anc_name and a.attrs.get("name"):
                        anc_name = a.attrs.get("name").lower()

        # Buscar en la fila (tr) inmediatamente anterior si existe
        if not anc_name and table.parent.parent:
            p_tr = table.parent
            while p_tr and p_tr.tag != "tr":
                p_tr = p_tr.parent
            if p_tr and p_tr.parent:
                sibs = p_tr.parent.children
                if p_tr in sibs:
                    idx = sibs.index(p_tr)
                else:
                    idx = -1
                if idx > 0:
                    prev_sib = sibs[idx - 1]
                    for a in _find_nodes(prev_sib, "a"):
                        if not anc_name and a.attrs.get("name"):
                            anc_name = a.attrs.get("name").lower()

    if anc_name in CVLAC_PRODUCT_ANCHORS:
        return True, anc_name

    if not h3s:
        return False, ""

    keywords = [
        "art", "libro", "capitul", "software", "patent", "secreto",
        "proces", "tecnic", "tecnol", "obra", "norma", "nota"
    ]
    if any(k in clean for k in keywords):
        return True, raw_title
    return False, ""


def _map_cvlac_product_category(anc_name: str, raw_title: str) -> str:
    anc = anc_name.lower()
    clean = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", raw_title.lower()))
    if anc == "articulos" or ("art" in clean and "cul" in clean):
        return "Artículos"
    if anc == "libros" or ("libro" in clean and "capit" not in clean):
        return "Libros"
    if anc == "capitulos" or "capit" in clean:
        return "Capítulos de libro"
    if anc == "software" or "software" in clean:
        return "Softwares"
    if anc == "tecnologicos" or "tecnol" in clean:
        return "Productos tecnológicos"
    if anc == "patentes" or "patent" in clean:
        return "Patentes"
    if anc == "secretos" or "secreto" in clean:
        return "Secretos empresariales"
    if anc == "procesos" or "proces" in clean:
        return "Procesos o técnicas"
    if anc == "trabajos_tec" or "trabajostec" in clean:
        return "Trabajos técnicos"
    if anc == "normas" or "norma" in clean:
        return "Normas y Regulaciones"
    return _clean_record(raw_title)


def _extract_investigator_sections_dom(root: ParseNode) -> Dict[str, List[str]]:
    section_map: Dict[str, List[str]] = {}
    all_tables = _find_nodes(root, "table")
    child_tables = []
    for t in all_tables:
        p = t.parent
        has_table_parent = False
        while p and not has_table_parent:
            if p.tag == "table":
                has_table_parent = True
            if not has_table_parent:
                p = p.parent
        if has_table_parent:
            child_tables.append(t)

    if child_tables:
        tables_to_check = child_tables
    else:
        tables_to_check = all_tables
    for t in tables_to_check:
        h3s = _find_nodes(t, "h3")
        if h3s:
            raw_title = h3s[0].all_text()
            clean_key = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", raw_title.lower()))

            is_p, _ = _is_cvlac_product_table(t)
            if not is_p:
                items = []
                for tr in _find_nodes(t, "tr"):
                    if not _find_nodes(tr, "h3"):
                        txt = _clean_record(tr.all_text())
                        norm_tr = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", txt.lower()))
                        if txt and len(txt) > 2 and not norm_tr.startswith("lositems"):
                            items.append(txt)
                if items:
                    section_map[clean_key] = items
    return section_map


def _extract_investigator_product(lines: List[str], category: str, index: int) -> Optional[ProductoInvestigacion]:
    if not lines:
        return None
    first = clean_text(lines[0])
    inline = INV_PRODUCT_INLINE_RE.match(first)
    subtype = clean_text(category)
    title = ""
    autores: List[str] = []

    if inline:
        title = clean_text(inline.group(1))
        subtype = clean_text(inline.group(2))
    else:
        quoted = re.search(r'["“]([^"”\r\n]+)["”]', first)
        if quoted:
            title = clean_text(quoted.group(1))
            q_start = first.find(quoted.group(0))
            raw_auth = first[:q_start].strip().rstrip(",").strip()
            raw_auth = re.sub(r"^(?:Tipo:\s*[^,]+,\s*|\*\s*)", "", raw_auth, flags=re.IGNORECASE)
            if raw_auth:
                autores = [a.strip() for a in raw_auth.split(",") if a.strip() and len(a.strip()) > 3]
        else:
            unq_title, unq_authors = _extract_unquoted_product_title_and_authors(first)
            title = unq_title
            autores = unq_authors

    # Buscar una linea posterior que contenga un titulo entre comillas si no se encontró
    if not title or len(title) < 3 or title in (".", "-", ":"):
        _found_q = False
        for line in lines[1:]:
            if not _found_q:
                quoted = re.search(r'["“]([^"”\r\n]+)["”]', line)
                if quoted:
                    title = clean_text(quoted.group(1))
                    _found_q = True

    all_text = " ".join(clean_text(line) for line in lines if clean_text(line))

    # Buscar nombre comercial si el titulo no fue claro
    if not title or title in (".", "-", ":", "Contacto:"):
        nc = re.search(r"Nombre comercial:\s*([^,]+)", all_text, re.IGNORECASE)
        if nc and nc.group(1).strip():
            title = clean_text(nc.group(1))

    title = title.rstrip(" .")

    product = ProductoInvestigacion(
        idProducto="P{}".format(index),
        titulo=title,
        categoria=clean_text(category),
        tipoProducto=subtype,
        subtipo=subtype,
        descripcion=all_text,
        autores=autores,
    )

    text_no_ids = re.sub(r"(?:ISSN|ISBN)\s*:\s*[\d-]+", "", all_text, flags=re.IGNORECASE)
    ym = re.search(r"(?:p\.\s*[\d\s-]+|\bEn:\s*[^,]+,\s*|,\s*)(19\d{2}|20\d{2})\s*[,.]", text_no_ids, re.IGNORECASE)
    if not ym:
        after_title = text_no_ids
        if title and title in text_no_ids:
            after_title = text_no_ids.split(title, 1)[-1]
        ym = re.search(r"\b(19\d{2}|20\d{2})\b", after_title)
    if not ym:
        ym = re.search(r"\b(19\d{2}|20\d{2})\b", text_no_ids)

    if ym:
        if ym.lastindex:
            val_year = ym.group(1)
        else:
            val_year = ym.group(0)
        product.anio = safe_int(val_year)

    isbn_match = re.search(r"ISBN:\s*([^,]+)", all_text, re.IGNORECASE)
    if isbn_match:
        product.isbn = clean_text(isbn_match.group(1))

    doi_match = re.search(r"DOI:\s*([^,\s]+(?:\S*://\S+|\S+)?)", all_text, re.IGNORECASE)
    if doi_match:
        product.doi = clean_text(doi_match.group(1))

    for line in lines:
        clean_line = clean_text(line)
        if "ISSN:" in clean_line.upper():
            before_issn = clean_text(re.split(r"ISSN:", clean_line, maxsplit=1, flags=re.IGNORECASE)[0])
            if "," in before_issn:
                first_part, second_part = before_issn.split(",", 1)
                if re.match(r"^[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñü .'-]+$", first_part.strip()):
                    product.revista = clean_text(second_part)
                else:
                    product.revista = before_issn
            else:
                product.revista = before_issn
        editorial_match = re.search(r"\bed:\s*([^,]+)", clean_line, re.IGNORECASE)
        if editorial_match:
            product.editorial = clean_text(editorial_match.group(1))

    _found_country = False
    for line in lines:
        if not _found_country:
            clean_line = clean_text(line)
            country_match = re.search(r"\bEn:\s*([^,]+)", clean_line, re.IGNORECASE)
            if country_match:
                product.pais = clean_text(country_match.group(1))
                _found_country = True
    if not product.pais:
        _found_country2 = False
        for line in lines[1:]:
            if not _found_country2:
                country_match = re.match(r"^([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñü .'-]+),", clean_text(line))
                if country_match:
                    product.pais = clean_text(country_match.group(1))
                    _found_country2 = True

    words_match = re.search(r"Palabras:\s*(.+?)(?=\s+Areas:|\s+Sectores:|$)", all_text, re.IGNORECASE)
    if words_match:
        product.palabrasClave = clean_text(words_match.group(1))

    areas_match = re.search(r"Areas:\s*(.+?)(?=\s+Sectores:|$)", all_text, re.IGNORECASE)
    if areas_match:
        product.areas = clean_text(areas_match.group(1))

    contract_match = re.search(r"contrato/registro:\s*([^,]+)", all_text, re.IGNORECASE)
    if contract_match:
        product.numeroContrato = clean_text(contract_match.group(1))

    # Fallback para autores si no se habían extraído
    if not product.autores:
        _found_auth = False
        for line in lines:
            if not _found_auth:
                explicit_authors = re.match(r"^Autores?:\s*(.+)$", clean_text(line), re.IGNORECASE)
                if explicit_authors:
                    product.autores = unique_strings(re.split(r"\s*,\s*", explicit_authors.group(1)))
                    _found_auth = True

    product.normalizar()
    if not product.titulo:
        return None
    return product


def _find_investigator_products(values: List[str], root: Optional[ParseNode] = None) -> List[ProductoInvestigacion]:
    products: List[ProductoInvestigacion] = []
    seen = set()
    counter = 1

    # 1. Extracción estructurada desde el árbol DOM si está disponible
    if root is not None:
        all_tables = _find_nodes(root, "table")
        child_tables = []
        for t in all_tables:
            p = t.parent
            has_table_parent = False
            while p and not has_table_parent:
                if p.tag == "table":
                    has_table_parent = True
                if not has_table_parent:
                    p = p.parent
            if has_table_parent:
                child_tables.append(t)

        if child_tables:
            tables_to_check = child_tables
        else:
            tables_to_check = all_tables
        for table in tables_to_check:
            is_p, label = _is_cvlac_product_table(table)
            if is_p:
                h3_nodes = _find_nodes(table, "h3")
                if h3_nodes:
                    raw_section_title = h3_nodes[0].all_text()
                else:
                    raw_section_title = label
                section_title = _map_cvlac_product_category(label, raw_section_title)

                bqs = _find_nodes(table, "blockquote")
                for bq in bqs:
                    text = _clean_record(bq.all_text())
                    if text and len(text) >= 4:
                        subtype = section_title
                        validado = False

                        # 1. Comprobar si hay imagen de verificación (chulo.jpg) dentro de bq
                        if any("chulo" in img.attrs.get("src", "").lower() for img in _find_nodes(bq, "img")):
                            validado = True

                        # 2. Comprobar en nodo ancestro directo en la misma fila (p.ej. li)
                        if not validado:
                            p_node = bq.parent
                            while p_node and p_node.tag not in ("tr", "table") and not validado:
                                if any("chulo" in img.attrs.get("src", "").lower() for img in _find_nodes(p_node, "img")):
                                    validado = True
                                if not validado:
                                    p_node = p_node.parent

                # 3. Subtipo y verificación en fila previa si no tiene su propio blockquote
                p_td = bq.parent
                while p_td and p_td.tag not in ("td", "tr", "table"):
                    p_td = p_td.parent
                if p_td and p_td.parent and p_td.parent.tag == "tr":
                    row = p_td.parent
                    table_rows = [c for c in row.parent.children if c.tag == "tr"]
                    if row in table_rows:
                        idx = table_rows.index(row)
                        if idx > 0:
                            prev_row = table_rows[idx - 1]
                            if not _find_nodes(prev_row, "blockquote"):
                                if any("chulo" in img.attrs.get("src", "").lower() for img in _find_nodes(prev_row, "img")):
                                    validado = True
                                prev_text = _clean_record(prev_row.all_text())
                                if any(k in prev_text.lower() for k in ["producción", "produccion", "tipo:"]):
                                    m_sub = re.search(r"((?:Producci[oó]n|Tipo:)[^\r\n<]+)", prev_text, re.IGNORECASE)
                                    if m_sub:
                                        subtype = m_sub.group(1).strip()
                                    else:
                                        subtype = prev_text[:80]

                # Titulo y autores
                title = ""
                autores: List[str] = []
                m_q = re.search(r'["“]([^"”\r\n]+)["”]', text)
                if m_q:
                    title = m_q.group(1).strip()
                    q_start = text.find(m_q.group(0))
                    raw_auth = text[:q_start].strip().rstrip(",").strip()
                    raw_auth = re.sub(r"^(?:Tipo:\s*[^,]+,\s*|\*\s*)", "", raw_auth, flags=re.IGNORECASE)
                    if raw_auth:
                        autores = [a.strip() for a in raw_auth.split(",") if a.strip() and len(a.strip()) > 3]
                else:
                    unq_title, unq_authors = _extract_unquoted_product_title_and_authors(text)
                    title = unq_title
                    autores = unq_authors

                title = title.rstrip(" .")
                anio = 0
                ym = re.search(r"\b(19\d{2}|20\d{2})\b", text)
                if ym:
                    anio = int(ym.group(1))

                prod = ProductoInvestigacion(
                    idProducto=f"P{counter}",
                    titulo=title,
                    categoria=section_title,
                    validado=validado,
                    anio=anio,
                    tipoProducto=subtype,
                    subtipo=subtype,
                    descripcion=text,
                    autores=autores,
                )

                m_doi = re.search(r"DOI:\s*([^,\s]+)", text, re.IGNORECASE)
                if m_doi:
                    prod.doi = m_doi.group(1).strip()
                m_isbn = re.search(r"ISBN:\s*([^,\s]+)", text, re.IGNORECASE)
                if m_isbn:
                    prod.isbn = m_isbn.group(1).strip()
                m_issn = re.search(r"ISSN:\s*([^,\s]+)", text, re.IGNORECASE)
                if m_issn:
                    prod.revista = m_issn.group(1).strip()

                key = (clean_text(prod.titulo).casefold(), int(prod.anio or 0))
                if key not in seen and len(prod.titulo) >= 2:
                    seen.add(key)
                    products.append(prod)
                    counter += 1

    # 2. Extraccion secuencial sobre bloques de texto (funciona como fallback)
    if not products:
        pending: List[str] = []
        category = ""
        active_production = False

        def flush() -> None:
            nonlocal pending, counter

            if pending:
                product = _extract_investigator_product(
                    pending,
                    category,
                    counter
                )
                if product is not None:
                    key = (clean_text(product.titulo).casefold(), int(product.anio or 0))
                    if key not in seen and len(product.titulo) >= 2:
                        products.append(product)
                        seen.add(key)
                        counter += 1

            pending = []

        for value in values:
            clean_value = clean_text(value)
            lowered = clean_value.casefold()

            marker = INV_PRODUCTION_START_RE.match(clean_value)
            inline_marker = INV_PRODUCT_INLINE_RE.match(clean_value)

            if marker:
                flush()
                active_production = True
                category = clean_text(marker.group(2))
            elif lowered in {
                "artículos", "capitulos de libro", "capítulos de libro",
                "libros", "nota científica", "textos en publicaciones no científicas",
                "otra producción bibliográfica", "patentes", "software", "softwares",
                "procesos o técnicas", "trabajos técnicos", "normas y regulaciones",
                "consultorías", "cursos de corta duración", "secretos empresariales",
                "documentos de trabajo", "demás trabajos", "empresas de base tecnológica"
            }:
                flush()
                category = clean_value
                active_production = True
            elif inline_marker:
                flush()
                pending = [clean_value]
                active_production = True
            elif active_production and _looks_like_inv_product_text(clean_value):
                flush()
                pending = [clean_value]
            else:
                if pending:
                    pending.append(clean_value)
                if any(sec in lowered for sec in ALL_CVLAC_SECTIONS):
                    flush()
                    active_production = False

        flush()

    return products


# -------------------------------------------------------------------------
# Integrantes GrupLAC
# -------------------------------------------------------------------------

def _extract_group_members(root: ParseNode) -> List[Dict[str, Any]]:
    selected_rows: List[List[str]] = []
    _found_tbl = False
    for table in _extract_tables(root):
        if not _found_tbl:
            header_index = -1
            _found_hdr = False
            for index, row in enumerate(table):
                if not _found_hdr:
                    normalized = [_norm_key(cell) for cell in row]
                    if "nombre" in normalized and ("vinculación" in normalized or "vinculacion" in normalized):
                        header_index = index
                        _found_hdr = True
            if header_index >= 0:
                selected_rows = table[header_index + 1:]
                _found_tbl = True

    members: List[Dict[str, Any]] = []
    for row in selected_rows:
        if row:
            name = _clean_numbered(row[0])
            if name:
                lowered = _norm_key(name)
                if lowered not in {"nombre", "nombre completo"}:
                    if len(row) >= 2:
                        vinc = clean_text(row[1])
                    else:
                        vinc = ""
                    if len(row) >= 3:
                        hd = clean_text(row[2])
                    else:
                        hd = ""
                    if len(row) >= 4:
                        ifv = clean_text(row[3])
                    else:
                        ifv = ""
                    member: Dict[str, Any] = {
                        "codigoRh": "",
                        "nombre": name,
                        "correo": "",
                        "orcid": "",
                        "institucion": "",
                        "departamento": "",
                        "ciudad": "",
                        "categoriaInvestigador": "",
                        "perfil": "",
                        "nombreCitaciones": "",
                        "nacionalidad": "",
                        "sexo": "",
                        "estadoParEvaluador": "",
                        "researcherId": "",
                        "autorIdScopus": "",
                        "googleScholar": "",
                        "researchGate": "",
                        "academiaEdu": "",
                        "mendeley": "",
                        "linkedin": "",
                        "repositorioInstitucional": "",
                        "idiomas": [],
                        "areasConocimiento": [],
                        "lineasInvestigacion": [],
                        "formacionAcademica": [],
                        "experienciaProfesional": [],
                        "gruposInvestigacion": [],
                        "semilleros": [],
                        "proyectos": [],
                        "reconocimientos": [],
                        "productos": [],
                        "activo": True,
                        "vinculacion": vinc,
                        "horasDedicacion": hd,
                        "inicioFinVinculacion": ifv,
                    }
                    members.append(member)

    output: List[Dict[str, Any]] = []
    seen = set()
    for member in members:
        key = member["nombre"].casefold()
        if key and key not in seen:
            output.append(member)
            seen.add(key)
    return output


# -------------------------------------------------------------------------
# Errores y scraper publico
# -------------------------------------------------------------------------

class ScraperError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class WebScraper:
    def __init__(self, timeout: int = DEFAULT_TIMEOUT) -> None:
        self.timeout = timeout
        self.last_error: Optional[ScraperError] = None

    def _fetch(self, url: str) -> str:
        self.last_error = None
        if not is_valid_url(url):
            raise ScraperError("URL_INVALIDA", "La URL no es válida.")

        request = Request(
            url,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "es-CO,es;q=0.9,en;q=0.7",
            },
        )

        raw = b""
        response = None
        encoding = "utf-8"
        try:
            # Minciencias puede presentar el certificado de la cadena SSL
            # como no verificable desde algunas instalaciones de Windows.
            context = ssl._create_unverified_context()
            response = urlopen(request, timeout=self.timeout, context=context)
            status = getattr(response, "status", 200)
            if status >= 400:
                raise ScraperError("HTTP", "La página respondió con un error HTTP {}.".format(status))
            raw = response.read()
            try:
                header_value = response.headers.get_content_charset()
                if header_value:
                    encoding = header_value
            except Exception:
                encoding = "utf-8"
        except HTTPError as exc:
            raise ScraperError("HTTP", "La página respondió con HTTP {}.".format(exc.code))
        except URLError as exc:
            raise ScraperError("CONEXION", "No fue posible conectar con la página: {}".format(exc.reason))
        except TimeoutError:
            raise ScraperError("TIMEOUT", "La conexión superó el tiempo de espera.")
        except OSError as exc:
            raise ScraperError("CONEXION", "No fue posible leer la página: {}".format(exc))
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

        detected_enc = None
        match = re.search(rb'charset=["\']?([\w\-]+)', raw[:4096], re.IGNORECASE)
        if match:
            try:
                candidate = match.group(1).decode("ascii", errors="ignore").lower()
                codecs.lookup(candidate)
                detected_enc = candidate
            except Exception:
                pass

        final_enc = detected_enc or encoding or "utf-8"
        try:
            html = raw.decode(final_enc, errors="replace")
        except (LookupError, UnicodeDecodeError):
            html = raw.decode("utf-8", errors="replace")

        if not html.strip():
            raise ScraperError("PAGINA_VACIA", "La página no contiene contenido HTML utilizable.")
        return html

    def _parse(self, html: str) -> DOMParser:
        parser = DOMParser()
        try:
            parser.feed(html)
            parser.close()
        except Exception as exc:
            raise ScraperError("HTML_INVALIDO", "No fue posible interpretar la estructura HTML: {}".format(exc))
        return parser

    def buscar_grupo(self, url: str) -> Dict[str, Any]:
        valido, norm_url, error_msg = validar_url_minciencias("grupo", url)
        if not valido:
            raise ScraperError("URL_INVALIDA", error_msg)
        url = norm_url
        try:
            html = self._fetch(url)
            parser = self._parse(html)
            values = _record_values(parser.root)
            full_text = parser.root.all_text()
            pairs = _label_value_pairs(parser.root)

            group = GrupoInvestigacion()
            for field_name in group.__dict__.keys():
                if field_name in pairs:
                    setattr(group, field_name, pairs[field_name])

            # El numero del grupo viene de la URL; es la fuente mas estable.
            nro = _query_parameter(url, "nro")
            if nro:
                group.nroGrupo = nro
            elif "nroGrupo" in pairs and not group.nroGrupo:
                group.nroGrupo = pairs["nroGrupo"]

            # El nombre aparece inmediatamente antes de 'Datos básicos' en
            # la pagina real de GrupLAC, pero puede estar en una etiqueta HTML
            # distinta. Se usa un extractor especifico para ese encabezado.
            group.nombreGrupo = _extract_group_name(values, full_text, parser.root)

            # Respaldo para variantes donde existe literalmente 'Nombre del grupo'.
            if not group.nombreGrupo:
                if "nombreGrupo" in pairs:
                    group.nombreGrupo = pairs["nombreGrupo"]
                else:
                    _found_n = False
                    for index, value in enumerate(values):
                        if not _found_n:
                            if _norm_key(value) in {"nombre del grupo", "nombre grupo"} and index + 1 < len(values):
                                group.nombreGrupo = clean_text(values[index + 1])
                                _found_n = True

            # Ubicacion exacta del registro 'Departamento - Ciudad'.
            location = pairs.get("departamento", "")
            if location:
                parts = re.split(r"\s+-\s+", location, maxsplit=1)
                if len(parts) == 2:
                    group.departamento = clean_text(parts[0])
                    group.ciudad = clean_text(parts[1])
                else:
                    group.departamento = clean_text(location)

            # Las instituciones se toman solamente de su seccion.
            group.instituciones = _section_items(
                values,
                ["instituciones"],
                ["líneas de investigación declaradas por el grupo", "lineas de investigacion declaradas por el grupo", "integrantes del grupo"],
            )

            # MUY IMPORTANTE: solo se recogen las 9 lineas ubicadas entre el
            # titulo de la seccion y 'Integrantes del grupo'.
            group.lineasInvestigacion = _section_items(
                values,
                ["líneas de investigación declaradas por el grupo", "lineas de investigacion declaradas por el grupo"],
                ["integrantes del grupo"],
                numbered_only=True,
            )

            group.integrantes = _extract_group_members(parser.root)
            group_products = _find_group_products(
                values,
                group.nroGrupo
            )

            group.productos = [
                product.to_dict()
                for product in group_products
            ]

            if group.clasificacion:
                group.clasificacion = _normalize_group_classification(group.clasificacion)

            group.normalizar()
            if not group.nroGrupo and not group.nombreGrupo:
                raise ScraperError(
                    "ESTRUCTURA",
                    "La página no contiene la estructura esperada para un grupo GrupLAC.",
                )

            result = group.to_dict()
            result["tipo"] = "grupo"
            result["fuente"] = url
            return result

        except ScraperError as exc:
            self.last_error = exc
            raise
        except Exception as exc:
            error = ScraperError(
                "PROCESAMIENTO",
                "Ocurrió un error controlado al procesar el grupo: {}".format(exc),
            )
            self.last_error = error
            raise error

    def buscar_investigador(self, url: str) -> Dict[str, Any]:
        valido, norm_url, error_msg = validar_url_minciencias("investigador", url)
        if not valido:
            raise ScraperError("URL_INVALIDA", error_msg)
        url = norm_url
        try:
            html = self._fetch(url)
            parser = self._parse(html)
            values = _record_values(parser.root)
            full_text = parser.root.all_text()

            investigator = Investigador()

            identity = _extract_investigator_identity(values, full_text, parser.root)
            for field_name, value in identity.items():
                if hasattr(investigator, field_name) and value:
                    setattr(investigator, field_name, value)

            # El codigo RH se obtiene directamente del parametro cod_rh.
            rh = _query_parameter(url, "cod_rh")
            if rh:
                investigator.codigoRh = rh

            links = _extract_investigator_links(parser.root)
            for field_name, value in links.items():
                if value and hasattr(investigator, field_name):
                    setattr(investigator, field_name, value)

            dom_sections = _extract_investigator_sections_dom(parser.root)

            def get_dom_sec(keywords: List[str]) -> List[str]:
                for kw in keywords:
                    norm_kw = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", kw.lower()))
                    for k, v in dom_sections.items():
                        if norm_kw in k:
                            return v
                return []

            investigator.formacionAcademica = get_dom_sec(["formación académica", "formacion academica", "formacion"]) or _section_items(
                values,
                ["formación académica", "formacion academica"],
                ["formación complementaria", "formacion complementaria", "experiencia profesional"],
            )
            investigator.experienciaProfesional = get_dom_sec(["experiencia profesional", "experiencia"]) or _section_items(
                values,
                ["experiencia profesional"],
                ["áreas de actuación", "areas de actuación", "otra información personal", "idiomas"],
            )
            investigator.areasConocimiento = get_dom_sec(["áreas de actuación", "areas de actuación", "áreas de conocimiento", "areas de conocimiento"]) or _section_items(
                values,
                ["áreas de actuación", "areas de actuación"],
                ["idiomas", "líneas de investigación", "lineas de investigacion"],
            )
            investigator.idiomas = _extract_languages(values, parser.root)
            investigator.lineasInvestigacion = get_dom_sec(["líneas de investigación", "lineas de investigación", "lineas"]) or _section_items(
                values,
                ["líneas de investigación", "lineas de investigación"],
                ["reconocimientos", "trabajos dirigidos", "asesorías", "artículos", "cursos de corta duración"],
            )
            investigator.reconocimientos = get_dom_sec(["reconocimientos"]) or _section_items(
                values,
                ["reconocimientos"],
                ["cursos de corta duración", "artículos", "capitulos de libro", "capítulos de libro"],
            )
            investigator.gruposInvestigacion = get_dom_sec(["grupos de investigación", "grupos de investigacion", "grupos"]) or _section_items(
                values,
                ["grupos de investigación", "grupos de investigacion"],
                ["semilleros", "proyectos", "reconocimientos"],
            )
            investigator.semilleros = get_dom_sec(["semilleros de investigación", "semilleros de investigacion", "semilleros"]) or _section_items(
                values,
                ["semilleros de investigación", "semilleros de investigacion", "semilleros"],
                ["proyectos", "reconocimientos", "artículos", "capitulos de libro", "capítulos de libro"],
            )
            investigator.proyectos = get_dom_sec(["proyectos de investigación", "proyectos de investigacion", "proyectos"]) or _section_items(
                values,
                ["proyectos de investigación", "proyectos de investigacion", "proyectos"],
                ["artículos", "capitulos de libro", "capítulos de libro", "reconocimientos"],
            )

            # En este CvLAC la afiliacion/campus esta dentro de experiencia
            # profesional, priorizando la institución actualmente activa.
            institution, city = _extract_investigator_affiliation(values, full_text, investigator.experienciaProfesional)
            if not investigator.institucion and institution:
                investigator.institucion = institution
            if not investigator.ciudad and city:
                investigator.ciudad = city

            products = _find_investigator_products(values, parser.root)
            investigator.productos = [product.to_dict() for product in products]

            investigator.normalizar()
            if not investigator.nombre and not investigator.codigoRh:
                raise ScraperError(
                    "ESTRUCTURA",
                    "La página no contiene la estructura esperada para un investigador CvLAC.",
                )

            result = investigator.to_dict()
            result["tipo"] = "investigador"
            result["fuente"] = url
            return result

        except ScraperError as exc:
            self.last_error = exc
            raise
        except Exception as exc:
            error = ScraperError(
                "PROCESAMIENTO",
                "Ocurrió un error controlado al procesar el investigador: {}".format(exc),
            )
            self.last_error = error
            raise error

    def buscar(self, tipo_busqueda: str, url: str) -> Dict[str, Any]:
        normalized = clean_text(tipo_busqueda).casefold()
        valido, norm_url, error_msg = validar_url_minciencias(normalized, url)
        if not valido:
            raise ScraperError("URL_INVALIDA", error_msg)

        if normalized == "grupo":
            return self.buscar_grupo(norm_url)
        if normalized == "investigador":
            return self.buscar_investigador(norm_url)
        raise ScraperError(
            "TIPO_INVALIDO",
            "El tipo de búsqueda debe ser 'grupo' o 'investigador'.",
        )


# =========================================================================
# CAPA DE SERVICIOS Y LOGICA DE APLICACION
# =========================================================================

class ApplicationService:
    def __init__(self) -> None:
        self.scraper = WebScraper()
        self.persistence = PersistenceManager()
        stored = self.persistence.load_all()
        self.investigadores: List[Dict[str, Any]] = stored.get("investigadores", [])
        self.grupos: List[Dict[str, Any]] = stored.get("grupos", [])
        self.events: List[Dict[str, str]] = []
        self.last_saved: str = ""

    def _event(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M")
        self.events.insert(0, {"hora": timestamp, "mensaje": message})
        self.events = self.events[:8]

    def save_all(self) -> bool:
        ok = self.persistence.save_all(self.investigadores, self.grupos)
        if ok:
            self.last_saved = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self._event("Datos guardados correctamente")
        else:
            self._event("Error al guardar los datos")
        return ok

    def add_scraped_result(self, result: Dict[str, Any]) -> Tuple[bool, str]:
        tipo = str(result.get("tipo", "")).casefold()
        if tipo == "investigador":
            key = canonical_key(result.get("codigoRh", ""))
            duplicate = False
            for current in self.investigadores:
                if canonical_key(current.get("codigoRh", "")) == key and key:
                    duplicate = True
            if duplicate:
                return False, "El investigador ya se encuentra cargado."
            self.investigadores.append(result)
            self._event("Investigador cargado desde CvLAC")
            return True, "Investigador cargado correctamente."
        elif tipo == "grupo":
            key = canonical_key(result.get("nroGrupo", ""))
            duplicate = False
            for current in self.grupos:
                if canonical_key(current.get("nroGrupo", "")) == key and key:
                    duplicate = True
            if duplicate:
                return False, "El grupo ya se encuentra cargado."
            self.grupos.append(result)
            self._event("Grupo cargado desde GrupLAC")
            return True, "Grupo cargado correctamente."
        else:
            return False, "El resultado del scraper no tiene un tipo válido."

    def scrape_and_add(self, tipo: str, url: str) -> Tuple[bool, Dict[str, Any], str]:
        valido, norm_url, error_msg = validar_url_minciencias(tipo, url)
        if not valido:
            self._event("Error de validación de URL")
            return False, {}, error_msg

        try:
            result = self.scraper.buscar(tipo, norm_url)
            added, message = self.add_scraped_result(result)
            return added, result, message
        except ScraperError as exc:
            self._event("Error de scraping: {}".format(exc.code))
            return False, {}, exc.message
        except Exception as exc:
            self._event("Error inesperado de scraping")
            return False, {}, "Error controlado de procesamiento: {}".format(exc)

    def toggle_investigator(self, codigo: str) -> bool:
        changed = False
        for investigator in self.investigadores:
            if canonical_key(investigator.get("codigoRh", "")) == canonical_key(codigo):
                investigator["activo"] = not bool(investigator.get("activo", True))
                changed = True
        if changed:
            self._event("Estado de investigador actualizado")
        return changed

    def search_investigators(self, text: str) -> List[Dict[str, Any]]:
        query = canonical_key(text)
        result: List[Dict[str, Any]] = []
        for item in self.investigadores:
            haystack = " ".join([
                str(item.get("codigoRh", "")), str(item.get("nombre", "")),
                str(item.get("institucion", "")), str(item.get("categoriaInvestigador", ""))
            ])
            if not query or query in canonical_key(haystack):
                result.append(item)
        return result

    def search_groups(self, text: str) -> List[Dict[str, Any]]:
        query = canonical_key(text)
        result: List[Dict[str, Any]] = []
        for item in self.grupos:
            haystack = " ".join([
                str(item.get("nroGrupo", "")), str(item.get("nombreGrupo", "")),
                str(item.get("ciudad", "")), str(item.get("lider", "")),
                str(item.get("clasificacion", ""))
            ])
            if not query or query in canonical_key(haystack):
                result.append(item)
        return result

    def statistics(self) -> Dict[str, Any]:
        investigator_count = len(self.investigadores)
        active_count = sum(1 for item in self.investigadores if bool(item.get("activo", True)))
        group_count = len(self.grupos)
        products: List[Dict[str, Any]] = []
        categories: Dict[str, int] = {}
        years: Dict[str, int] = {}
        for investigator in self.investigadores:
            for product in investigator.get("productos", []):
                products.append(product)
        for group in self.grupos:
            for product in group.get("productos", []):
                products.append(product)
        unique_products: List[Dict[str, Any]] = []
        seen = set()
        for product in products:
            titulo = str(product.get("titulo", ""))
            anio = str(product.get("anio", 0))
            key = (canonical_key(titulo), anio)
            if titulo and key not in seen:
                unique_products.append(product)
                seen.add(key)
        for product in unique_products:
            category = str(product.get("categoria", "") or product.get("tipoProducto", "") or "Sin categoría").strip()
            year = str(product.get("anio", "") or "Sin año").strip()
            categories[category] = categories.get(category, 0) + 1
            years[year] = years.get(year, 0) + 1
        return {
            "investigadores": investigator_count,
            "investigadores_activos": active_count,
            "grupos": group_count,
            "productos": len(unique_products),
            "categorias": categories,
            "anios": years,
        }

    def dashboard(self) -> Dict[str, Any]:
        stats = self.statistics()
        return {
            "stats": stats,
            "events": list(self.events),
            "last_saved": self.last_saved,
        }


# =========================================================================
# SERVIDOR API LOCAL (PUENTE HTTP 127.0.0.1:8765)
# =========================================================================

HOST = "127.0.0.1"
PORT = 8765


class PEARequestHandler(BaseHTTPRequestHandler):
    service: ApplicationService = None  # type: ignore

    def _send(self, status: int, body: str, content_type: str) -> None:
        payload = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:
        if self.path.split("?", 1)[0] == "/health":
            self._send(200, json.dumps({"status": "ok", "service": "PEA-Scraper"}, ensure_ascii=False), "application/json")
        else:
            self._send(404, json.dumps({"status": "error", "message": "Ruta no encontrada."}, ensure_ascii=False), "application/json")

    def do_POST(self) -> None:
        route = self.path.split("?", 1)[0]
        if route == "/scraping":
            self._handle_scraping()
        else:
            self._send(404, serialize_error("Ruta no encontrada."), "text/plain")

    def _handle_scraping(self) -> None:
        content_length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(content_length)
        request = None
        request_error = ""
        try:
            request = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            request_error = "El cuerpo de la solicitud no contiene JSON válido."
        if request_error:
            self._send(200, serialize_error(request_error), "text/plain")
        elif not isinstance(request, dict):
            self._send(200, serialize_error("La solicitud JSON debe ser un objeto."), "text/plain")
        else:
            tipo = request.get("tipoBusqueda", "")
            url = request.get("url", "")
            valid = isinstance(tipo, str) and isinstance(url, str) and bool(tipo.strip()) and bool(url.strip())
            if not valid:
                self._send(200, serialize_error("La solicitud debe incluir tipoBusqueda y url."), "text/plain")
            else:
                ok, result, message = self.service.scrape_and_add(tipo, url)
                if ok:
                    payload = serialize_result(result)
                else:
                    payload = serialize_error(message)
                self._send(200, payload, "text/plain")

    def log_message(self, format: str, *args: Any) -> None:
        pass


class LocalAPIServer:
    def __init__(self, service: ApplicationService, host: str = HOST, port: int = PORT) -> None:
        self.service = service
        self.server = ThreadingHTTPServer((host, port), PEARequestHandler)
        self.server.RequestHandlerClass.service = service

    def serve_forever(self) -> None:
        self.server.serve_forever()

    def shutdown(self) -> None:
        self.server.shutdown()
        self.server.server_close()


# =========================================================================
# INTERFAZ GRAFICA DE USUARIO (TKINTER / MODO CUBO)
# =========================================================================

BG = "#f4f6f8"
PANEL = "#ffffff"
DARK = "#17202a"
MUTED = "#697586"
ACCENT = "#2457a6"
PRIMARY = "#2457a6"
GREEN = "#2f855a"
RED = "#c53030"
BORDER = "#d9dee7"


class CubeView(tk.Frame):
    def __init__(self, master: tk.Misc, on_select, on_exit) -> None:
        super().__init__(master, bg=BG)
        self.on_select = on_select
        self.on_exit = on_exit
        self.faces = [
            ("Inicio", "Dashboard principal"),
            ("Investigadores", "Gestión de investigadores"),
            ("Grupos", "Grupos de investigación"),
            ("Carga de Datos", "CvLAC y GrupLAC"),
            ("Estadísticas", "Indicadores y gráficos"),
            ("Reportes / Análisis", "Consultas y reportes")
        ]
        self.rotation_x = -0.28
        self.rotation_y = 0.55
        self.scale = 1.0
        self.drag_start: Optional[Tuple[int, int]] = None
        self.click_pos: Optional[Tuple[int, int]] = None
        self.drag_distance: float = 0.0
        self.hovered_face: Optional[int] = None
        self.rendered_faces: List[Tuple[float, int, List[Tuple[float, float]], Tuple[float, float, float, float]]] = []

        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=20, pady=(10, 55))

        self.controls_bar = tk.Frame(self, bg=BG)
        self.controls_bar.place(relx=0.5, rely=0.95, anchor="center")

        self.btn_open_front = ttk.Button(
            self.controls_bar,
            text="Abrir módulo frontal",
            command=self._open_front_face
        )
        self.btn_open_front.pack(side="left", padx=8)

        self.btn_exit = ttk.Button(
            self.controls_bar,
            text="Volver a la interfaz normal",
            command=self._handle_exit
        )
        self.btn_exit.pack(side="left", padx=8)

        self.canvas.bind("<Configure>", lambda event: self.draw())
        self.canvas.bind("<ButtonPress-1>", self.begin_drag)
        self.canvas.bind("<B1-Motion>", self.drag)
        self.canvas.bind("<ButtonRelease-1>", self.end_drag)
        self.canvas.bind("<Motion>", self.on_motion)
        self.canvas.bind("<Leave>", self.on_leave)
        self.canvas.bind("<MouseWheel>", self.wheel)
        self.canvas.bind("<Button-4>", lambda event: self.zoom(1))
        self.canvas.bind("<Button-5>", lambda event: self.zoom(-1))
        self.canvas.bind("<Left>", lambda event: self.rotate(-0.16, 0))
        self.canvas.bind("<Right>", lambda event: self.rotate(0.16, 0))
        self.canvas.bind("<Up>", lambda event: self.rotate(0, 0.16))
        self.canvas.bind("<Down>", lambda event: self.rotate(0, -0.16))
        self.canvas.focus_set()
        self.after(60, self.draw)

    def _handle_exit(self) -> None:
        if callable(self.on_exit):
            self.on_exit()

    def _handle_select(self, face_idx: int) -> None:
        if 0 <= face_idx < len(self.faces) and callable(self.on_select):
            self.on_select(self.faces[face_idx][0])

    def _open_front_face(self) -> None:
        nearest = self._nearest_face()
        if nearest is not None:
            self._handle_select(nearest[0])

    def begin_drag(self, event) -> None:
        self.drag_start = (event.x, event.y)
        self.click_pos = (event.x, event.y)
        self.drag_distance = 0.0

    def drag(self, event) -> None:
        if self.drag_start is not None:
            dx = event.x - self.drag_start[0]
            dy = event.y - self.drag_start[1]
            self.drag_distance += abs(dx) + abs(dy)
            self.rotate(dx * 0.01, -dy * 0.01)
            self.drag_start = (event.x, event.y)

    def end_drag(self, event) -> None:
        # If total mouse movement was minimal, consider this a face click
        handled = False
        if self.click_pos is not None and self.drag_distance < 10:
            face_idx = self._face_at_point(event.x, event.y)
            if face_idx is not None:
                self._handle_select(face_idx)
                handled = True
        if not handled:
            self.drag_start = None
            self.click_pos = None

    def on_motion(self, event) -> None:
        if self.drag_start is None:
            face_idx = self._face_at_point(event.x, event.y)
            if face_idx != self.hovered_face:
                self.hovered_face = face_idx
                if face_idx is not None:
                    self.canvas.config(cursor="hand2")
                else:
                    self.canvas.config(cursor="")
                self.draw()

    def on_leave(self, event) -> None:
        if self.hovered_face is not None:
            self.hovered_face = None
            self.canvas.config(cursor="")
            self.draw()

    def wheel(self, event) -> None:
        if event.delta > 0:
            direction = 1
        else:
            direction = -1
        self.zoom(direction)

    def zoom(self, direction: int) -> None:
        self.scale += 0.08 * direction
        if self.scale < 0.7:
            self.scale = 0.7
        if self.scale > 1.35:
            self.scale = 1.35
        self.draw()

    def rotate(self, dyaw: float, dpitch: float) -> None:
        self.rotation_y += dyaw
        self.rotation_x += dpitch
        self.draw()

    @staticmethod
    def _point_in_polygon(x: float, y: float, poly: List[Tuple[float, float]]) -> bool:
        n = len(poly)
        inside = False
        p1x, p1y = poly[0]
        for i in range(1, n + 1):
            p2x, p2y = poly[i % n]
            if y > min(p1y, p2y):
                if y <= max(p1y, p2y):
                    if x <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                        if p1x == p2x or x <= xinters:
                            inside = not inside
            p1x, p1y = p2x, p2y
        return inside

    def _face_at_point(self, x: float, y: float) -> Optional[int]:
        # Iterate in reverse Painter's order (closest faces tested first)
        for avg_z, index, polygon, _ in reversed(self.rendered_faces):
            if avg_z > -0.05 and self._point_in_polygon(x, y, polygon):
                return index
        return None

    def _nearest_face(self):
        face_defs = [
            (0, [(0.5, -0.5, 0.5), (0.5, 0.5, 0.5), (-0.5, 0.5, 0.5), (-0.5, -0.5, 0.5)]),
            (1, [(0.5, -0.5, -0.5), (-0.5, -0.5, -0.5), (-0.5, 0.5, -0.5), (0.5, 0.5, -0.5)]),
            (2, [(-0.5, -0.5, -0.5), (-0.5, -0.5, 0.5), (-0.5, 0.5, 0.5), (-0.5, 0.5, -0.5)]),
            (3, [(0.5, -0.5, 0.5), (0.5, -0.5, -0.5), (0.5, 0.5, -0.5), (0.5, 0.5, 0.5)]),
            (4, [(-0.5, -0.5, 0.5), (0.5, -0.5, 0.5), (0.5, -0.5, -0.5), (-0.5, -0.5, -0.5)]),
            (5, [(-0.5, 0.5, -0.5), (-0.5, 0.5, 0.5), (0.5, 0.5, 0.5), (0.5, 0.5, -0.5)])
        ]
        best = None
        for index, vertices in face_defs:
            rotated = [self._rotate_point(v) for v in vertices]
            z = sum(point[2] for point in rotated) / 4.0
            if best is None or z > best[1]:
                best = (index, z)
        return best

    def _rotate_point(self, point: Tuple[float, float, float]) -> Tuple[float, float, float]:
        x, y, z = point
        cy = math.cos(self.rotation_y)
        sy = math.sin(self.rotation_y)
        x1 = x * cy + z * sy
        z1 = -x * sy + z * cy
        cx = math.cos(self.rotation_x)
        sx = math.sin(self.rotation_x)
        y2 = y * cx - z1 * sx
        z2 = y * sx + z1 * cx
        return x1, y2, z2

    def _project(self, point: Tuple[float, float, float], width: int, height: int) -> Tuple[float, float, float]:
        x, y, z = self._rotate_point(point)
        focal = 3.2
        depth = focal / max(0.7, focal - z)
        screen_x = width / 2 + x * 310 * depth * self.scale
        screen_y = height / 2 + y * 310 * depth * self.scale
        return screen_x, screen_y, z

    def draw(self) -> None:
        width = max(self.canvas.winfo_width(), 800)
        height = max(self.canvas.winfo_height(), 520)
        self.canvas.delete("all")
        face_defs = [
            (0, [(0.5, -0.5, 0.5), (0.5, 0.5, 0.5), (-0.5, 0.5, 0.5), (-0.5, -0.5, 0.5)]),
            (1, [(0.5, -0.5, -0.5), (-0.5, -0.5, -0.5), (-0.5, 0.5, -0.5), (0.5, 0.5, -0.5)]),
            (2, [(-0.5, -0.5, -0.5), (-0.5, -0.5, 0.5), (-0.5, 0.5, 0.5), (-0.5, 0.5, -0.5)]),
            (3, [(0.5, -0.5, 0.5), (0.5, -0.5, -0.5), (0.5, 0.5, -0.5), (0.5, 0.5, 0.5)]),
            (4, [(-0.5, -0.5, 0.5), (0.5, -0.5, 0.5), (0.5, -0.5, -0.5), (-0.5, -0.5, -0.5)]),
            (5, [(-0.5, 0.5, -0.5), (-0.5, 0.5, 0.5), (0.5, 0.5, 0.5), (0.5, 0.5, -0.5)])
        ]
        render: List[Tuple[float, int, List[Tuple[float, float]], Tuple[float, float, float, float]]] = []
        palette = ["#d7e7ff", "#dce9dc", "#f4e4c6", "#eadcf7", "#f1d9df", "#d9edef"]
        hover_palette = ["#bcd7ff", "#c7e3c7", "#f6dcab", "#dfcbf5", "#f0c2cd", "#c5e6e8"]
        for index, vertices in face_defs:
            projected = [self._project(vertex, width, height) for vertex in vertices]
            avg_z = sum(point[2] for point in projected) / 4.0
            polygon = [(point[0], point[1]) for point in projected]
            xs = [p[0] for p in polygon]
            ys = [p[1] for p in polygon]
            center = (sum(xs) / 4.0, sum(ys) / 4.0)
            render.append((avg_z, index, polygon, (center[0], center[1], sum(xs) / 4.0, sum(ys) / 4.0)))
        render.sort(key=lambda item: item[0])
        self.rendered_faces = render

        for avg_z, index, polygon, center_info in render:
            is_hovered = (index == self.hovered_face)
            if is_hovered:
                fill_color = hover_palette[index]
            else:
                fill_color = palette[index]
            if is_hovered:
                outline_color = PRIMARY
            else:
                outline_color = "#5b6573"
            if is_hovered:
                outline_width = 3
            else:
                outline_width = 2
            self.canvas.create_polygon(polygon, fill=fill_color, outline=outline_color, width=outline_width)
            if avg_z > -0.05:
                center_x, center_y, _, _ = center_info
                title, subtitle = self.faces[index]
                if is_hovered:
                    text_color = PRIMARY
                else:
                    text_color = DARK
                self.canvas.create_text(center_x, center_y - 12, text=title, fill=text_color, font=("Segoe UI", 18, "bold"))
                self.canvas.create_text(center_x, center_y + 16, text=subtitle, fill=MUTED, font=("Segoe UI", 9))

        nearest = self._nearest_face()
        if self.hovered_face is not None:
            hov_title, hov_sub = self.faces[self.hovered_face]
            top_heading = f"▶ Clic para abrir módulo: {hov_title}"
            sub_heading = f"{hov_sub} (haz clic directamente sobre la cara para entrar)"
            head_color = PRIMARY
        elif nearest is not None:
            front_title, front_sub = self.faces[nearest[0]]
            top_heading = f"Módulo frontal: {front_title}"
            sub_heading = f"{front_sub} · Haz clic en cualquier cara para abrirla · Arrastra para rotar"
            head_color = DARK
            if hasattr(self, "btn_open_front"):
                self.btn_open_front.configure(text=f"Abrir módulo: {front_title}")
        else:
            top_heading = "Navegación 3D de Módulos"
            sub_heading = "Haz clic en cualquier cara para abrirla · Arrastra para rotar · Rueda para zoom"
            head_color = DARK

        self.canvas.create_text(width / 2, 34, text=top_heading, fill=head_color, font=("Segoe UI", 18, "bold"))
        self.canvas.create_text(width / 2, 60, text=sub_heading, fill=MUTED, font=("Segoe UI", 10))


class PEAApp(tk.Tk):
    def __init__(self, service: ApplicationService) -> None:
        super().__init__()
        self.service = service
        self.title("PEA-i Programa Estadístico de Análisis de Investigacion")
        self.geometry("1250x760")
        self.minsize(1050, 680)
        self.configure(bg=BG)
        self.current_view = "Inicio"
        self.previous_view = "Inicio"
        self.content: Optional[tk.Frame] = None
        self.status = tk.StringVar(value="Sistema listo")
        self.nav_frame = None
        self.in_cube_mode = False
        self.was_nav_visible_before_cube = True
        self._configure_styles()
        self._build_shell()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.show_view("Inicio")

    def on_close(self) -> None:
        self.destroy()
        sys.exit(0)

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TButton", font=("Segoe UI", 10), padding=8)
        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=10)
        style.configure("TLabel", background=BG, foreground=DARK, font=("Segoe UI", 10))
        style.configure("Treeview", rowheight=30, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def _build_shell(self) -> None:
        self.top_frame = tk.Frame(self, bg=PANEL, height=68, highlightbackground=BORDER, highlightthickness=1)
        self.top_frame.pack(fill="x")
        self.menu_button = ttk.Button(self.top_frame, text="☰", width=4, command=self.toggle_nav)
        self.menu_button.pack(side="left", padx=14, pady=12)
        self.title_label = tk.Label(self.top_frame, text="PEA-i Programa Estadístico de Análisis de Investigacion", bg=PANEL, fg=DARK, font=("Segoe UI", 15, "bold"))
        self.title_label.pack(side="left")
        self.subtitle_label = tk.Label(self.top_frame, text="Gestión y Análisis de Información de Investigación", bg=PANEL, fg=MUTED, font=("Segoe UI", 9))
        self.subtitle_label.pack(side="left", padx=12, pady=(17, 0))
        self.close_button = ttk.Button(self.top_frame, text="⏻", width=4, command=self.on_close)
        self.close_button.pack(side="right", padx=14)
        self.cube_button = ttk.Button(self.top_frame, text="◇ Modo Cubo", command=self.show_cube)
        self.cube_button.pack(side="right", padx=4)

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        self.nav_frame = tk.Frame(body, bg="#202a36", width=215)
        self.nav_visible = True
        self.nav_frame.pack(side="left", fill="y")
        self._build_nav()
        self.main_frame = tk.Frame(body, bg=BG)
        self.main_frame.pack(side="right", fill="both", expand=True)

        self.bottom_frame = tk.Frame(self, bg=PANEL, height=48, highlightbackground=BORDER, highlightthickness=1)
        self.bottom_frame.pack(fill="x")
        ttk.Button(self.bottom_frame, text="💾 Guardar datos", command=self.save_data).pack(side="left", padx=14, pady=7)
        tk.Label(self.bottom_frame, textvariable=self.status, bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(side="left", padx=18)

    def _build_nav(self) -> None:
        tk.Label(self.nav_frame, text="MÓDULOS", bg="#202a36", fg="#cfd7e3", font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=22, pady=(25, 12))
        options = ["Inicio", "Investigadores", "Grupos", "Carga de Datos", "Estadísticas", "Reportes / Análisis"]
        for option in options:
            button = tk.Button(self.nav_frame, text=option, bg="#202a36", fg="#edf2f7", activebackground="#314154", activeforeground="#ffffff", bd=0, anchor="w", font=("Segoe UI", 10), padx=22, pady=11, command=lambda name=option: self.show_view(name))
            button.pack(fill="x")

    def toggle_nav(self) -> None:
        if not getattr(self, "in_cube_mode", False):
            if self.nav_visible:
                self.nav_frame.pack_forget()
                self.nav_visible = False
            else:
                self.nav_frame.pack(side="left", fill="y", before=self.main_frame)
                self.nav_visible = True

    def clear_content(self) -> None:
        if self.content is not None:
            self.content.destroy()
        self.content = tk.Frame(self.main_frame, bg=BG)
        self.content.pack(fill="both", expand=True, padx=28, pady=24)

    def show_view(self, name: str) -> None:
        if getattr(self, "in_cube_mode", False):
            self.in_cube_mode = False
            if hasattr(self, "menu_button") and not self.menu_button.winfo_ismapped():
                self.menu_button.pack(side="left", padx=14, pady=12, before=self.title_label)
            if hasattr(self, "cube_button") and not self.cube_button.winfo_ismapped():
                self.cube_button.pack(side="right", padx=4, before=self.close_button)
            if hasattr(self, "bottom_frame") and not self.bottom_frame.winfo_ismapped():
                self.bottom_frame.pack(fill="x")
            if getattr(self, "was_nav_visible_before_cube", True):
                if not self.nav_visible:
                    self.nav_frame.pack(side="left", fill="y", before=self.main_frame)
                    self.nav_visible = True
            else:
                if self.nav_visible:
                    self.nav_frame.pack_forget()
                    self.nav_visible = False

        self.current_view = name
        self.clear_content()
        if name == "Inicio":
            self.build_dashboard()
        elif name == "Investigadores":
            self.build_investigators()
        elif name == "Grupos":
            self.build_groups()
        elif name == "Carga de Datos":
            self.build_loading()
        elif name == "Estadísticas":
            self.build_statistics()
        elif name == "Reportes / Análisis":
            self.build_reports()

    def show_cube(self) -> None:
        if not getattr(self, "in_cube_mode", False):
            self.in_cube_mode = True
            self.previous_view = self.current_view or "Inicio"
            self.was_nav_visible_before_cube = self.nav_visible

            # Hide left navigation module list
            if self.nav_visible:
                self.nav_frame.pack_forget()
                self.nav_visible = False

            # Hide top bar "Modo Cubo" button and menu button
            if hasattr(self, "cube_button") and self.cube_button.winfo_ismapped():
                self.cube_button.pack_forget()
            if hasattr(self, "menu_button") and self.menu_button.winfo_ismapped():
                self.menu_button.pack_forget()

            # Hide bottom bar for distraction-free 3D cube view
            if hasattr(self, "bottom_frame") and self.bottom_frame.winfo_ismapped():
                self.bottom_frame.pack_forget()

            self.clear_content()
            cube = CubeView(self.content, on_select=self.open_cube_module, on_exit=self.exit_cube)
            cube.pack(fill="both", expand=True)

    def exit_cube(self, target_view: Optional[str] = None) -> None:
        if not getattr(self, "in_cube_mode", False):
            if target_view:
                self.show_view(target_view)
        else:
            self.in_cube_mode = False

            # Restore top bar buttons
            if hasattr(self, "menu_button") and not self.menu_button.winfo_ismapped():
                self.menu_button.pack(side="left", padx=14, pady=12, before=self.title_label)
            if hasattr(self, "cube_button") and not self.cube_button.winfo_ismapped():
                self.cube_button.pack(side="right", padx=4, before=self.close_button)

            # Restore bottom bar
            if hasattr(self, "bottom_frame") and not self.bottom_frame.winfo_ismapped():
                self.bottom_frame.pack(fill="x")

            # Restore left navigation menu only if it was open prior to entering cube mode
            if getattr(self, "was_nav_visible_before_cube", True):
                if not self.nav_visible:
                    self.nav_frame.pack(side="left", fill="y", before=self.main_frame)
                    self.nav_visible = True
            else:
                if self.nav_visible:
                    self.nav_frame.pack_forget()
                    self.nav_visible = False

            dest = target_view or getattr(self, "previous_view", "Inicio") or "Inicio"
            self.show_view(dest)

    def open_cube_module(self, module: str) -> None:
        self.exit_cube(target_view=module)

    def heading(self, title: str, subtitle: str) -> None:
        tk.Label(self.content, text=title, bg=BG, fg=DARK, font=("Segoe UI", 26, "bold")).pack(anchor="w")
        tk.Label(self.content, text=subtitle, bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(2, 18))

    def card(self, parent: tk.Misc, title: str, value: str, note: str = "") -> tk.Frame:
        frame = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        tk.Label(frame, text=title.upper(), bg=PANEL, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=16, pady=(14, 3))
        tk.Label(frame, text=value, bg=PANEL, fg=DARK, font=("Segoe UI", 26, "bold")).pack(anchor="w", padx=16)
        if note:
            tk.Label(frame, text=note, bg=PANEL, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w", padx=16, pady=(1, 14))
        else:
            frame.configure(pady=10)
        return frame

    def build_dashboard(self) -> None:
        self.heading("Dashboard", "Visión general de grupos de investigación e investigadores institucionales")
        stats = self.service.statistics()

        total_inv = stats["investigadores"]
        active_inv = stats["investigadores_activos"]
        if total_inv:
            inv_note = f"{active_inv} activos"
        else:
            inv_note = "registrados"
        total_groups = stats["grupos"]
        total_products = stats["productos"]
        total_members = sum(len(g.get("integrantes", [])) for g in self.service.grupos)
        if total_groups:
            members_note = "en grupos"
        else:
            members_note = "vinculaciones"

        cards = tk.Frame(self.content, bg=BG)
        cards.pack(fill="x")
        kpis = [
            ("Investigadores", str(total_inv), inv_note),
            ("Grupos de Investigación", str(total_groups), "unidades cargadas"),
            ("Producción Científica", str(total_products), "productos únicos"),
            ("Integrantes Vinculados", str(total_members), members_note)
        ]
        for index, (title, value, note) in enumerate(kpis):
            card = self.card(cards, title, value, note)
            if index == 0:
                left_pad = 0
            else:
                left_pad = 8
            if index == len(kpis) - 1:
                right_pad = 0
            else:
                right_pad = 8
            card.grid(row=0, column=index, sticky="nsew", padx=(left_pad, right_pad))
            cards.grid_columnconfigure(index, weight=1)

        lower = tk.Frame(self.content, bg=BG)
        lower.pack(fill="both", expand=True, pady=18)

        # Panel Izquierdo: Panorama de Grupos de Investigación
        groups_frame = tk.Frame(lower, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        groups_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        tk.Label(groups_frame, text="Grupos de Investigación Registrados", bg=PANEL, fg=DARK, font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=16, pady=(16, 2))
        tk.Label(groups_frame, text="Unidades académicas, clasificación Minciencias y líderes", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(0, 10))

        if not self.service.grupos:
            empty_grp = tk.Frame(groups_frame, bg="#fbfcfe", highlightbackground=BORDER, highlightthickness=1)
            empty_grp.pack(fill="both", expand=True, padx=16, pady=12)
            tk.Label(empty_grp, text="No hay grupos de investigación registrados en el sistema.", bg="#fbfcfe", fg=MUTED, font=("Segoe UI", 10)).pack(pady=(35, 6))
            tk.Label(empty_grp, text="Puedes importar grupos y sus integrantes desde el módulo de carga.", bg="#fbfcfe", fg=MUTED, font=("Segoe UI", 9)).pack(pady=(0, 14))
            ttk.Button(empty_grp, text="Ir a Carga de Datos (GrupLAC)", command=lambda: self.show_view("Carga de Datos")).pack(pady=(0, 30))
        else:
            tree_container = tk.Frame(groups_frame, bg=PANEL)
            tree_container.pack(fill="both", expand=True, padx=16, pady=(0, 8))

            grp_tree = ttk.Treeview(tree_container, columns=("nombre", "clasif", "lider", "integrantes", "productos"), show="headings", height=7)
            sb = ttk.Scrollbar(tree_container, orient="vertical", command=grp_tree.yview)
            grp_tree.configure(yscrollcommand=sb.set)

            grp_tree.heading("nombre", text="Nombre del Grupo")
            grp_tree.column("nombre", width=220, anchor="w")
            grp_tree.heading("clasif", text="Clasif.")
            grp_tree.column("clasif", width=65, anchor="center")
            grp_tree.heading("lider", text="Líder")
            grp_tree.column("lider", width=160, anchor="w")
            grp_tree.heading("integrantes", text="Integrantes")
            grp_tree.column("integrantes", width=75, anchor="center")
            grp_tree.heading("productos", text="Productos")
            grp_tree.column("productos", width=75, anchor="center")

            grp_tree.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")

            clasif_counts: Dict[str, int] = {}
            for g in self.service.grupos:
                c = g.get("clasificacion", "").strip() or "Sin clasificación"
                clasif_counts[c] = clasif_counts.get(c, 0) + 1
                grp_tree.insert("", "end", values=(
                    g.get("nombreGrupo", "Sin nombre"),
                    g.get("clasificacion", "") or "S/C",
                    g.get("lider", "No especificado"),
                    len(g.get("integrantes", [])),
                    len(g.get("productos", []))
                ))

            grp_tree.bind("<Double-1>", lambda event: self.show_view("Grupos"))

            footer_grp = tk.Frame(groups_frame, bg=PANEL)
            footer_grp.pack(fill="x", padx=16, pady=(0, 12))

            clasif_parts = [f"{k}: {v}" for k, v in sorted(clasif_counts.items(), key=lambda x: str(x[0]))]
            if clasif_parts:
                clasif_str = "Clasificaciones: " + " · ".join(clasif_parts)
            else:
                clasif_str = "Clasificaciones: N/A"
            tk.Label(footer_grp, text=clasif_str, bg=PANEL, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(side="left")
            ttk.Button(footer_grp, text="Ver módulo Grupos", command=lambda: self.show_view("Grupos")).pack(side="right")

        # Panel Derecho: Contenedor con Scroll para Investigadores y Repositorio
        right_container = tk.Frame(lower, bg=BG, width=350)
        right_container.pack(side="right", fill="both")
        right_container.pack_propagate(False)

        right_canvas = tk.Canvas(right_container, bg=BG, highlightthickness=0)
        right_scroll = ttk.Scrollbar(right_container, orient="vertical")

        def _custom_right_yview(*args) -> None:
            try:
                fits = False
                bbox = right_canvas.bbox("all")
                if bbox:
                    content_h = bbox[3] - bbox[1]
                    canv_h = right_canvas.winfo_height()
                    if content_h <= canv_h:
                        right_canvas.yview_moveto(0.0)
                        fits = True
                if not fits:
                    right_canvas.yview(*args)
                    y0, y1 = right_canvas.yview()
                    if y0 < 0.0:
                        right_canvas.yview_moveto(0.0)
                    elif y1 > 1.0:
                        right_canvas.yview_moveto(max(0.0, 1.0 - (y1 - y0)))
            except Exception:
                pass

        right_scroll.configure(command=_custom_right_yview)
        scrollable_right = tk.Frame(right_canvas, bg=BG)
        window_id = right_canvas.create_window((0, 0), window=scrollable_right, anchor="nw")

        right_scroll.pack(side="right", fill="y")
        right_canvas.pack(side="left", fill="both", expand=True)

        def _update_right_scroll_bounds(event=None) -> None:
            try:
                canv_w = right_canvas.winfo_width()
                canv_h = right_canvas.winfo_height()
                if canv_w > 1 and canv_h > 1:
                    right_canvas.itemconfig(window_id, width=canv_w)
                    bbox = right_canvas.bbox("all")
                    if bbox:
                        content_h = max(bbox[3] - bbox[1], 1)
                        eff_h = max(canv_h, content_h)
                        right_canvas.configure(scrollregion=(0, 0, canv_w, eff_h))
                        if content_h <= canv_h:
                            right_canvas.yview_moveto(0.0)
                            if right_scroll.winfo_ismapped():
                                right_scroll.pack_forget()
                        else:
                            if not right_scroll.winfo_ismapped():
                                right_scroll.pack(side="right", fill="y", before=right_canvas)
            except Exception:
                pass

        scrollable_right.bind("<Configure>", _update_right_scroll_bounds)
        right_canvas.bind("<Configure>", _update_right_scroll_bounds)
        right_canvas.configure(yscrollcommand=right_scroll.set)

        def _on_mousewheel(event) -> None:
            try:
                bbox = right_canvas.bbox("all")
                if bbox:
                    content_h = bbox[3] - bbox[1]
                    canv_h = right_canvas.winfo_height()
                    if content_h <= canv_h:
                        right_canvas.yview_moveto(0.0)
                    else:
                        if hasattr(event, "delta") and event.delta:
                            delta = int(-1 * (event.delta / 120))
                        else:
                            delta = 0
                        if delta != 0:
                            y0, y1 = right_canvas.yview()
                            if delta < 0 and y0 <= 0.0:
                                right_canvas.yview_moveto(0.0)
                            elif not (delta > 0 and y1 >= 1.0):
                                right_canvas.yview_scroll(delta, "units")
                                y0_n, y1_n = right_canvas.yview()
                                if y0_n < 0.0:
                                    right_canvas.yview_moveto(0.0)
                                elif y1_n > 1.0:
                                    right_canvas.yview_moveto(max(0.0, 1.0 - (y1_n - y0_n)))
            except Exception:
                pass

        def _bind_mouse(event=None) -> None:
            right_canvas.bind_all("<MouseWheel>", _on_mousewheel)

        def _unbind_mouse(event=None) -> None:
            try:
                right_canvas.unbind_all("<MouseWheel>")
            except Exception:
                pass

        right_canvas.bind("<Enter>", _bind_mouse)
        right_canvas.bind("<Leave>", _unbind_mouse)
        scrollable_right.bind("<Enter>", _bind_mouse)
        scrollable_right.bind("<Leave>", _unbind_mouse)

        inv_panel = tk.Frame(scrollable_right, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        inv_panel.pack(fill="x", pady=(0, 10))

        tk.Label(inv_panel, text="Investigadores por Nivel", bg=PANEL, fg=DARK, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(12, 2))
        tk.Label(inv_panel, text="Categorización reconocida en Minciencias", bg=PANEL, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w", padx=16, pady=(0, 8))

        if not self.service.investigadores:
            tk.Label(inv_panel, text="No hay investigadores registrados.", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(padx=16, pady=8)
            ttk.Button(inv_panel, text="Cargar desde CvLAC", command=lambda: self.show_view("Carga de Datos")).pack(padx=16, pady=(0, 12))
        else:
            cat_map = {
                "Investigador Emérito": 0,
                "Investigador Sénior": 0,
                "Investigador Asociado": 0,
                "Investigador Junior": 0,
                "En formación / Sin categoría": 0,
            }
            for inv in self.service.investigadores:
                cat_raw = inv.get("categoriaInvestigador", "").lower()
                if "emérito" in cat_raw or "emerito" in cat_raw:
                    cat_map["Investigador Emérito"] += 1
                elif "sénior" in cat_raw or "senior" in cat_raw:
                    cat_map["Investigador Sénior"] += 1
                elif "asociado" in cat_raw:
                    cat_map["Investigador Asociado"] += 1
                elif "junior" in cat_raw:
                    cat_map["Investigador Junior"] += 1
                else:
                    cat_map["En formación / Sin categoría"] += 1

            for cat_name, count in cat_map.items():
                row = tk.Frame(inv_panel, bg=PANEL)
                row.pack(fill="x", padx=16, pady=2)
                tk.Label(row, text=cat_name, bg=PANEL, fg=DARK, font=("Segoe UI", 9)).pack(side="left")
                if count > 0:
                    fg_col = PRIMARY
                else:
                    fg_col = MUTED
                tk.Label(row, text=str(count), bg=PANEL, fg=fg_col, font=("Segoe UI", 9, "bold")).pack(side="right")

            activos_cnt = stats["investigadores_activos"]
            tot_cnt = stats["investigadores"]
            if tot_cnt:
                pct_act = int(round(100 * activos_cnt / tot_cnt))
            else:
                pct_act = 0
            tk.Label(inv_panel, text=f"Actividad: {activos_cnt} de {tot_cnt} investigadores activos ({pct_act}%)", bg=PANEL, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w", padx=16, pady=(8, 8))
            ttk.Button(inv_panel, text="Ver módulo Investigadores", command=lambda: self.show_view("Investigadores")).pack(fill="x", padx=16, pady=(0, 10))

        repo_panel = tk.Frame(scrollable_right, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        repo_panel.pack(fill="x", pady=(0, 4))

        tk.Label(repo_panel, text="Gestión del Repositorio", bg=PANEL, fg=DARK, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(12, 2))

        last = self.service.last_saved or "Aún no se ha guardado en esta sesión"
        tk.Label(repo_panel, text="Último guardado en disco:", bg=PANEL, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=16, pady=(4, 1))
        tk.Label(repo_panel, text=last, bg=PANEL, fg=DARK, font=("Segoe UI", 8), wraplength=270, justify="left").pack(anchor="w", padx=16, pady=(0, 8))

        quick_btns = tk.Frame(repo_panel, bg=PANEL)
        quick_btns.pack(fill="x", padx=16, pady=(0, 10))
        ttk.Button(quick_btns, text="💾 Guardar datos", command=self.save_data).pack(fill="x", pady=2)
        ttk.Button(quick_btns, text="+ Incorporar datos", command=lambda: self.show_view("Carga de Datos")).pack(fill="x", pady=2)
        ttk.Button(quick_btns, text="📊 Explorar estadísticas", command=lambda: self.show_view("Estadísticas")).pack(fill="x", pady=2)

        def _attach_scroll(widget: tk.Misc) -> None:
            widget.bind("<Enter>", _bind_mouse, add="+")
            widget.bind("<Leave>", _unbind_mouse, add="+")
            for child in widget.winfo_children():
                _attach_scroll(child)

        _attach_scroll(scrollable_right)

    def build_investigators(self) -> None:
        self.heading("Investigadores", "Consulta y gestión de investigadores cargados desde CvLAC")
        bar = tk.Frame(self.content, bg=BG)
        bar.pack(fill="x", pady=(0, 10))
        entry = ttk.Entry(bar)
        entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        entry.insert(0, "")
        ttk.Button(bar, text="Buscar", command=lambda: self.refresh_investigator_tree(tree, entry.get())).pack(side="left")
        ttk.Button(bar, text="Ver detalle", command=lambda: self.show_investigator_detail(tree)).pack(side="left", padx=8)
        ttk.Button(bar, text="Activar / desactivar", command=lambda: self.toggle_selected_investigator(tree)).pack(side="left")
        tree = self._create_tree(self.content, [("codigo", "Código RH", 120), ("nombre", "Nombre", 280), ("categoria", "Categoría", 220), ("nacionalidad", "Nacionalidad", 140), ("estado", "Estado", 100)])
        entry.bind("<Return>", lambda event: self.refresh_investigator_tree(tree, entry.get()))
        tree.bind("<Double-1>", lambda event: self.show_investigator_detail(tree))
        self.refresh_investigator_tree(tree, "")

    def _create_tree(self, parent: tk.Misc, columns: List[Tuple[str, str, int]]) -> ttk.Treeview:
        frame = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(frame, columns=[column[0] for column in columns], show="headings")
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        for key, title, width in columns:
            tree.heading(key, text=title)
            tree.column(key, width=width, anchor="w")
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        return tree

    def refresh_investigator_tree(self, tree: ttk.Treeview, query: str) -> None:
        for iid in tree.get_children():
            tree.delete(iid)
        for item in self.service.search_investigators(query):
            if bool(item.get("activo", True)):
                state = "Activo"
            else:
                state = "Inactivo"
            categoria = item.get("categoriaInvestigador", "")
            disp_categoria = categoria
            if " con vigencia" in categoria:
                disp_categoria = categoria.split(" con vigencia")[0].strip()
            tree.insert("", "end", values=(item.get("codigoRh", ""), item.get("nombre", ""), disp_categoria, item.get("nacionalidad", ""), state))

    def toggle_selected_investigator(self, tree: ttk.Treeview) -> None:
        selected = tree.selection()
        if selected:
            values = tree.item(selected[0], "values")
            if values:
                if self.service.toggle_investigator(values[0]):
                    self.refresh_investigator_tree(tree, "")
                    self.status.set("Estado del investigador actualizado")

    def show_investigator_detail(self, tree: ttk.Treeview) -> None:
        selected = tree.selection()
        values = ()
        if not selected:
            messagebox.showinfo("Detalle de investigador", "Seleccione un investigador de la lista para ver su información.")
        else:
            values = tree.item(selected[0], "values")
        if values:
            investigator = None
            _found_inv = False
            for item in self.service.investigadores:
                if not _found_inv:
                    if values[0] and str(item.get("codigoRh", "")).strip() == str(values[0]).strip():
                        investigator = item
                        _found_inv = True
                    elif not values[0] and str(item.get("nombre", "")).strip() == str(values[1]).strip():
                        investigator = item
                        _found_inv = True
            if investigator is not None:
                fields = [
                    ("codigoRh", "Código RH"),
                    ("nombre", "Nombre"),
                    ("categoriaInvestigador", "Categoría Minciencias"),
                    ("correo", "Correo electrónico"),
                    ("orcid", "ORCID"),
                    ("departamento", "Departamento"),
                    ("ciudad", "Ciudad"),
                    ("nacionalidad", "Nacionalidad"),
                    ("sexo", "Sexo"),
                    ("perfil", "Perfil / Biografía"),
                    ("estadoParEvaluador", "Par evaluador"),
                    ("nombreCitaciones", "Nombre en citaciones"),
                    ("researcherId", "ResearcherID"),
                    ("autorIdScopus", "Scopus ID"),
                    ("googleScholar", "Google Scholar"),
                    ("researchGate", "ResearchGate"),
                    ("academiaEdu", "Academia.edu"),
                    ("mendeley", "Mendeley"),
                    ("linkedin", "LinkedIn"),
                    ("repositorioInstitucional", "Repositorio institucional")
                ]
                lists = [
                    ("Productos", investigator.get("productos", [])),
                    ("Grupos de investigación", investigator.get("gruposInvestigacion", [])),
                    ("Formación académica", investigator.get("formacionAcademica", [])),
                    ("Experiencia profesional", investigator.get("experienciaProfesional", [])),
                    ("Líneas de investigación", investigator.get("lineasInvestigacion", [])),
                    ("Proyectos", investigator.get("proyectos", [])),
                    ("Áreas de conocimiento", investigator.get("areasConocimiento", [])),
                    ("Semilleros", investigator.get("semilleros", [])),
                    ("Reconocimientos", investigator.get("reconocimientos", [])),
                    ("Idiomas", investigator.get("idiomas", []))
                ]
                self._detail_window("Detalle del investigador", investigator, fields, lists)

    def build_groups(self) -> None:
        self.heading("Grupos de investigación", "Consulta y gestión de grupos cargados desde GrupLAC")
        bar = tk.Frame(self.content, bg=BG)
        bar.pack(fill="x", pady=(0, 10))
        entry = ttk.Entry(bar)
        entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(bar, text="Buscar", command=lambda: self.refresh_group_tree(tree, entry.get())).pack(side="left")
        ttk.Button(bar, text="Ver detalle", command=lambda: self.show_group_detail(tree)).pack(side="left", padx=8)
        tree = self._create_tree(self.content, [("codigo", "Código", 130), ("nombre", "Nombre", 340), ("lider", "Líder", 220), ("ciudad", "Ciudad", 140), ("categoria", "Clasificación", 130)])
        entry.bind("<Return>", lambda event: self.refresh_group_tree(tree, entry.get()))
        tree.bind("<Double-1>", lambda event: self.show_group_detail(tree))
        self.refresh_group_tree(tree, "")

    def refresh_group_tree(self, tree: ttk.Treeview, query: str) -> None:
        for iid in tree.get_children():
            tree.delete(iid)
        for item in self.service.search_groups(query):
            tree.insert("", "end", values=(item.get("nroGrupo", ""), item.get("nombreGrupo", ""), item.get("lider", ""), item.get("ciudad", ""), item.get("clasificacion", "")))

    def show_group_detail(self, tree: ttk.Treeview) -> None:
        selected = tree.selection()
        values = ()
        if not selected:
            messagebox.showinfo("Detalle del grupo", "Seleccione un grupo de la lista para ver su información.")
        else:
            values = tree.item(selected[0], "values")
        if values:
            group = None
            _found_grp = False
            for item in self.service.grupos:
                if not _found_grp:
                    if str(item.get("nroGrupo", "")).strip() == str(values[0]).strip():
                        group = item
                        _found_grp = True
            if group is not None:
                fields = [
                    ("nroGrupo", "Código"),
                    ("nombreGrupo", "Nombre del grupo"),
                    ("anioFormacion", "Año de formación"),
                    ("departamento", "Departamento"),
                    ("ciudad", "Ciudad"),
                    ("lider", "Líder"),
                    ("clasificacion", "Clasificación"),
                    ("areaConocimiento", "Área de conocimiento"),
                    ("programaNacionalCti", "Programa nacional CTI"),
                    ("programaNacionalCtiSecundario", "Programa nacional CTI secundario"),
                    ("email", "Correo"),
                    ("paginaWeb", "Página web"),
                    ("planEstrategico", "Plan estratégico"),
                    ("estadoArte", "Estado del arte"),
                    ("objetivos", "Objetivos"),
                    ("retos", "Retos"),
                    ("vision", "Visión")
                ]
                lists = [
                    ("Instituciones", group.get("instituciones", [])),
                    ("Integrantes", group.get("integrantes", [])),
                    ("Productos", group.get("productos", [])),
                    ("Líneas de investigación", group.get("lineasInvestigacion", []))
                ]
                self._detail_window("Detalle del grupo", group, fields, lists)

    def _detail_window(
        self,
        title: str,
        data: Dict[str, Any],
        fields: List[Any],
        lists: Optional[List[Tuple[str, List[Any]]]] = None
    ) -> None:
        window = tk.Toplevel(self)
        window.title(title)
        window.geometry("780x640")
        notebook = ttk.Notebook(window)
        notebook.pack(fill="both", expand=True, padx=14, pady=14)

        info = tk.Frame(notebook, bg=PANEL)
        notebook.add(info, text="Información")
        info_scroll = ttk.Scrollbar(info, orient="vertical")
        info_scroll.pack(side="right", fill="y")
        text = tk.Text(info, wrap="word", bg=PANEL, fg=DARK, relief="flat", font=("Segoe UI", 10), yscrollcommand=info_scroll.set)
        text.pack(side="left", fill="both", expand=True, padx=12, pady=12)
        info_scroll.configure(command=text.yview)

        text.tag_config("bold_label", font=("Segoe UI", 10, "bold"), foreground=DARK)
        text.tag_config("hyperlink", foreground="#0d6efd", underline=True)

        url_regex = re.compile(r"https?://[^\s<>\"']+")
        tag_to_url: Dict[str, str] = {}
        link_counter = 0

        for item in fields:
            if isinstance(item, (tuple, list)):
                field_key, display_label = item[0], item[1]
            else:
                field_key, display_label = item, item
            val = data.get(field_key)
            if val not in (None, "", []):
                if isinstance(val, bool):
                    if val:
                        val_str = "Activo"
                    else:
                        val_str = "Inactivo"
                else:
                    val_str = str(val)
                text.insert("end", "{}:\n".format(display_label), "bold_label")
                matches = list(url_regex.finditer(val_str))
                if matches:
                    last_idx = 0
                    for match in matches:
                        start, end = match.span()
                        if start > last_idx:
                            text.insert("end", val_str[last_idx:start])
                        url_target = match.group(0)
                        tag_name = f"link_url_{link_counter}"
                        link_counter += 1
                        tag_to_url[tag_name] = url_target
                        text.insert("end", url_target, (tag_name, "hyperlink"))
                        last_idx = end
                    if last_idx < len(val_str):
                        text.insert("end", val_str[last_idx:])
                else:
                    text.insert("end", val_str)
                text.insert("end", "\n\n")

        def _on_text_click(event: tk.Event) -> None:
            idx = text.index(f"@{event.x},{event.y}")
            opened = False
            for tag in text.tag_names(idx):
                if not opened and tag in tag_to_url:
                    webbrowser.open_new_tab(tag_to_url[tag])
                    opened = True

        def _on_text_motion(event: tk.Event) -> None:
            idx = text.index(f"@{event.x},{event.y}")
            if any(tag in tag_to_url for tag in text.tag_names(idx)):
                text.config(cursor="hand2")
            else:
                text.config(cursor="")

        text.bind("<Button-1>", _on_text_click)
        text.bind("<Motion>", _on_text_motion)
        text.configure(state="disabled")

        if lists is None:
            lists = [("Integrantes", data.get("integrantes", [])), ("Productos", data.get("productos", [])), ("Líneas", data.get("lineasInvestigacion", []))]

        for title_text, values in lists:
            if values:
                pane = tk.Frame(notebook, bg=PANEL)
                notebook.add(pane, text=title_text)

                if title_text.lower() == "idiomas":
                    cols = [
                        ("idioma", "Idioma", 160),
                        ("habla", "Habla", 110),
                        ("escribe", "Escribe", 110),
                        ("lee", "Lee", 110),
                        ("entiende", "Entiende", 110),
                    ]
                    tree = self._create_tree(pane, cols)
                    for item in values:
                        line = str(item).strip()
                        if line:
                            norm_line = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", line.lower()))
                            if norm_line not in ("idiomahablaescribeleeentiende", "hablaescribeleeentiende"):
                                parts = [p.strip() for p in line.split("|")]
                                vals = (parts + [""] * 5)[:5]
                                tree.insert("", "end", values=vals)
                else:
                    scrollbar = ttk.Scrollbar(pane, orient="vertical")
                    scrollbar.pack(side="right", fill="y")
                    listbox = tk.Listbox(pane, font=("Segoe UI", 9), bg=PANEL, fg=DARK, relief="flat", yscrollcommand=scrollbar.set)
                    listbox.pack(side="left", fill="both", expand=True, padx=(12, 0), pady=12)
                    scrollbar.configure(command=listbox.yview)
                    for value in values:
                        if isinstance(value, dict):
                            if value.get("nombre"):
                                if value.get("vinculacion"):
                                    role = f" ({value.get('vinculacion')})"
                                else:
                                    role = ""
                                display = f"{value.get('nombre')}{role}"
                            elif value.get("titulo"):
                                y = value.get("anio") or value.get("ano")
                                if y:
                                    year = f" ({y})"
                                else:
                                    year = ""
                                if value.get("categoria"):
                                    cat = f"[{value.get('categoria')}] "
                                else:
                                    cat = ""
                                if value.get("autores"):
                                    authors = f" - {', '.join(value.get('autores', []))}"
                                else:
                                    authors = ""
                                display = f"{cat}{value.get('titulo')}{year}{authors}"
                            else:
                                display = str(value)
                        else:
                            display = str(value)
                        if display:
                            listbox.insert("end", display)

    def build_loading(self) -> None:
        self.heading("Carga de Datos", "Carga estructurada desde los portales CvLAC y GrupLAC de MinCiencias")
        container = tk.Frame(self.content, bg=BG)
        container.pack(fill="both", expand=True)
        left = tk.Frame(container, bg=PANEL, highlightbackground=BORDER, highlightthickness=1, width=430)
        left.pack(side="left", fill="y", padx=(0, 10))
        tk.Label(left, text="Origen de datos", bg=PANEL, fg=DARK, font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(18, 12))
        kind = tk.StringVar(value="investigador")
        tk.Radiobutton(left, text="Investigador · CvLAC", variable=kind, value="investigador", bg=PANEL, fg=DARK, selectcolor=PANEL, activebackground=PANEL).pack(anchor="w", padx=18, pady=4)
        tk.Radiobutton(left, text="Grupo · GrupLAC", variable=kind, value="grupo", bg=PANEL, fg=DARK, selectcolor=PANEL, activebackground=PANEL).pack(anchor="w", padx=18, pady=4)
        tk.Label(left, text="URL", bg=PANEL, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=18, pady=(20, 4))
        url_entry = ttk.Entry(left)
        url_entry.pack(fill="x", padx=18)
        result_text = tk.Text(left, height=13, wrap="word", bg="#fbfcfe", relief="flat", font=("Segoe UI", 9))
        result_text.pack(fill="both", expand=True, padx=18, pady=16)
        def do_scrape() -> None:
            target_kind = kind.get()
            raw_url = url_entry.get().strip()
            valido, norm_url, error_msg = validar_url_minciencias(target_kind, raw_url)
            if not valido:
                result_text.delete("1.0", "end")
                result_text.insert("end", "⚠️ Validación de URL fallida:\n\n")
                result_text.insert("end", error_msg + "\n")
                self.status.set("URL no válida para la carga")
            else:
                result_text.delete("1.0", "end")
                result_text.insert("end", "Procesando...\n")
                def worker() -> None:
                    ok, result, message = self.service.scrape_and_add(target_kind, norm_url)
                    def finish() -> None:
                        result_text.delete("1.0", "end")
                        result_text.insert("end", message + "\n\n")
                        if ok:
                            result_text.insert("end", "Tipo: {}\n".format(result.get("tipo", "")))
                            result_text.insert("end", "Identificador: {}\n".format(result.get("codigoRh", result.get("nroGrupo", ""))))
                            result_text.insert("end", "Nombre: {}\n".format(result.get("nombre", result.get("nombreGrupo", ""))))
                            self.status.set(message)
                            render_summary(target_kind, result)
                        else:
                            self.status.set("Carga no completada")
                    self.after(0, finish)
                threading.Thread(target=worker, daemon=True).start()
        url_entry.bind("<Return>", lambda event: do_scrape())
        ttk.Button(left, text="Cargar información", style="Primary.TButton", command=do_scrape).pack(fill="x", padx=18, pady=(0, 18))
        right = tk.Frame(container, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        right.pack(side="right", fill="both", expand=True)

        def render_empty_summary() -> None:
            for w in right.winfo_children():
                w.destroy()
            header = tk.Frame(right, bg=PANEL)
            header.pack(fill="x", padx=20, pady=(18, 10))
            tk.Label(header, text="Resumen de datos cargados", bg=PANEL, fg=DARK, font=("Segoe UI", 14, "bold")).pack(anchor="w")
            tk.Label(header, text="Visualización en tiempo real del registro extraído.", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))

            box = tk.Frame(right, bg="#f8fafc", highlightbackground=BORDER, highlightthickness=1)
            box.pack(fill="both", expand=True, padx=20, pady=(10, 20))

            center_frame = tk.Frame(box, bg="#f8fafc")
            center_frame.place(relx=0.5, rely=0.45, anchor="center")

            tk.Label(center_frame, text="📋", font=("Segoe UI", 36), bg="#f8fafc").pack(pady=(0, 10))
            tk.Label(center_frame, text="No hay información reciente cargada", font=("Segoe UI", 12, "bold"), fg=DARK, bg="#f8fafc").pack(pady=(0, 6))
            tk.Label(
                center_frame,
                text="Seleccione el origen (Investigador o Grupo) a la izquierda, ingrese el enlace oficial de MinCiencias (CvLAC o GrupLAC) y presione 'Cargar información'.\n\nAl completar la extracción, aquí aparecerá la síntesis completa de los datos registrados.",
                font=("Segoe UI", 9),
                fg=MUTED,
                bg="#f8fafc",
                wraplength=440,
                justify="center"
            ).pack()

        def render_summary(data_kind: str, data: Dict[str, Any]) -> None:
            for w in right.winfo_children():
                w.destroy()

            header = tk.Frame(right, bg=PANEL)
            header.pack(fill="x", padx=20, pady=(16, 10))
            if data_kind == "investigador":
                title_text = "Resumen del investigador cargado"
            else:
                title_text = "Resumen del grupo cargado"
            tk.Label(header, text=title_text, bg=PANEL, fg=DARK, font=("Segoe UI", 14, "bold")).pack(anchor="w")

            canvas_frame = tk.Frame(right, bg=PANEL)
            canvas_frame.pack(fill="both", expand=True, padx=20, pady=(0, 16))

            canvas = tk.Canvas(canvas_frame, bg=PANEL, highlightthickness=0)
            scrollbar = ttk.Scrollbar(canvas_frame, orient="vertical")

            def _custom_yview(*args) -> None:
                try:
                    fits = False
                    bbox = canvas.bbox("all")
                    if bbox:
                        content_h = bbox[3] - bbox[1]
                        canv_h = canvas.winfo_height()
                        if content_h <= canv_h:
                            canvas.yview_moveto(0.0)
                            fits = True
                    if not fits:
                        canvas.yview(*args)
                        y0, y1 = canvas.yview()
                        if y0 < 0.0:
                            canvas.yview_moveto(0.0)
                        elif y1 > 1.0:
                            canvas.yview_moveto(max(0.0, 1.0 - (y1 - y0)))
                except Exception:
                    pass

            scrollbar.configure(command=_custom_yview)
            scroll_content = tk.Frame(canvas, bg=PANEL)
            canvas_window = canvas.create_window((0, 0), window=scroll_content, anchor="nw")

            scrollbar.pack(side="right", fill="y")
            canvas.pack(side="left", fill="both", expand=True)

            def _update_scroll_bounds(event: Optional[tk.Event] = None) -> None:
                try:
                    canv_w = canvas.winfo_width()
                    canv_h = canvas.winfo_height()
                    if canv_w > 1 and canv_h > 1:
                        canvas.itemconfig(canvas_window, width=canv_w)
                        bbox = canvas.bbox("all")
                        if bbox:
                            content_h = max(bbox[3] - bbox[1], 1)
                            eff_h = max(canv_h, content_h)
                            canvas.configure(scrollregion=(0, 0, canv_w, eff_h))
                            if content_h <= canv_h:
                                canvas.yview_moveto(0.0)
                                if scrollbar.winfo_ismapped():
                                    scrollbar.pack_forget()
                            else:
                                if not scrollbar.winfo_ismapped():
                                    scrollbar.pack(side="right", fill="y", before=canvas)
                except Exception:
                    pass

            canvas.bind("<Configure>", _update_scroll_bounds)
            scroll_content.bind("<Configure>", _update_scroll_bounds)
            canvas.configure(yscrollcommand=scrollbar.set)

            card = tk.Frame(scroll_content, bg="#ffffff", highlightbackground=BORDER, highlightthickness=1)
            card.pack(fill="x", pady=(0, 12))

            if data_kind == "investigador":
                nombre = data.get("nombre", "Investigador sin nombre")
                rh = data.get("codigoRh", "N/A")
                cat = data.get("categoriaInvestigador", "Sin categoría")
                nac = data.get("nacionalidad", "No especificada")
                sexo = data.get("sexo", "No especificado")
                inst = data.get("institucion", "No registrada")
                productos = data.get("productos", [])
                proyectos = data.get("proyectos", [])
                idiomas = data.get("idiomas", [])
                formacion = data.get("formacionAcademica", [])
                experiencia = data.get("experienciaProfesional", [])

                ch = tk.Frame(card, bg="#f8fafc", padx=14, pady=10)
                ch.pack(fill="x")
                tk.Label(ch, text=nombre, font=("Segoe UI", 13, "bold"), fg=DARK, bg="#f8fafc").pack(anchor="w")
                tk.Label(ch, text=f"Perfil CvLAC  •  Código RH: {rh}", font=("Segoe UI", 9), fg=PRIMARY, bg="#f8fafc").pack(anchor="w")

                body = tk.Frame(card, bg="#ffffff", padx=14, pady=12)
                body.pack(fill="x")

                details = [
                    ("Categoría", cat),
                    ("Nacionalidad", nac),
                    ("Sexo", sexo),
                    ("Institución principal", inst)
                ]
                for label_txt, val_txt in details:
                    if val_txt:
                        row = tk.Frame(body, bg="#ffffff")
                        row.pack(fill="x", pady=2)
                        tk.Label(row, text=f"{label_txt}: ", font=("Segoe UI", 9, "bold"), fg=DARK, bg="#ffffff").pack(side="left")
                        tk.Label(row, text=str(val_txt), font=("Segoe UI", 9), fg=MUTED, bg="#ffffff", wraplength=480, justify="left").pack(side="left")

                metrics_frame = tk.Frame(scroll_content, bg=PANEL)
                metrics_frame.pack(fill="x", pady=(0, 12))

                if any("habla" in i.lower() for i in idiomas):
                    base_len = len(idiomas) - 1
                else:
                    base_len = len(idiomas)
                valid_idiomas_cnt = max(0, base_len)
                stats_items = [
                    ("Productos", len(productos)),
                    ("Proyectos", len(proyectos)),
                    ("Idiomas", valid_idiomas_cnt),
                    ("Formación", len(formacion)),
                    ("Experiencia", len(experiencia)),
                ]
                for idx, (st_name, st_val) in enumerate(stats_items):
                    m_card = tk.Frame(metrics_frame, bg="#ffffff", highlightbackground=BORDER, highlightthickness=1, padx=6, pady=8)
                    if idx > 0:
                        padx_val = 2
                    else:
                        padx_val = 0
                    m_card.grid(row=0, column=idx, sticky="nsew", padx=padx_val)
                    metrics_frame.grid_columnconfigure(idx, weight=1)
                    tk.Label(m_card, text=str(st_val), font=("Segoe UI", 13, "bold"), fg=PRIMARY, bg="#ffffff").pack()
                    tk.Label(m_card, text=st_name, font=("Segoe UI", 8), fg=MUTED, bg="#ffffff").pack()

                if productos:
                    p_card = tk.Frame(scroll_content, bg="#ffffff", highlightbackground=BORDER, highlightthickness=1, padx=14, pady=12)
                    p_card.pack(fill="x")
                    tk.Label(p_card, text=f"Productos destacados ({min(4, len(productos))} de {len(productos)})", font=("Segoe UI", 10, "bold"), fg=DARK, bg="#ffffff").pack(anchor="w", pady=(0, 8))
                    for p in productos[:4]:
                        p_tit = p.get("titulo", "Sin título")
                        p_cat = p.get("categoria", "")
                        p_yr = p.get("anio", "")
                        if p_yr:
                            p_yr_str = f" ({p_yr})"
                        else:
                            p_yr_str = ""
                        p_txt = f"• [{p_cat}] {p_tit}{p_yr_str}"
                        tk.Label(p_card, text=p_txt, font=("Segoe UI", 9), fg=DARK, bg="#ffffff", anchor="w", justify="left", wraplength=500).pack(anchor="w", pady=2)
            else:
                nombre = data.get("nombreGrupo", "Grupo sin nombre")
                nro = data.get("nroGrupo", "N/A")
                lider = data.get("lider", "No especificado")
                clasif = data.get("clasificacion", "Sin clasificar")
                anio = data.get("anioFormacion", "")
                ciudad = data.get("ciudad", "")
                depto = data.get("departamento", "")
                area = data.get("areaConocimiento", "")
                integrantes = data.get("integrantes", [])
                productos = data.get("productos", [])
                lineas = data.get("lineasInvestigacion", [])
                instituciones = data.get("instituciones", [])

                ch = tk.Frame(card, bg="#f8fafc", padx=14, pady=10)
                ch.pack(fill="x")
                tk.Label(ch, text=nombre, font=("Segoe UI", 13, "bold"), fg=DARK, bg="#f8fafc").pack(anchor="w")
                tk.Label(ch, text=f"Grupo GrupLAC  •  Código: {nro}", font=("Segoe UI", 9), fg=PRIMARY, bg="#f8fafc").pack(anchor="w")

                body = tk.Frame(card, bg="#ffffff", padx=14, pady=12)
                body.pack(fill="x")

                ubica = f"{ciudad}, {depto}".strip(" ,") or "No registrada"
                details = [
                    ("Líder", lider),
                    ("Clasificación", clasif),
                    ("Año de formación", anio),
                    ("Ubicación", ubica),
                    ("Área de conocimiento", area)
                ]
                for label_txt, val_txt in details:
                    if val_txt:
                        row = tk.Frame(body, bg="#ffffff")
                        row.pack(fill="x", pady=2)
                        tk.Label(row, text=f"{label_txt}: ", font=("Segoe UI", 9, "bold"), fg=DARK, bg="#ffffff").pack(side="left")
                        tk.Label(row, text=str(val_txt), font=("Segoe UI", 9), fg=MUTED, bg="#ffffff", wraplength=480, justify="left").pack(side="left")

                metrics_frame = tk.Frame(scroll_content, bg=PANEL)
                metrics_frame.pack(fill="x", pady=(0, 12))

                stats_items = [
                    ("Integrantes", len(integrantes)),
                    ("Productos", len(productos)),
                    ("Líneas", len(lineas)),
                    ("Instituciones", len(instituciones)),
                ]
                for idx, (st_name, st_val) in enumerate(stats_items):
                    m_card = tk.Frame(metrics_frame, bg="#ffffff", highlightbackground=BORDER, highlightthickness=1, padx=6, pady=8)
                    if idx > 0:
                        padx_val = 2
                    else:
                        padx_val = 0
                    m_card.grid(row=0, column=idx, sticky="nsew", padx=padx_val)
                    metrics_frame.grid_columnconfigure(idx, weight=1)
                    tk.Label(m_card, text=str(st_val), font=("Segoe UI", 13, "bold"), fg=PRIMARY, bg="#ffffff").pack()
                    tk.Label(m_card, text=st_name, font=("Segoe UI", 8), fg=MUTED, bg="#ffffff").pack()

                if productos:
                    p_card = tk.Frame(scroll_content, bg="#ffffff", highlightbackground=BORDER, highlightthickness=1, padx=14, pady=12)
                    p_card.pack(fill="x")
                    tk.Label(p_card, text=f"Productos destacados ({min(4, len(productos))} de {len(productos)})", font=("Segoe UI", 10, "bold"), fg=DARK, bg="#ffffff").pack(anchor="w", pady=(0, 8))
                    for p in productos[:4]:
                        p_tit = p.get("titulo", "Sin título")
                        p_cat = p.get("categoria", "")
                        if p_cat:
                            p_txt = f"• [{p_cat}] {p_tit}"
                        else:
                            p_txt = f"• {p_tit}"
                        tk.Label(p_card, text=p_txt, font=("Segoe UI", 9), fg=DARK, bg="#ffffff", anchor="w", justify="left", wraplength=500).pack(anchor="w", pady=2)

            def _on_wheel(event: tk.Event) -> None:
                try:
                    bbox = canvas.bbox("all")
                    if bbox:
                        canv_h = canvas.winfo_height()
                        content_h = bbox[3] - bbox[1]
                        if content_h <= canv_h:
                            canvas.yview_moveto(0.0)
                        else:
                            if getattr(event, "num", None) == 4:
                                delta = -1
                            elif getattr(event, "num", None) == 5:
                                delta = 1
                            elif hasattr(event, "delta") and event.delta:
                                delta = int(-1 * (event.delta / 120))
                            else:
                                delta = 0

                            if delta != 0:
                                y0, y1 = canvas.yview()
                                if delta < 0 and y0 <= 0.0:
                                    canvas.yview_moveto(0.0)
                                elif not (delta > 0 and y1 >= 1.0):
                                    canvas.yview_scroll(delta, "units")
                                    y0_new, y1_new = canvas.yview()
                                    if y0_new < 0.0:
                                        canvas.yview_moveto(0.0)
                                    elif y1_new > 1.0:
                                        canvas.yview_moveto(max(0.0, 1.0 - (y1_new - y0_new)))
                except Exception:
                    pass

            def _bind_mousewheel_tree(w: tk.Misc) -> None:
                w.bind("<MouseWheel>", _on_wheel, add="+")
                w.bind("<Button-4>", _on_wheel, add="+")
                w.bind("<Button-5>", _on_wheel, add="+")
                for child in w.winfo_children():
                    _bind_mousewheel_tree(child)

            _bind_mousewheel_tree(right)

            def _bind_all(event=None) -> None:
                canvas.bind_all("<MouseWheel>", _on_wheel)
                canvas.bind_all("<Button-4>", _on_wheel)
                canvas.bind_all("<Button-5>", _on_wheel)

            def _unbind_all(event=None) -> None:
                try:
                    canvas.unbind_all("<MouseWheel>")
                    canvas.unbind_all("<Button-4>")
                    canvas.unbind_all("<Button-5>")
                except Exception:
                    pass

            canvas_frame.bind("<Enter>", _bind_all)
            canvas_frame.bind("<Leave>", _unbind_all)
            canvas.bind("<Enter>", _bind_all)
            canvas.bind("<Leave>", _unbind_all)
            scroll_content.bind("<Enter>", _bind_all)
            scroll_content.bind("<Leave>", _unbind_all)
            canvas.after_idle(_update_scroll_bounds)

        render_empty_summary()

    def build_statistics(self) -> None:
        self.heading("Estadísticas", "Visualización exploratoria de los datos cargados en el sistema")
        stats = self.service.statistics()
        cards = tk.Frame(self.content, bg=BG)
        cards.pack(fill="x")
        for index, title, value in [(0, "Investigadores", stats["investigadores"]), (1, "Grupos", stats["grupos"]), (2, "Productos", stats["productos"])]:
            c = self.card(cards, title, str(value))
            c.grid(row=0, column=index, sticky="nsew", padx=(0, 8))
            cards.grid_columnconfigure(index, weight=1)
        charts = tk.Frame(self.content, bg=BG)
        charts.pack(fill="both", expand=True, pady=16)
        bar_panel = tk.Frame(charts, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        bar_panel.pack(side="left", fill="both", expand=True, padx=(0, 8))
        pie_panel = tk.Frame(charts, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        pie_panel.pack(side="right", fill="both", expand=True)
        tk.Label(bar_panel, text="Productos por año", bg=PANEL, fg=DARK, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=14, pady=12)
        bar = tk.Canvas(bar_panel, bg=PANEL, highlightthickness=0)
        bar.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        tk.Label(pie_panel, text="Distribución por categoría", bg=PANEL, fg=DARK, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=14, pady=12)
        pie = tk.Canvas(pie_panel, bg=PANEL, highlightthickness=0)
        pie.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        def render_charts() -> None:
            self.draw_bar_chart(bar, stats.get("anios", {}))
            self.draw_pie_chart(pie, stats.get("categorias", {}))
        bar.bind("<Configure>", lambda event: render_charts())
        pie.bind("<Configure>", lambda event: render_charts())
        self.after(80, render_charts)

    def draw_bar_chart(self, canvas: tk.Canvas, data: Dict[str, int]) -> None:
        canvas.delete("all")
        width = max(canvas.winfo_width(), 450)
        height = max(canvas.winfo_height(), 300)
        if not data:
            canvas.create_text(width / 2, height / 2, text="Sin datos suficientes para graficar", fill=MUTED, font=("Segoe UI", 10))
        else:
            items = sorted(data.items(), key=lambda item: str(item[0]))
            max_value = max(data.values())
            left = 55
            bottom = height - 45
            top = 30
            plot_width = width - left - 20
            plot_height = bottom - top
            canvas.create_line(left, bottom, width - 20, bottom, fill=BORDER)
            count = len(items)
            slot = plot_width / max(count, 1)
            bar_width = max(18, slot * 0.58)
            for index, (label, value) in enumerate(items):
                x = left + slot * index + slot / 2
                bar_height = plot_height * value / max_value
                y0 = bottom - bar_height
                canvas.create_rectangle(x - bar_width / 2, y0, x + bar_width / 2, bottom, fill="#3f75bd", outline="")
                canvas.create_text(x, y0 - 10, text=str(value), fill=DARK, font=("Segoe UI", 8, "bold"))
                canvas.create_text(x, bottom + 16, text=str(label), fill=MUTED, font=("Segoe UI", 8), angle=45)

    def draw_pie_chart(self, canvas: tk.Canvas, data: Dict[str, int]) -> None:
        canvas.delete("all")
        width = max(canvas.winfo_width(), 450)
        height = max(canvas.winfo_height(), 300)
        if not data:
            canvas.create_text(width / 2, height / 2, text="Sin datos suficientes para graficar", fill=MUTED, font=("Segoe UI", 10))
        else:
            palette = ["#3f75bd", "#6ca56c", "#d6a644", "#9b69bc", "#cf6e7c", "#55a8b2", "#8c9ba5"]
            items = sorted(data.items(), key=lambda item: item[1], reverse=True)
            max_categories = 6
            if len(items) > max_categories:
                chart_items = list(items[:max_categories])
                otros_count = sum(val for _, val in items[max_categories:])
                if otros_count > 0:
                    chart_items.append(("Otras categorías", otros_count))
            else:
                chart_items = list(items)

            total = sum(val for _, val in chart_items)
            size = min(width * 0.46, height * 0.72)
            x0 = 20
            y0 = (height - size) / 2
            start = 0.0
            for index, (label, value) in enumerate(chart_items):
                if total:
                    if index == len(chart_items) - 1:
                        extent = 360.0 - start
                    else:
                        extent = 360.0 * value / total
                    color = palette[index % len(palette)]
                    canvas.create_arc(x0, y0, x0 + size, y0 + size, start=start, extent=extent, fill=color, outline=PANEL)
                    start += extent

            legend_x = x0 + size + 24
            legend_y = max(18, int((height - len(chart_items) * 22) / 2))
            for index, (label, value) in enumerate(chart_items):
                color = palette[index % len(palette)]
                canvas.create_rectangle(legend_x, legend_y, legend_x + 12, legend_y + 12, fill=color, outline="")
                if len(label) <= 34:
                    disp_text = label
                else:
                    disp_text = label[:31] + "..."
                canvas.create_text(legend_x + 18, legend_y + 6, text=f"{disp_text} ({value})", anchor="w", fill=DARK, font=("Segoe UI", 8))
                legend_y += 22

    def build_reports(self) -> None:
        self.heading("Reportes / Análisis", "Consultas consolidadas y preparación de salidas analíticas")
        panel = tk.Frame(self.content, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        panel.pack(fill="both", expand=True)
        tk.Label(panel, text="Generador de reportes", bg=PANEL, fg=DARK, font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(18, 8))
        description = "Genera vistas tabulares detalladas o exporta la información general del sistema en formato de texto."
        tk.Label(panel, text=description, bg=PANEL, fg=MUTED, font=("Segoe UI", 9), wraplength=760, justify="left").pack(anchor="w", padx=18, pady=(0, 18))
        ttk.Button(panel, text="Resumen de investigadores", command=self.report_investigators).pack(anchor="w", padx=18, pady=4)
        ttk.Button(panel, text="Resumen de grupos", command=self.report_groups).pack(anchor="w", padx=18, pady=4)
        ttk.Button(panel, text="Resumen de producción", command=self.report_products).pack(anchor="w", padx=18, pady=4)
        ttk.Button(panel, text="Guardar Información del Dashboard", command=self.export_dashboard).pack(anchor="w", padx=18, pady=4)

    def report_investigators(self) -> None:
        stats = self.service.statistics()
        win = tk.Toplevel(self)
        win.title(f"Resumen de investigadores (Total: {stats['investigadores']}, Activos: {stats['investigadores_activos']})")
        win.geometry("800x400")
        
        tree = ttk.Treeview(win, columns=("codigo", "nombre", "categoria"), show="headings")
        tree.heading("codigo", text="Código RH")
        tree.heading("nombre", text="Nombre")
        tree.heading("categoria", text="Categoría")
        
        tree.column("codigo", width=120)
        tree.column("nombre", width=300)
        tree.column("categoria", width=150)
        
        for item in self.service.investigadores:
            tree.insert("", "end", values=(
                item.get("codigoRh", ""),
                item.get("nombre", ""),
                item.get("categoriaInvestigador", "")
            ))
            
        scroll = ttk.Scrollbar(win, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def report_groups(self) -> None:
        win = tk.Toplevel(self)
        win.title(f"Resumen de grupos (Total: {len(self.service.grupos)})")
        win.geometry("900x400")
        
        tree = ttk.Treeview(win, columns=("nro", "nombre", "lider", "clasificacion"), show="headings")
        tree.heading("nro", text="Número")
        tree.heading("nombre", text="Nombre del Grupo")
        tree.heading("lider", text="Líder")
        tree.heading("clasificacion", text="Clasificación")
        
        tree.column("nro", width=120)
        tree.column("nombre", width=300)
        tree.column("lider", width=250)
        tree.column("clasificacion", width=150)
        
        for item in self.service.grupos:
            tree.insert("", "end", values=(
                item.get("nroGrupo", ""),
                item.get("nombreGrupo", ""),
                item.get("lider", ""),
                item.get("clasificacion", "")
            ))
            
        scroll = ttk.Scrollbar(win, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def report_products(self) -> None:
        stats = self.service.statistics()
        win = tk.Toplevel(self)
        win.title(f"Resumen de producción (Total únicos: {stats['productos']})")
        win.geometry("400x400")
        
        tree = ttk.Treeview(win, columns=("anio", "cantidad"), show="headings")
        tree.heading("anio", text="Año")
        tree.heading("cantidad", text="Cantidad de Productos")
        
        for year, count in sorted(stats.get("anios", {}).items(), key=lambda item: str(item[0])):
            tree.insert("", "end", values=(year, count))
            
        scroll = ttk.Scrollbar(win, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def export_dashboard(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", 
            initialfile="Reporte PEA-i Dashboard",
            filetypes=[("Archivo de texto", "*.txt")]
        )
        if path:
            dash = self.service.dashboard()
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write("="*50 + "\n")
                    f.write("      REPORTE PEA-i DASHBOARD\n")
                    f.write("="*50 + "\n\n")
                    
                    f.write("--- ESTADÍSTICAS GENERALES ---\n")
                    stats = dash.get("stats", {})
                    f.write(f"Total Investigadores: {stats.get('investigadores', 0)}\n")
                    f.write(f"Investigadores Activos: {stats.get('investigadores_activos', 0)}\n")
                    f.write(f"Total Grupos: {stats.get('grupos', 0)}\n")
                    f.write(f"Total Productos (Únicos): {stats.get('productos', 0)}\n\n")
                    
                    f.write("--- PRODUCCIÓN POR AÑO ---\n")
                    anios = stats.get("anios", {})
                    for anio, cant in sorted(anios.items(), key=lambda item: str(item[0])):
                        f.write(f"{anio}: {cant} productos\n")
                    f.write("\n")
                    
                    f.write("--- INVESTIGADORES CARGADOS ---\n")
                    for inv in self.service.investigadores:
                        f.write(f"- {inv.get('nombre', 'Sin Nombre')} (RH: {inv.get('codigoRh', 'N/A')})\n")
                    f.write("\n")
                    
                    f.write("--- GRUPOS CARGADOS ---\n")
                    for grp in self.service.grupos:
                        f.write(f"- {grp.get('nombreGrupo', 'Sin Nombre')} (Nro: {grp.get('nroGrupo', 'N/A')})\n")
                messagebox.showinfo("Exportación", "Dashboard exportado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No fue posible exportar: {str(e)}")

    def save_data(self) -> None:
        ok = self.service.save_all()
        if ok:
            self.status.set("Datos guardados correctamente")
            if getattr(self, "current_view", "") == "Inicio":
                self.show_view("Inicio")
            messagebox.showinfo("Guardar datos", "Los investigadores y grupos fueron guardados en JSON.")
        else:
            self.status.set("No se pudieron guardar todos los datos")
            messagebox.showerror("Guardar datos", "No fue posible escribir los archivos JSON.")


# =========================================================================
# PUNTOS DE ENTRADA Y CONTROL DEL APLICATIVO
# =========================================================================

def run_api() -> None:
    """Inicia el servidor API local para servir solicitudes desde C++."""
    service = ApplicationService()
    server = LocalAPIServer(service, HOST, PORT)
    try:
        server.serve_forever()
    except (KeyboardInterrupt, SystemExit):
        server.shutdown()


def run_gui() -> None:
    """Inicia la interfaz grafica de usuario en modo escritorio Tkinter."""
    service = ApplicationService()
    app = PEAApp(service)
    app.mainloop()


def parse_arguments():
    """Parsea los argumentos de linea de comandos."""
    parser = argparse.ArgumentParser(
        prog="PEA-i",
        description="PEA-i Programa Estadístico de Análisis de Investigacion"
    )
    parser.add_argument(
        "--api",
        action="store_true",
        help="Inicia la API local en 127.0.0.1:8765 para integracion con C++"
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_arguments()
    if arguments.api:
        run_api()
    else:
        run_gui()


if __name__ == "__main__":
    main()
