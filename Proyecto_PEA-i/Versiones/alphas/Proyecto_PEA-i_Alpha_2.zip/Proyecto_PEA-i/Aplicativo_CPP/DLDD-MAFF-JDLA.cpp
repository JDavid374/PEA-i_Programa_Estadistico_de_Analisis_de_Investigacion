#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <memory>
#include <sstream>
#include <cstddef>
#include <cstdlib>

#ifdef _WIN32
#include <windows.h>
#include <conio.h>
#else
// Fallback para sistemas no Windows
#include <termios.h>
#include <unistd.h>
#include <stdio.h>

inline void gotoxy(int x, int y) {
    printf("\033[%d;%dH", y, x);
}

inline int _getch() {
    struct termios oldt, newt;
    int ch;

    tcgetattr(STDIN_FILENO, &oldt);

    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);

    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);

    return ch;
}

inline void Sleep(int ms) {
    usleep(ms * 1000);
}

#endif

using namespace std;


// =========================================================================
// GOToxy NATIVO PARA WINDOWS
// =========================================================================

#ifdef _WIN32

void gotoxy(int x, int y) {

    COORD coord;

    coord.X = x;
    coord.Y = y;

    SetConsoleCursorPosition(
        GetStdHandle(STD_OUTPUT_HANDLE),
        coord
    );
}

#endif


// =========================================================================
// JSON
// =========================================================================

#include "json.hpp"

using json = nlohmann::json;


// =========================================================================
// PRODUCTO DE INVESTIGACION
// =========================================================================

struct ProductoInvestigacion {

    string idProducto;
    string titulo;
    string categoria;
    bool validado;
    int anio;

    ProductoInvestigacion(
        string id = "",
        string t = "",
        string c = "",
        bool v = false,
        int a = 0
    )
        : idProducto(id),
          titulo(t),
          categoria(c),
          validado(v),
          anio(a) {
    }
};


// =========================================================================
// NODO PRODUCTO
// =========================================================================

struct NodoProducto {

    ProductoInvestigacion* producto;
    NodoProducto* sig;

    NodoProducto(ProductoInvestigacion* p)
        : producto(p),
          sig(NULL) {
    }

    ~NodoProducto() {
        delete producto;
    }
};


// =========================================================================
// INVESTIGADOR
// =========================================================================

struct Investigador {

    string codigoRh;
    string nombre;
    string correo;

    NodoProducto* productos;

    bool activo;

    Investigador(
        string id = "",
        string nom = "",
        string corr = ""
    )
        : codigoRh(id),
          nombre(nom),
          correo(corr),
          productos(NULL),
          activo(true) {
    }

    ~Investigador() {

        NodoProducto* actual = productos;

        while (actual) {

            NodoProducto* siguiente = actual->sig;

            delete actual;

            actual = siguiente;
        }

        productos = NULL;
    }

    void agregarProducto(
        ProductoInvestigacion* producto
    ) {

        if (!producto)
            return;

        NodoProducto* nuevo =
            new NodoProducto(producto);

        if (!productos) {

            productos = nuevo;

            return;
        }

        NodoProducto* actual = productos;

        while (actual->sig) {

            actual = actual->sig;
        }

        actual->sig = nuevo;
    }
};


// =========================================================================
// NODO INVESTIGADOR
// =========================================================================

struct NodoInvestigador {

    Investigador* investigador;

    NodoInvestigador* ant;
    NodoInvestigador* sig;

    NodoInvestigador(
        Investigador* inv
    )
        : investigador(inv),
          ant(NULL),
          sig(NULL) {
    }

    ~NodoInvestigador() {

        delete investigador;

        investigador = NULL;
    }
};


// =========================================================================
// GRUPO DE INVESTIGACION
// =========================================================================

struct GrupoInvestigacion {

    string nroGrupo;
    string nombreGrupo;

    GrupoInvestigacion(
        string num = "",
        string nom = ""
    )
        : nroGrupo(num),
          nombreGrupo(nom) {
    }
};


// =========================================================================
// NODO GRUPO
// =========================================================================

struct NodoGrupo {

    GrupoInvestigacion* grupo;

    // Los investigadores almacenados dentro del grupo
    // son copias independientes.
    NodoInvestigador* hijoIntegrantes;

    // Los productos pertenecen al grupo.
    NodoProducto* hijoProductos;

    NodoGrupo* sig;

    NodoGrupo(
        GrupoInvestigacion* g
    )
        : grupo(g),
          hijoIntegrantes(NULL),
          hijoProductos(NULL),
          sig(NULL) {
    }

    ~NodoGrupo() {

        // Liberar grupo
        delete grupo;

        // Liberar integrantes
        NodoInvestigador* inv =
            hijoIntegrantes;

        while (inv) {

            NodoInvestigador* siguiente =
                inv->sig;

            delete inv;

            inv = siguiente;
        }

        // Liberar productos
        NodoProducto* prod =
            hijoProductos;

        while (prod) {

            NodoProducto* siguiente =
                prod->sig;

            delete prod;

            prod = siguiente;
        }

        grupo = NULL;
        hijoIntegrantes = NULL;
        hijoProductos = NULL;
    }
};


// =========================================================================
// LISTA DE INVESTIGADORES
// =========================================================================

class ListaInvestigadores {

private:

    NodoInvestigador* cabeza;
    NodoInvestigador* cola;

public:

    ListaInvestigadores()
        : cabeza(NULL),
          cola(NULL) {
    }

    ~ListaInvestigadores() {
        limpiar();
    }


    // ---------------------------------------------------------
    // AGREGAR
    // ---------------------------------------------------------

    void agregar(
        Investigador* inv
    ) {

        if (!inv)
            return;

        NodoInvestigador* nuevo =
            new NodoInvestigador(inv);

        if (!cabeza) {

            cabeza = nuevo;
            cola = nuevo;
        }
        else {

            cola->sig = nuevo;

            nuevo->ant = cola;

            cola = nuevo;
        }
    }


    // ---------------------------------------------------------
    // BUSCAR
    // ---------------------------------------------------------

    Investigador* buscar(
        string codigo
    ) {

        NodoInvestigador* actual =
            cabeza;

        while (actual) {

            if (
                actual->investigador->codigoRh
                == codigo
            ) {

                return actual->investigador;
            }

            actual = actual->sig;
        }

        return NULL;
    }


    // ---------------------------------------------------------
    // DESACTIVAR
    // ---------------------------------------------------------

    void desactivar(
        string codigo
    ) {

        Investigador* inv =
            buscar(codigo);

        if (inv) {

            inv->activo = false;
        }
    }


    // ---------------------------------------------------------
    // OBTENER CABEZA
    // ---------------------------------------------------------

    NodoInvestigador* getCabeza() {

        return cabeza;
    }


    // ---------------------------------------------------------
    // LIMPIAR
    // ---------------------------------------------------------

    void limpiar() {

        NodoInvestigador* actual =
            cabeza;

        while (actual) {

            NodoInvestigador* siguiente =
                actual->sig;

            delete actual;

            actual = siguiente;
        }

        cabeza = NULL;
        cola = NULL;
    }
};


// =========================================================================
// MULTILISTA DE GRUPOS
// =========================================================================

class MultilistaGrupos {

private:

    NodoGrupo* cabeza;

public:

    MultilistaGrupos()
        : cabeza(NULL) {
    }

    ~MultilistaGrupos() {
        limpiar();
    }


    // ---------------------------------------------------------
    // AGREGAR GRUPO
    // ---------------------------------------------------------

    void agregarGrupo(
        GrupoInvestigacion* g
    ) {

        if (!g)
            return;

        NodoGrupo* nuevo =
            new NodoGrupo(g);

        if (!cabeza) {

            cabeza = nuevo;

            return;
        }

        NodoGrupo* actual =
            cabeza;

        while (actual->sig) {

            actual = actual->sig;
        }

        actual->sig = nuevo;
    }


    // ---------------------------------------------------------
    // BUSCAR GRUPO
    // ---------------------------------------------------------

    NodoGrupo* buscarGrupo(
        string idGrupo
    ) {

        NodoGrupo* actual =
            cabeza;

        while (actual) {

            if (
                actual->grupo->nroGrupo
                == idGrupo
            ) {

                return actual;
            }

            actual = actual->sig;
        }

        return NULL;
    }


    // ---------------------------------------------------------
    // AGREGAR INTEGRANTE
    // ---------------------------------------------------------

    void agregarIntegrante(
        string idGrupo,
        Investigador* inv
    ) {

        if (!inv)
            return;

        NodoGrupo* grupo =
            buscarGrupo(idGrupo);

        if (!grupo)
            return;

        NodoInvestigador* nuevo =
            new NodoInvestigador(inv);

        nuevo->sig =
            grupo->hijoIntegrantes;

        if (grupo->hijoIntegrantes) {

            grupo->hijoIntegrantes->ant =
                nuevo;
        }

        grupo->hijoIntegrantes =
            nuevo;
    }


    // ---------------------------------------------------------
    // AGREGAR PRODUCTO
    // ---------------------------------------------------------

    void agregarProducto(
        string idGrupo,
        ProductoInvestigacion* producto
    ) {

        if (!producto)
            return;

        NodoGrupo* grupo =
            buscarGrupo(idGrupo);

        if (!grupo)
            return;

        NodoProducto* nuevo =
            new NodoProducto(producto);

        if (!grupo->hijoProductos) {

            grupo->hijoProductos =
                nuevo;

            return;
        }

        NodoProducto* actual =
            grupo->hijoProductos;

        while (actual->sig) {

            actual = actual->sig;
        }

        actual->sig = nuevo;
    }


    // ---------------------------------------------------------
    // OBTENER CABEZA
    // ---------------------------------------------------------

    NodoGrupo* getCabeza() {

        return cabeza;
    }


    // ---------------------------------------------------------
    // LIMPIAR
    // ---------------------------------------------------------

    void limpiar() {

        NodoGrupo* actual =
            cabeza;

        while (actual) {

            NodoGrupo* siguiente =
                actual->sig;

            delete actual;

            actual = siguiente;
        }

        cabeza = NULL;
    }
};


// =========================================================================
// PILA DE OPERACIONES
// =========================================================================

class PilaOperaciones {

private:

    vector<string> operaciones;

public:

    void push(string op) {

        operaciones.push_back(op);
    }

    string pop() {

        if (operaciones.empty())
            return "";

        string op =
            operaciones.back();

        operaciones.pop_back();

        return op;
    }

    bool empty() {

        return operaciones.empty();
    }
};


// =========================================================================
// COLA DE PROCESAMIENTO
// =========================================================================

class ColaProcesamiento {

private:

    vector<ProductoInvestigacion*> cola;

public:

    void enqueue(
        ProductoInvestigacion* p
    ) {

        if (p)
            cola.push_back(p);
    }

    ProductoInvestigacion* dequeue() {

        if (cola.empty())
            return NULL;

        ProductoInvestigacion* p =
            cola.front();

        cola.erase(
            cola.begin()
        );

        return p;
    }

    bool empty() {

        return cola.empty();
    }
};


// =========================================================================
// HIPERCUBO
// =========================================================================

class HipercuboInformacion {

private:

    double*** matriz;

    int N;
    int M;
    int K;

public:

    HipercuboInformacion(
        int grupos,
        int categorias,
        int anios
    )
        : matriz(NULL),
          N(grupos),
          M(categorias),
          K(anios) {

        matriz =
            new double**[N];

        for (int i = 0; i < N; ++i) {

            matriz[i] =
                new double*[M];

            for (int j = 0; j < M; ++j) {

                matriz[i][j] =
                    new double[K];

                for (int k = 0; k < K; ++k) {

                    matriz[i][j][k] =
                        0.0;
                }
            }
        }
    }


    ~HipercuboInformacion() {

        if (!matriz)
            return;

        for (int i = 0; i < N; ++i) {

            for (int j = 0; j < M; ++j) {

                delete[] matriz[i][j];
            }

            delete[] matriz[i];
        }

        delete[] matriz;

        matriz = NULL;
    }


    void registrarDato(
        int g,
        int c,
        int a,
        double valor
    ) {

        if (
            g >= 0 && g < N &&
            c >= 0 && c < M &&
            a >= 0 && a < K
        ) {

            matriz[g][c][a] +=
                valor;
        }
    }


    void generarResumenEstadistico() {

        cout
            << "Resumen Estadistico Generado..."
            << endl;
    }
};


// =========================================================================
// LECTOR DE ARCHIVOS Y WEB
// =========================================================================

class LectorArchivosYWeb {

public:

    // ---------------------------------------------------------
    // CARGAR INVESTIGADOR DESDE CVLAC
    // ---------------------------------------------------------

    Investigador*
    cargarInvestigadorDesdeWeb(
        const string& url
    ) {

        cout
            << "\nCargando investigador desde CvLAC..."
            << endl;

        cout
            << "URL: "
            << url
            << endl;


        /*
            AQUI IRA EL SCRAPING REAL.

            Flujo:

            1. Descargar la pagina.
            2. Verificar que sea una URL de CvLAC.
            3. Analizar el HTML.
            4. Extraer:
               - codigo RH
               - nombre
               - correo
               - productos
            5. Crear el objeto Investigador.
            6. Agregar sus productos.
            7. Retornar el Investigador*.
        */


        return NULL;
    }


    // ---------------------------------------------------------
    // CARGAR GRUPO DESDE GRUPLAC
    // ---------------------------------------------------------

    GrupoInvestigacion*
    cargarGrupoDesdeWeb(
        const string& url
    ) {

        cout
            << "\nCargando grupo desde GrupLAC..."
            << endl;

        cout
            << "URL: "
            << url
            << endl;


        /*
            AQUI IRA EL SCRAPING REAL.

            Flujo:

            1. Descargar la pagina.
            2. Verificar que sea una URL de GrupLAC.
            3. Analizar el HTML.
            4. Extraer:
               - numero del grupo
               - nombre del grupo
               - integrantes
               - productos
            5. Crear GrupoInvestigacion.
            6. Retornar el grupo.

            IMPORTANTE:

            Por ahora NO seguimos los sub-enlaces.
            Solo procesaremos la pagina cuya URL
            ingreso el usuario.
        */


        return NULL;
    }
};


// =========================================================================
// PERSISTENCIA DE ARCHIVOS
// =========================================================================

class PersistenciaArchivos {

private:

    const string ARCHIVO_INVESTIGADORES =
        "investigadores.json";

    const string ARCHIVO_GRUPOS =
        "grupos.json";


    // =========================================================
    // PRODUCTO -> JSON
    // =========================================================

    json productoAJson(
        ProductoInvestigacion* producto
    ) {

        json j;

        if (!producto)
            return j;

        j["idProducto"] =
            producto->idProducto;

        j["titulo"] =
            producto->titulo;

        j["categoria"] =
            producto->categoria;

        j["validado"] =
            producto->validado;

        j["anio"] =
            producto->anio;

        return j;
    }


    // =========================================================
    // JSON -> PRODUCTO
    // =========================================================

    ProductoInvestigacion*
    jsonAProducto(
        const json& j
    ) {

        return new ProductoInvestigacion(

            j.value(
                "idProducto",
                ""
            ),

            j.value(
                "titulo",
                ""
            ),

            j.value(
                "categoria",
                ""
            ),

            j.value(
                "validado",
                false
            ),

            j.value(
                "anio",
                0
            )
        );
    }


public:

    // =========================================================
    // GUARDAR INVESTIGADORES
    // =========================================================

    bool guardarInvestigadores(
        ListaInvestigadores& lista
    ) {

        json raiz;

        raiz["tipo"] =
            "investigadores";

        raiz["investigadores"] =
            json::array();


        NodoInvestigador* actual =
            lista.getCabeza();


        while (actual) {

            Investigador* inv =
                actual->investigador;

            json jInv;

            jInv["codigoRh"] =
                inv->codigoRh;

            jInv["nombre"] =
                inv->nombre;

            jInv["correo"] =
                inv->correo;

            jInv["activo"] =
                inv->activo;

            jInv["productos"] =
                json::array();


            NodoProducto* producto =
                inv->productos;


            while (producto) {

                jInv["productos"].push_back(

                    productoAJson(
                        producto->producto
                    )
                );

                producto =
                    producto->sig;
            }


            raiz["investigadores"]
                .push_back(jInv);


            actual =
                actual->sig;
        }


        ofstream archivo(
            ARCHIVO_INVESTIGADORES
        );


        if (!archivo.is_open()) {

            return false;
        }


        archivo << raiz.dump(4);

        archivo.close();


        return true;
    }


    // =========================================================
    // CARGAR INVESTIGADORES
    // =========================================================

    bool cargarInvestigadores(
        ListaInvestigadores& lista
    ) {

        ifstream archivo(
            ARCHIVO_INVESTIGADORES
        );


        if (!archivo.is_open()) {

            return false;
        }


        try {

            json raiz;

            archivo >> raiz;

            archivo.close();


            if (
                !raiz.contains(
                    "investigadores"
                )
            ) {

                return false;
            }


            lista.limpiar();


            for (
                const auto& jInv :
                raiz["investigadores"]
            ) {

                Investigador* inv =
                    new Investigador(

                        jInv.value(
                            "codigoRh",
                            ""
                        ),

                        jInv.value(
                            "nombre",
                            ""
                        ),

                        jInv.value(
                            "correo",
                            ""
                        )
                    );


                inv->activo =
                    jInv.value(
                        "activo",
                        true
                    );


                if (
                    jInv.contains(
                        "productos"
                    )
                ) {

                    for (
                        const auto& jProd :
                        jInv["productos"]
                    ) {

                        inv->agregarProducto(

                            jsonAProducto(
                                jProd
                            )
                        );
                    }
                }


                lista.agregar(inv);
            }

        }
        catch (...) {

            archivo.close();

            return false;
        }


        return true;
    }


    // =========================================================
    // GUARDAR GRUPOS
    // =========================================================

    bool guardarGrupos(
        MultilistaGrupos& grupos
    ) {

        json raiz;

        raiz["tipo"] =
            "grupos";

        raiz["grupos"] =
            json::array();


        NodoGrupo* grupo =
            grupos.getCabeza();


        while (grupo) {

            json jGrupo;

            jGrupo["nroGrupo"] =
                grupo->grupo->nroGrupo;

            jGrupo["nombreGrupo"] =
                grupo->grupo->nombreGrupo;

            jGrupo["integrantes"] =
                json::array();

            jGrupo["productos"] =
                json::array();


            // -------------------------------------------------
            // INTEGRANTES
            // -------------------------------------------------

            NodoInvestigador* inv =
                grupo->hijoIntegrantes;


            while (inv) {

                Investigador* investigador =
                    inv->investigador;

                json jInv;

                jInv["codigoRh"] =
                    investigador->codigoRh;

                jInv["nombre"] =
                    investigador->nombre;

                jInv["correo"] =
                    investigador->correo;

                jInv["activo"] =
                    investigador->activo;


                jGrupo["integrantes"]
                    .push_back(jInv);


                inv =
                    inv->sig;
            }


            // -------------------------------------------------
            // PRODUCTOS
            // -------------------------------------------------

            NodoProducto* producto =
                grupo->hijoProductos;


            while (producto) {

                jGrupo["productos"]
                    .push_back(

                        productoAJson(
                            producto->producto
                        )
                    );


                producto =
                    producto->sig;
            }


            raiz["grupos"]
                .push_back(jGrupo);


            grupo =
                grupo->sig;
        }


        ofstream archivo(
            ARCHIVO_GRUPOS
        );


        if (!archivo.is_open()) {

            return false;
        }


        archivo << raiz.dump(4);

        archivo.close();


        return true;
    }


    // =========================================================
    // CARGAR GRUPOS
    // =========================================================

    bool cargarGrupos(
        MultilistaGrupos& grupos
    ) {

        ifstream archivo(
            ARCHIVO_GRUPOS
        );


        if (!archivo.is_open()) {

            return false;
        }


        try {

            json raiz;

            archivo >> raiz;

            archivo.close();


            if (
                !raiz.contains(
                    "grupos"
                )
            ) {

                return false;
            }


            grupos.limpiar();


            for (
                const auto& jGrupo :
                raiz["grupos"]
            ) {

                GrupoInvestigacion* grupo =
                    new GrupoInvestigacion(

                        jGrupo.value(
                            "nroGrupo",
                            ""
                        ),

                        jGrupo.value(
                            "nombreGrupo",
                            ""
                        )
                    );


                grupos.agregarGrupo(
                    grupo
                );


                // -------------------------------------------------
                // INTEGRANTES
                // -------------------------------------------------

                if (
                    jGrupo.contains(
                        "integrantes"
                    )
                ) {

                    for (
                        const auto& jInv :
                        jGrupo["integrantes"]
                    ) {

                        Investigador* inv =
                            new Investigador(

                                jInv.value(
                                    "codigoRh",
                                    ""
                                ),

                                jInv.value(
                                    "nombre",
                                    ""
                                ),

                                jInv.value(
                                    "correo",
                                    ""
                                )
                            );


                        inv->activo =
                            jInv.value(
                                "activo",
                                true
                            );


                        grupos.agregarIntegrante(

                            grupo->nroGrupo,

                            inv
                        );
                    }
                }


                // -------------------------------------------------
                // PRODUCTOS
                // -------------------------------------------------

                if (
                    jGrupo.contains(
                        "productos"
                    )
                ) {

                    for (
                        const auto& jProd :
                        jGrupo["productos"]
                    ) {

                        grupos.agregarProducto(

                            grupo->nroGrupo,

                            jsonAProducto(
                                jProd
                            )
                        );
                    }
                }
            }

        }
        catch (...) {

            archivo.close();

            return false;
        }


        return true;
    }
};


// =========================================================================
// MOTOR DE CONSOLA
// =========================================================================

class MotorConsolaC {

private:

    // =========================================================
    // ESTRUCTURAS PRINCIPALES
    // =========================================================

    ListaInvestigadores listasInv;

    MultilistaGrupos multilistas;


    // =========================================================
    // MODULO DE LECTURA WEB
    // =========================================================

    LectorArchivosYWeb lectorWeb;


    // =========================================================
    // MODULO DE PERSISTENCIA
    // =========================================================

    PersistenciaArchivos persistencia;


    // =========================================================
    // DIBUJAR MARCO
    // =========================================================

    void dibujarMarco() {

#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif

        gotoxy(
            10,
            2
        );

        cout
            << "==========================================================";


        gotoxy(
            10,
            3
        );

        cout
            << "|        PROYECTO PEA-i (Programa Estadistico UPC)       |";


        gotoxy(
            10,
            4
        );

        cout
            << "==========================================================";
    }


    // =========================================================
    // PAUSAR
    // =========================================================

    void pausar() {

        gotoxy(
            10,
            20
        );

        cout
            << "Presione cualquier tecla para continuar...";

        _getch();
    }


    // =========================================================
    // CARGAR INVESTIGADOR
    // =========================================================

    void cargarInvestigador() {

        dibujarMarco();


        gotoxy(
            15,
            6
        );

        cout
            << "--- CARGAR INVESTIGADOR DESDE CvLAC ---";


        gotoxy(
            15,
            8
        );

        cout
            << "Ingrese la URL:";


        gotoxy(
            15,
            9
        );

        cin >> ws;

        string url;

        getline(
            cin,
            url
        );


        // -----------------------------------------------------
        // LLAMAR AL LECTOR WEB
        // -----------------------------------------------------

        Investigador* investigador =

            lectorWeb.cargarInvestigadorDesdeWeb(
                url
            );


        // -----------------------------------------------------
        // ALMACENAR RESULTADO
        // -----------------------------------------------------

        if (
            investigador != NULL
        ) {

            listasInv.agregar(
                investigador
            );


            gotoxy(
                15,
                12
            );

            cout
                << "Investigador cargado correctamente.";
        }

        else {

            gotoxy(
                15,
                12
            );

            cout
                << "No se pudo cargar el investigador.";
        }


        pausar();
    }


    // =========================================================
    // CARGAR GRUPO
    // =========================================================

    void cargarGrupo() {

        dibujarMarco();


        gotoxy(
            15,
            6
        );

        cout
            << "--- CARGAR GRUPO DESDE GrupLAC ---";


        gotoxy(
            15,
            8
        );

        cout
            << "Ingrese la URL:";


        gotoxy(
            15,
            9
        );

        cin >> ws;

        string url;

        getline(
            cin,
            url
        );


        // -----------------------------------------------------
        // LLAMAR AL LECTOR WEB
        // -----------------------------------------------------

        GrupoInvestigacion* grupo =

            lectorWeb.cargarGrupoDesdeWeb(
                url
            );


        // -----------------------------------------------------
        // ALMACENAR RESULTADO
        // -----------------------------------------------------

        if (
            grupo != NULL
        ) {

            multilistas.agregarGrupo(
                grupo
            );


            gotoxy(
                15,
                12
            );

            cout
                << "Grupo cargado correctamente.";
        }

        else {

            gotoxy(
                15,
                12
            );

            cout
                << "No se pudo cargar el grupo.";
        }


        pausar();
    }


    // =========================================================
    // MENU CARGAR DATOS
    // =========================================================

    void menuCargarDatos() {

        int opcion = 0;


        while (
            opcion != 3
        ) {

            dibujarMarco();


            gotoxy(
                15,
                6
            );

            cout
                << "--- CARGAR DATOS ---";


            gotoxy(
                15,
                8
            );

            cout
                << "1. Cargar Investigador";


            gotoxy(
                15,
                9
            );

            cout
                << "2. Cargar Grupo";


            gotoxy(
                15,
                10
            );

            cout
                << "3. Regresar";


            gotoxy(
                15,
                12
            );

            cout
                << "Seleccione una opcion: ";


            cin >> opcion;


            switch (opcion) {

                case 1:

                    cargarInvestigador();

                    break;


                case 2:

                    cargarGrupo();

                    break;


                case 3:

                    break;


                default:

                    gotoxy(
                        15,
                        14
                    );

                    cout
                        << "Opcion no valida.";

                    pausar();

                    break;
            }
        }
    }


public:

    // =========================================================
    // SEMILLA DE PRUEBA
    // =========================================================

    void iniciarSemilla() {

        // -----------------------------------------------------
        // INVESTIGADOR
        // -----------------------------------------------------

        Investigador* inv =

            new Investigador(
                "001",
                "Dr. Juan Perez",
                "jperez@upc.edu.co"
            );


        listasInv.agregar(
            inv
        );


        // -----------------------------------------------------
        // GRUPO
        // -----------------------------------------------------

        GrupoInvestigacion* grupo =

            new GrupoInvestigacion(
                "G8",
                "Grupo de Investigacion UPC"
            );


        multilistas.agregarGrupo(
            grupo
        );


        // -----------------------------------------------------
        // INTEGRANTE DEL GRUPO
        // -----------------------------------------------------

        // Es una copia independiente.
        Investigador* integrante =

            new Investigador(
                "001",
                "Dr. Juan Perez",
                "jperez@upc.edu.co"
            );


        multilistas.agregarIntegrante(
            "G8",
            integrante
        );


        // -----------------------------------------------------
        // PRODUCTO
        // -----------------------------------------------------

        ProductoInvestigacion* producto =

            new ProductoInvestigacion(
                "P001",
                "Sistema de informacion para investigacion",
                "Articulo",
                true,
                2025
            );


        multilistas.agregarProducto(
            "G8",
            producto
        );
    }


    // =========================================================
    // MENU PRINCIPAL
    // =========================================================

    void menuPrincipal() {

        int opcion = 0;


        while (
            opcion != 6
        ) {

            dibujarMarco();


            gotoxy(
                15,
                6
            );

            cout
                << "1. Gestionar Investigadores";


            gotoxy(
                15,
                7
            );

            cout
                << "2. Gestionar Grupos";


            gotoxy(
                15,
                8
            );

            cout
                << "3. Reportes Analiticos (Hipercubo)";


            gotoxy(
                15,
                9
            );

            cout
                << "4. Cargar Datos";


            gotoxy(
                15,
                10
            );

            cout
                << "5. Guardar Datos";


            gotoxy(
                15,
                11
            );

            cout
                << "6. Salir";


            gotoxy(
                15,
                13
            );

            cout
                << "Seleccione una opcion: ";


            cin >> opcion;


            switch (opcion) {


                // =================================================
                // INVESTIGADORES
                // =================================================

                case 1:

                    dibujarMarco();


                    gotoxy(
                        15,
                        6
                    );

                    cout
                        << "--- GESTION DE INVESTIGADORES ---";


                    gotoxy(
                        15,
                        8
                    );

                    cout
                        << "Listado actual:";


                    {
                        int y = 10;

                        NodoInvestigador* act =
                            listasInv.getCabeza();


                        while (
                            act &&
                            y < 19
                        ) {

                            gotoxy(
                                15,
                                y++
                            );


                            cout
                                << "- "
                                << act->investigador->nombre
                                << " ("
                                << act->investigador->codigoRh
                                << ")";


                            act =
                                act->sig;
                        }
                    }


                    pausar();

                    break;


                // =================================================
                // GRUPOS
                // =================================================

                case 2:

                    dibujarMarco();


                    gotoxy(
                        15,
                        6
                    );

                    cout
                        << "--- GESTION DE GRUPOS ---";


                    gotoxy(
                        15,
                        8
                    );

                    cout
                        << "Listado actual:";


                    {
                        int y = 10;

                        NodoGrupo* act =
                            multilistas.getCabeza();


                        while (
                            act &&
                            y < 19
                        ) {

                            gotoxy(
                                15,
                                y++
                            );


                            cout
                                << "- "
                                << act->grupo->nombreGrupo
                                << " ("
                                << act->grupo->nroGrupo
                                << ")";


                            act =
                                act->sig;
                        }
                    }


                    pausar();

                    break;


                // =================================================
                // REPORTES
                // =================================================

                case 3:

                    dibujarMarco();


                    gotoxy(
                        15,
                        8
                    );

                    cout
                        << "Modulo de reportes en desarrollo.";


                    pausar();

                    break;


                // =================================================
                // CARGAR DATOS
                // =================================================

                case 4:

                    menuCargarDatos();

                    break;


                // =================================================
                // GUARDAR DATOS
                // =================================================

                case 5:

                    dibujarMarco();


                    gotoxy(
                        15,
                        6
                    );

                    cout
                        << "--- GUARDAR DATOS ---";


                    {
                        bool investigadoresOK =

                            persistencia.guardarInvestigadores(
                                listasInv
                            );


                        bool gruposOK =

                            persistencia.guardarGrupos(
                                multilistas
                            );


                        gotoxy(
                            15,
                            9
                        );


                        if (
                            investigadoresOK &&
                            gruposOK
                        ) {

                            cout
                                << "Todos los datos fueron "
                                << "guardados correctamente.";
                        }

                        else {

                            cout
                                << "Ocurrio un error al guardar "
                                << "los datos.";
                        }
                    }


                    pausar();

                    break;


                // =================================================
                // SALIR
                // =================================================

                case 6:

                    gotoxy(
                        15,
                        14
                    );

                    cout
                        << "Saliendo del sistema...";


                    Sleep(1000);

                    break;


                // =================================================
                // OPCION INVALIDA
                // =================================================

                default:

                    gotoxy(
                        15,
                        14
                    );

                    cout
                        << "Opcion no valida.";


                    pausar();

                    break;
            }
        }
    }
};


// =========================================================================
// FUNCION PRINCIPAL
// =========================================================================

int main() {

#ifdef _WIN32

    SetConsoleOutputCP(
        CP_UTF8
    );

#endif


    MotorConsolaC motor;


    // ---------------------------------------------------------
    // DATOS DE PRUEBA
    // ---------------------------------------------------------
    //
    // Por ahora dejamos la semilla.
    //
    // Cuando terminemos el modulo de persistencia,
    // podremos cambiar esto por:
    //
    // persistencia.cargarInvestigadores(...)
    // persistencia.cargarGrupos(...)
    //
    // ---------------------------------------------------------

    motor.iniciarSemilla();


    // ---------------------------------------------------------
    // INICIAR MENU
    // ---------------------------------------------------------

    motor.menuPrincipal();


    return 0;
}
