#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <memory>
#include <sstream>
#include <cstddef>

#ifdef _WIN32
#include <windows.h>
#include <conio.h>
#else
// Fallback para sistemas no Windows
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
inline void gotoxy(int x, int y) { printf("\033[%d;%dH", y, x); }
inline int _getch() {
    struct termios oldt, newt;
    int ch;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    return ch;
}
inline void Sleep(int ms) { usleep(ms * 1000); }
#endif

using namespace std;

// Función gotoxy nativa para Windows
#ifdef _WIN32
void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
#endif

// =========================================================================
// ENTIDADES Y NODOS
// =========================================================================

struct ProductoInvestigacion {
    string idProducto;
    string titulo;
    string categoria;
    bool validado;
    int anio;

    ProductoInvestigacion(string id, string t, string c, bool v, int a)
        : idProducto(id), titulo(t), categoria(c), validado(v), anio(a) {}
};

struct NodoProducto {
    ProductoInvestigacion* producto;
    NodoProducto* sig;
    NodoProducto(ProductoInvestigacion* p) : producto(p), sig(NULL) {}
    ~NodoProducto() { delete producto; }
};

struct Investigador {
    string codigoRh;
    string nombre;
    string correo;
    NodoProducto* productos;
    bool activo;

    Investigador(string id, string nom, string corr)
        : codigoRh(id), nombre(nom), correo(corr), productos(NULL), activo(true) {}
};

struct NodoInvestigador {
    Investigador* investigador;
    NodoInvestigador* ant;
    NodoInvestigador* sig;
    NodoInvestigador(Investigador* inv) : investigador(inv), ant(NULL), sig(NULL) {}
    ~NodoInvestigador() { delete investigador; }
};

struct GrupoInvestigacion {
    string nroGrupo;
    string nombreGrupo;

    GrupoInvestigacion(string num, string nom) : nroGrupo(num), nombreGrupo(nom) {}
};

struct NodoGrupo {
    GrupoInvestigacion* grupo;
    NodoInvestigador* hijoIntegrantes;
    NodoProducto* hijoProductos;
    NodoGrupo* sig;

    NodoGrupo(GrupoInvestigacion* g) : grupo(g), hijoIntegrantes(NULL), hijoProductos(NULL), sig(NULL) {}
    ~NodoGrupo() { delete grupo; }
};

// =========================================================================
// ESTRUCTURAS DE DATOS PRINCIPALES
// =========================================================================

class ListaInvestigadores {
private:
    NodoInvestigador* cabeza;
    NodoInvestigador* cola;
public:
    ListaInvestigadores() : cabeza(NULL), cola(NULL) {}

    void agregar(Investigador* inv) {
        NodoInvestigador* nuevo = new NodoInvestigador(inv);
        if (!cabeza) {
            cabeza = cola = nuevo;
        } else {
            cola->sig = nuevo;
            nuevo->ant = cola;
            cola = nuevo;
        }
    }

    void desactivar(string codigo) {
        NodoInvestigador* actual = cabeza;
        while (actual) {
            if (actual->investigador->codigoRh == codigo) {
                actual->investigador->activo = false;
                break;
            }
            actual = actual->sig;
        }
    }

    NodoInvestigador* getCabeza() { return cabeza; }
};

class MultilistaGrupos {
private:
    NodoGrupo* cabeza;
public:
    MultilistaGrupos() : cabeza(NULL) {}

    void agregarGrupo(GrupoInvestigacion* g) {
        NodoGrupo* nuevo = new NodoGrupo(g);
        if (!cabeza) {
            cabeza = nuevo;
        } else {
            NodoGrupo* actual = cabeza;
            while (actual->sig) actual = actual->sig;
            actual->sig = nuevo;
        }
    }

    void agregarIntegrante(string idGrupo, Investigador* inv) {
        NodoGrupo* grupo = cabeza;
        while (grupo) {
            if (grupo->grupo->nroGrupo == idGrupo) {
                NodoInvestigador* nuevo = new NodoInvestigador(inv);
                nuevo->sig = grupo->hijoIntegrantes;
                if (grupo->hijoIntegrantes) grupo->hijoIntegrantes->ant = nuevo;
                grupo->hijoIntegrantes = nuevo;
                break;
            }
            grupo = grupo->sig;
        }
    }

    NodoGrupo* getCabeza() { return cabeza; }
};

// =========================================================================
// PILAS, COLAS Y MATRICES
// =========================================================================

class PilaOperaciones {
private:
    vector<string> operaciones;
public:
    void push(string op) { operaciones.push_back(op); }
    string pop() {
        if (operaciones.empty()) return "";
        string op = operaciones.back();
        operaciones.pop_back();
        return op;
    }
    bool empty() { return operaciones.empty(); }
};

class ColaProcesamiento {
private:
    vector<ProductoInvestigacion*> cola;
public:
    void enqueue(ProductoInvestigacion* p) { cola.push_back(p); }
    ProductoInvestigacion* dequeue() {
        if (cola.empty()) return NULL;
        ProductoInvestigacion* p = cola.front();
        cola.erase(cola.begin());
        return p;
    }
    bool empty() { return cola.empty(); }
};

class HipercuboInformacion {
private:
    double*** matriz;
    int N, M, K;
public:
    HipercuboInformacion(int grupos, int categorias, int anios) : N(grupos), M(categorias), K(anios) {
        matriz = new double**[N];
        for (int i = 0; i < N; ++i) {
            matriz[i] = new double*[M];
            for (int j = 0; j < M; ++j) {
                matriz[i][j] = new double[K];
                for (int k = 0; k < K; ++k) matriz[i][j][k] = 0.0;
            }
        }
    }

    void registrarDato(int g, int c, int a, double valor) {
        if (g < N && c < M && a < K) {
            matriz[g][c][a] += valor;
        }
    }

    void generarResumenEstadistico() {
        cout << "Resumen Estadistico Generado..." << endl;
        // Lógica simulada
    }
};

// =========================================================================
// MÓDULOS DE PERSISTENCIA Y LECTURA
// =========================================================================

class LectorArchivosYWeb {
public:
    void cargarDatosScraping() {
        // Simulación de carga web
    }
};

class PersistenciaArchivos {
public:
    void guardarDatosBinarios(MultilistaGrupos& m) {
        // Simulación
    }
    void cargarDatosBinarios() {
        // Simulación
    }
};

// =========================================================================
// MOTOR DE CONSOLA C++
// =========================================================================

class MotorConsolaC {
private:
    ListaInvestigadores listasInv;
    MultilistaGrupos multilistas;

    void dibujarMarco() {
        system("cls");
        gotoxy(10, 2); cout << "==========================================================";
        gotoxy(10, 3); cout << "|        PROYECTO PEA-i (Programa Estadistico UPC)       |";
        gotoxy(10, 4); cout << "==========================================================";
    }

    void pausar() {
        gotoxy(10, 20); cout << "Presione cualquier tecla para continuar...";
        _getch();
    }

public:
    void iniciarSemilla() {
        multilistas.agregarGrupo(new GrupoInvestigacion("G8", "Grupo de Investigacion UPC"));
        listasInv.agregar(new Investigador("001", "Dr. Juan Perez", "jperez@upc.edu.co"));
        multilistas.agregarIntegrante("G8", new Investigador("001", "Dr. Juan Perez", "jperez@upc.edu.co"));
    }

    void menuPrincipal() {
        int opcion = 0;
        while (opcion != 5) {
            dibujarMarco();
            gotoxy(15, 6); cout << "1. Gestionar Investigadores";
            gotoxy(15, 7); cout << "2. Gestionar Grupos";
            gotoxy(15, 8); cout << "3. Reportes Analiticos (Hipercubo)";
            gotoxy(15, 9); cout << "4. Guardar Datos";
            gotoxy(15, 10); cout << "5. Salir";
            gotoxy(15, 12); cout << "Seleccione una opcion: ";
            cin >> opcion;

            switch(opcion) {
                case 1:
                    dibujarMarco();
                    gotoxy(15, 6); cout << "--- GESTION DE INVESTIGADORES ---";
                    gotoxy(15, 8); cout << "Listado actual:";
                    {
                        int y = 10;
                        NodoInvestigador* act = listasInv.getCabeza();
                        while(act) {
                            gotoxy(15, y++);
                            cout << "- " << act->investigador->nombre << " (" << act->investigador->codigoRh << ")";
                            act = act->sig;
                        }
                    }
                    pausar();
                    break;
                case 5:
                    gotoxy(15, 14); cout << "Saliendo del sistema...";
                    Sleep(1000);
                    break;
                default:
                    gotoxy(15, 14); cout << "Opcion no valida o en desarrollo.";
                    pausar();
                    break;
            }
        }
    }
};

// =========================================================================
// FUNCION PRINCIPAL
// =========================================================================

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
#endif
    MotorConsolaC motor;
    motor.iniciarSemilla();
    motor.menuPrincipal();
    return 0;
}
